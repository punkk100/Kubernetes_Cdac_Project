#!/bin/bash
# Verification script to check if everything is set up correctly

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "=========================================="
echo "Project Setup Verification"
echo "=========================================="
echo ""

ERRORS=0

# Check 1: Virtual environment
echo "1. Checking virtual environment..."
if [ -d "$PROJECT_ROOT/.venv" ]; then
    echo "   ✓ Virtual environment exists"
    if [ -x "$PROJECT_ROOT/.venv/bin/ansible" ]; then
        echo "   ✓ Ansible found in venv"
        ANSIBLE_VERSION=$("$PROJECT_ROOT/.venv/bin/ansible" --version | head -1)
        echo "   ✓ $ANSIBLE_VERSION"
    else
        echo "   ✗ Ansible not found in venv"
        ERRORS=$((ERRORS + 1))
    fi
else
    echo "   ✗ Virtual environment not found"
    ERRORS=$((ERRORS + 1))
fi
echo ""

# Check 2: Collections
echo "2. Checking Ansible collections..."
COLLECTIONS_DIR="$PROJECT_ROOT/ansible/collections"
if [ -d "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" ]; then
    echo "   ✓ kubernetes.core collection installed"
    COLLECTION_VERSION=$(find "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" -name "MANIFEST.json" -exec grep -o '"version": "[^"]*"' {} \; | head -1 || echo "unknown")
    echo "   ✓ Version: $COLLECTION_VERSION"
else
    echo "   ✗ kubernetes.core collection NOT found"
    echo "   Location checked: $COLLECTIONS_DIR/ansible_collections/kubernetes/core"
    ERRORS=$((ERRORS + 1))
fi
echo ""

# Check 3: Inventory file
echo "3. Checking inventory file..."
INVENTORY_FILE="$PROJECT_ROOT/ansible/inventories/lab/hosts.ini"
if [ -f "$INVENTORY_FILE" ]; then
    echo "   ✓ Inventory file exists"
    HOST_COUNT=$(grep -c "ansible_host=" "$INVENTORY_FILE" || echo "0")
    echo "   ✓ Found $HOST_COUNT hosts"
else
    echo "   ✗ Inventory file not found"
    ERRORS=$((ERRORS + 1))
fi
echo ""

# Check 4: Ansible config
echo "4. Checking Ansible configuration..."
if [ -f "$PROJECT_ROOT/ansible.cfg" ]; then
    echo "   ✓ Root ansible.cfg exists"
    COLLECTIONS_PATH=$(grep "^collections_path" "$PROJECT_ROOT/ansible.cfg" | cut -d'=' -f2 | tr -d ' ' || echo "")
    if [ "$COLLECTIONS_PATH" = "ansible/collections" ]; then
        echo "   ✓ Collections path configured correctly: $COLLECTIONS_PATH"
    else
        echo "   ⚠ Collections path: $COLLECTIONS_PATH (expected: ansible/collections)"
    fi
else
    echo "   ✗ Root ansible.cfg not found"
    ERRORS=$((ERRORS + 1))
fi
echo ""

# Check 5: SSH key
echo "5. Checking SSH key..."
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"
if [ -f "$SSH_KEY" ]; then
    echo "   ✓ SSH key found: $SSH_KEY"
else
    echo "   ⚠ SSH key not found at $SSH_KEY (will be generated if needed)"
fi
echo ""

# Summary
echo "=========================================="
if [ $ERRORS -eq 0 ]; then
    echo "✓ All checks passed! Project is ready."
    echo "=========================================="
    exit 0
else
    echo "✗ Found $ERRORS error(s). Please fix them before proceeding."
    echo "=========================================="
    echo ""
    echo "Quick fixes:"
    echo "  - Missing collection: ./scripts/install-collections.sh"
    echo "  - Missing venv: Run Step 1 of ./scripts/run-project.sh"
    echo "  - Missing inventory: Run Step 2 of ./scripts/run-project.sh"
    exit 1
fi
