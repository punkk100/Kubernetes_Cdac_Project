#!/bin/bash
# Script to prepare master and worker nodes
# Run this on each node (master and workers) to prepare them for Kubernetes

set -e

NODE_TYPE=${1:-worker}  # master or worker

echo "=========================================="
echo "Preparing $NODE_TYPE Node for Kubernetes"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root or with sudo"
    exit 1
fi

# Update system
echo "Updating system packages..."
apt update
apt upgrade -y

# Install required packages
echo "Installing required packages..."
apt install -y \
    curl \
    wget \
    git \
    vim \
    net-tools \
    apt-transport-https \
    ca-certificates \
    gnupg \
    lsb-release \
    software-properties-common \
    python3-pip

# Disable swap
echo "Disabling swap..."
swapoff -a
sed -i '/ swap / s/^/#/' /etc/fstab

# Load kernel modules
echo "Loading kernel modules..."
modprobe overlay
modprobe br_netfilter

# Ensure modules load on boot
cat > /etc/modules-load.d/k8s.conf << EOF
overlay
br_netfilter
EOF

# Configure sysctl
echo "Configuring sysctl settings..."
cat > /etc/sysctl.d/k8s.conf << EOF
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF

sysctl --system

# Set timezone
echo "Setting timezone to UTC..."
timedatectl set-timezone UTC

# Configure hostname (will be set by Ansible, but prepare here)
CURRENT_HOSTNAME=$(hostname)
echo "Current hostname: $CURRENT_HOSTNAME"
echo "Note: Hostname will be set by Ansible playbook"

# Install containerd
echo "Installing containerd..."
apt install -y containerd

# Configure containerd
mkdir -p /etc/containerd
containerd config default | tee /etc/containerd/config.toml
sed -i 's/SystemdCgroup = false/SystemdCgroup = true/' /etc/containerd/config.toml

# Enable and start containerd
systemctl enable containerd
systemctl restart containerd

# Add Kubernetes repository
echo "Adding Kubernetes repository..."
mkdir -p /etc/apt/keyrings
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.28/deb/Release.key | gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.28/deb/ /" | tee /etc/apt/sources.list.d/kubernetes.list

# Update and install Kubernetes packages
echo "Installing Kubernetes packages..."
apt update
apt install -y kubelet kubeadm kubectl
apt-mark hold kubelet kubeadm kubectl

# Enable kubelet (but don't start yet - will start after cluster init)
systemctl enable kubelet

echo ""
echo "=========================================="
echo "Node preparation complete!"
echo "=========================================="
echo ""
echo "Node is ready for Kubernetes installation via Ansible."
echo ""
echo "If preparing manually (without Ansible):"
if [ "$NODE_TYPE" == "master" ]; then
    echo "  On master node, run:"
    echo "    kubeadm init --pod-network-cidr=10.244.0.0/16"
else
    echo "  On worker node, get join command from master and run:"
    echo "    kubeadm join <master-ip>:6443 --token <token> --discovery-token-ca-cert-hash <hash>"
fi
echo ""

