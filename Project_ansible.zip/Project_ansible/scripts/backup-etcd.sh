#!/bin/bash
# etcd backup script

set -e

BACKUP_DIR="${BACKUP_DIR:-/backup/etcd}"
DATE=$(date +%Y%m%d-%H%M%S)
RETENTION_DAYS="${RETENTION_DAYS:-7}"

echo "Creating etcd backup..."

# Create backup directory
sudo mkdir -p $BACKUP_DIR

# Create backup
sudo ETCDCTL_API=3 etcdctl snapshot save $BACKUP_DIR/etcd-snapshot-$DATE.db \
  --endpoints=https://127.0.0.1:2379 \
  --cacert=/etc/kubernetes/pki/etcd/ca.crt \
  --cert=/etc/kubernetes/pki/etcd/server.crt \
  --key=/etc/kubernetes/pki/etcd/server.key

echo "Backup created: $BACKUP_DIR/etcd-snapshot-$DATE.db"

# Cleanup old backups
echo "Cleaning up backups older than $RETENTION_DAYS days..."
sudo find $BACKUP_DIR -name "etcd-snapshot-*.db" -mtime +$RETENTION_DAYS -delete

echo "Backup complete!"

