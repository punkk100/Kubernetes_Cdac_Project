#!/bin/bash
# Setup script for control node

set -e

# Ensure Ansible sees a UTF-8 locale (required by newer versions)
export LANG=C.UTF-8
export LC_ALL=C.UTF-8

echo "=== Kubernetes Cluster Control Node Setup ==="

# Update system
echo "Updating system packages..."
sudo apt update
sudo apt upgrade -y

# Install Ansible and Python tooling
echo "Installing Ansible and Python tooling..."
sudo apt install -y ansible git openssh-client python3-pip python3-venv

# Install Helm
echo "Installing Helm..."
if ! command -v helm &> /dev/null; then
    sudo snap install helm --classic
else
    echo "Helm already installed"
fi

# Install kubectl
echo "Installing kubectl..."
if ! command -v kubectl &> /dev/null; then
    KUBECTL_VERSION=$(curl -L -s https://dl.k8s.io/release/stable.txt)
    curl -LO "https://dl.k8s.io/release/${KUBECTL_VERSION}/bin/linux/amd64/kubectl"
    sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
    rm kubectl
else
    echo "kubectl already installed"
fi

# Install Python dependencies in a virtual environment (avoid system-wide pip)
echo "Installing Python dependencies (virtual environment)..."

# Determine project root (this script is usually run from project root)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
VENV_DIR="$PROJECT_ROOT/.venv"

if [ ! -d "$VENV_DIR" ]; then
    echo "Creating Python virtual environment at $VENV_DIR..."
    python3 -m venv "$VENV_DIR"
fi

echo "Activating virtual environment..."
source "$VENV_DIR/bin/activate"

echo "Installing requirements from requirements.txt into virtual environment..."
pip install --upgrade pip
pip install -r "$PROJECT_ROOT/requirements.txt"

# Install Kubernetes collection (ensure it matches the venv's Ansible)
echo "Installing Kubernetes Ansible collection (virtual environment)..."
mkdir -p "$PROJECT_ROOT/ansible/collections"
# Try installing from requirements.yml first, fallback to direct install
if [ -f "$PROJECT_ROOT/ansible/collections/requirements.yml" ]; then
    "$VENV_DIR/bin/ansible-galaxy" collection install -r "$PROJECT_ROOT/ansible/collections/requirements.yml" -p "$PROJECT_ROOT/ansible/collections" || \
    "$VENV_DIR/bin/ansible-galaxy" collection install kubernetes.core -p "$PROJECT_ROOT/ansible/collections"
else
    "$VENV_DIR/bin/ansible-galaxy" collection install kubernetes.core -p "$PROJECT_ROOT/ansible/collections"
fi

# Verify installation
if [ ! -d "$PROJECT_ROOT/ansible/collections/ansible_collections/kubernetes/core" ]; then
    echo -e "${RED}ERROR: Failed to install kubernetes.core collection${NC}"
    echo "Trying alternative installation method..."
    "$VENV_DIR/bin/ansible-galaxy" collection install kubernetes.core --force -p "$PROJECT_ROOT/ansible/collections"
    if [ ! -d "$PROJECT_ROOT/ansible/collections/ansible_collections/kubernetes/core" ]; then
        echo -e "${RED}CRITICAL: Collection installation failed. Please check your internet connection and try again.${NC}"
        exit 1
    fi
fi
echo -e "${GREEN}✓ Kubernetes collection installed successfully${NC}"

deactivate

# Generate SSH key if not exists
if [ ! -f ~/.ssh/id_ed25519 ]; then
    echo "Generating SSH key..."
    ssh-keygen -t ed25519 -C "k8s-lab" -f ~/.ssh/id_ed25519 -N ""
    echo "SSH key generated at ~/.ssh/id_ed25519"
    echo "Please copy this key to all cluster nodes:"
    echo "  ssh-copy-id <user>@<node-ip>"
else
    echo "SSH key already exists"
fi

echo ""
echo "=== Setup Complete ==="
echo "Next steps:"
echo "1. Edit ansible/inventories/lab/hosts.ini with your node IPs and users"
echo "2. Copy SSH key to all nodes:"
echo "     ./scripts/copy-ssh-keys-to-nodes.sh"
echo "   Or manually (use user@ip from hosts.ini):"
echo "     ssh-copy-id -i ~/.ssh/id_ed25519.pub master@<worker1-ip>"
echo "     ssh-copy-id -i ~/.ssh/id_ed25519.pub worker1@<worker2-ip>"
echo "3. Test connectivity: ansible -i ansible/inventories/lab/hosts.ini all -m ping"
echo "4. Run playbook: ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml"

