#!/bin/bash
# Master script to guide step-by-step project initialization

set -e

# Ensure Ansible sees a UTF-8 locale (required by newer versions)
export LANG=C.UTF-8
export LC_ALL=C.UTF-8

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

CONTROL_SETUP_FLAG="$PROJECT_ROOT/.state_control_node_ready"
INVENTORY_READY_FLAG="$PROJECT_ROOT/.state_inventory_ready"
PLAYBOOK_RUN_FLAG="$PROJECT_ROOT/.state_playbook_run"
KUBECONFIG_READY_FLAG="$PROJECT_ROOT/.state_kubeconfig_ready"

VENV_BIN="$PROJECT_ROOT/.venv/bin"
if [ -x "$VENV_BIN/ansible" ]; then
  ANSIBLE="$VENV_BIN/ansible"
  ANSIBLE_PLAYBOOK="$VENV_BIN/ansible-playbook"
  ANSIBLE_INVENTORY="$VENV_BIN/ansible-inventory"
else
  ANSIBLE="ansible"
  ANSIBLE_PLAYBOOK="ansible-playbook"
  ANSIBLE_INVENTORY="ansible-inventory"
fi

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "=============================================="
echo " Kubernetes Lab - Guided Initialization Wizard"
echo "=============================================="
echo ""
echo "This script will guide you through the required steps:"
echo "  1) Setup control node"
echo "  2) Configure cluster nodes & inventory"
echo "  3) Run Ansible playbook (cluster deployment)"
echo "  4) Copy kubeconfig"
echo "  5) Verify cluster"
echo ""

confirm() {
  local prompt="$1"
  read -p "$prompt (y/n): " ans
  case "$ans" in
    y|Y) return 0 ;;
    *) return 1 ;;
  esac
}

check_command() {
  local cmd="$1"
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo -e "${RED}Missing required command: $cmd${NC}"
    return 1
  fi
}

step1_control_node_setup() {
  echo "Step 1: Setup control node"
  if [ -f "$CONTROL_SETUP_FLAG" ]; then
    echo -e "${GREEN}✓ Control node already marked as ready.${NC}"
    return 0
  fi

  echo "This will run: scripts/setup-control-node.sh"
  if confirm "Run control-node setup now?"; then
    (cd "$PROJECT_ROOT" && bash scripts/setup-control-node.sh)
    touch "$CONTROL_SETUP_FLAG"
    echo -e "${GREEN}Control node setup completed and recorded.${NC}"
  else
    echo -e "${YELLOW}You must complete control-node setup before continuing.${NC}"
    exit 1
  fi
}

step2_cluster_nodes_inventory() {
  echo ""
  echo "Step 2: Configure cluster nodes & inventory"
  if [ -f "$INVENTORY_READY_FLAG" ]; then
    echo -e "${GREEN}✓ Inventory previously marked as done.${NC}"
    echo ""
    echo "You can either:"
    echo "  - Reuse the existing master/worker IPs and SSH users from the current hosts.ini"
    echo "    (the script will just refresh SSH config and test connectivity), or"
    echo "  - Re-run the interactive node setup to CHANGE master/worker IPs and/or SSH users."
    echo ""
    if confirm "Reuse existing inventory and refresh it in auto mode?"; then
      echo -e "${YELLOW}Refreshing hosts.ini for current admin (non-interactive)...${NC}"
      # Refresh hosts.ini based on existing inventory + current admin environment (SSH key under $HOME)
      (cd "$PROJECT_ROOT" && bash scripts/setup-cluster-nodes.sh --auto)
      echo -e "${GREEN}Inventory refreshed.${NC}"
      # If inventory has changed (e.g., different master/worker IPs), any previous
      # deployment state is no longer reliable. Clear playbook/kubeconfig flags so
      # the wizard will re-run the deployment for the new setup.
      if [ -f "$PLAYBOOK_RUN_FLAG" ] || [ -f "$KUBECONFIG_READY_FLAG" ]; then
        echo -e "${YELLOW}Inventory was refreshed; clearing previous deployment state flags so a new cluster can be created.${NC}"
        rm -f "$PLAYBOOK_RUN_FLAG" "$KUBECONFIG_READY_FLAG"
      fi
      return 0
    else
      echo -e "${YELLOW}Re-running interactive cluster node setup so you can change IPs/users...${NC}"
      # Clear previous state so this is treated as a fresh inventory setup
      rm -f "$INVENTORY_READY_FLAG" "$PLAYBOOK_RUN_FLAG" "$KUBECONFIG_READY_FLAG"
      # Fall through to the interactive setup logic below
    fi
  fi

  echo "This will run: scripts/setup-cluster-nodes.sh"
  echo "It will:"
  echo "  - Ask for master/worker IPs (LAN or ZeroTier)"
  echo "  - Test SSH"
  echo "  - Create ansible/inventories/lab/hosts.ini"
  echo "  - Test Ansible ping"

  if confirm "Run cluster-nodes setup now?"; then
    (cd "$PROJECT_ROOT" && bash scripts/setup-cluster-nodes.sh)
    # Validate inventory file exists and is valid
    if [ ! -f "$PROJECT_ROOT/ansible/inventories/lab/hosts.ini" ]; then
      echo -e "${RED}Error: Inventory file was not created.${NC}"
      exit 1
    fi
    # Validate inventory file can be parsed by Ansible
    VALIDATION_OUTPUT=$(cd "$PROJECT_ROOT" && "$ANSIBLE_INVENTORY" -i ansible/inventories/lab/hosts.ini --list 2>&1)
    VALIDATION_EXIT_CODE=$?
    if [ $VALIDATION_EXIT_CODE -ne 0 ]; then
      echo -e "${RED}Error: Inventory file validation failed!${NC}"
      echo "Ansible-inventory error output:"
      echo "$VALIDATION_OUTPUT"
      echo ""
      echo "Trying alternative validation method..."
      # Try using ansible-playbook --list-hosts as alternative validation
      if (cd "$PROJECT_ROOT" && "$ANSIBLE_PLAYBOOK" --list-hosts -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml >/dev/null 2>&1); then
        echo -e "${YELLOW}Warning: ansible-inventory failed, but ansible-playbook can parse the inventory.${NC}"
        echo -e "${GREEN}Continuing with deployment...${NC}"
      else
        echo -e "${RED}Both validation methods failed. Please check: $PROJECT_ROOT/ansible/inventories/lab/hosts.ini${NC}"
        echo "It should contain only valid Ansible INI format (no extra text or status messages)."
        exit 1
      fi
    fi
    # Validate Ansible ping works
    if (cd "$PROJECT_ROOT" && "$ANSIBLE" -i ansible/inventories/lab/hosts.ini all -m ping >/dev/null 2>&1); then
      touch "$INVENTORY_READY_FLAG"
      echo -e "${GREEN}Inventory & node configuration verified and recorded.${NC}"
    else
      echo -e "${RED}Ansible connectivity test failed. Fix connectivity and re-run this step.${NC}"
      exit 1
    fi
  else
    echo -e "${YELLOW}You must configure nodes & inventory before continuing.${NC}"
    exit 1
  fi
}

step3_run_playbook() {
  echo ""
  echo "Step 3: Deploy cluster with Ansible"
  if [ -f "$PLAYBOOK_RUN_FLAG" ]; then
    echo -e "${GREEN}✓ Cluster deployment already marked as done.${NC}"
    return 0
  fi

  if [ ! -f "$INVENTORY_READY_FLAG" ]; then
    echo -e "${RED}Inventory is not marked as ready. Complete Step 2 first.${NC}"
    exit 1
  fi

  echo ""
  echo -e "${YELLOW}If these machines were previously part of a Kubernetes cluster (old lab, old IPs, or a failed run),${NC}"
  echo -e "${YELLOW}they should be reset before a fresh deployment to avoid kubeadm preflight errors.${NC}"
  if confirm "Reset Kubernetes state on worker nodes now (kubeadm reset -f and CNI cleanup)?"; then
    echo "Running kubeadm reset on k8s_workers..."
    (cd "$PROJECT_ROOT" && "$ANSIBLE" -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a 'kubeadm reset -f' || true)
    echo "Cleaning CNI configuration on k8s_workers..."
    (cd "$PROJECT_ROOT" && "$ANSIBLE" -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a 'rm -rf /etc/cni/net.d/*' || true)
    echo -e "${GREEN}Worker nodes reset step completed (see above for any host-specific issues).${NC}"
    echo ""
  fi

  # Ensure kubernetes.core collection is installed
  echo "Checking for required Ansible collections..."
  COLLECTIONS_DIR="$PROJECT_ROOT/ansible/collections"
  mkdir -p "$COLLECTIONS_DIR"
  
  if [ ! -d "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" ]; then
    echo -e "${YELLOW}kubernetes.core collection not found. Installing...${NC}"
    
    # Determine which ansible-galaxy to use
    if [ -x "$VENV_BIN/ansible-galaxy" ]; then
      ANSIBLE_GALAXY="$VENV_BIN/ansible-galaxy"
    else
      ANSIBLE_GALAXY="ansible-galaxy"
    fi
    
    # Try installing from requirements.yml if it exists
    if [ -f "$COLLECTIONS_DIR/requirements.yml" ]; then
      echo "Installing from requirements.yml..."
      "$ANSIBLE_GALAXY" collection install -r "$COLLECTIONS_DIR/requirements.yml" -p "$COLLECTIONS_DIR" || \
      "$ANSIBLE_GALAXY" collection install kubernetes.core -p "$COLLECTIONS_DIR"
    else
      echo "Installing kubernetes.core collection directly..."
      "$ANSIBLE_GALAXY" collection install kubernetes.core -p "$COLLECTIONS_DIR"
    fi
    
    # Verify installation
    if [ ! -d "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" ]; then
      echo -e "${RED}Failed to install kubernetes.core collection. Trying force install...${NC}"
      "$ANSIBLE_GALAXY" collection install kubernetes.core --force -p "$COLLECTIONS_DIR"
      
      if [ ! -d "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" ]; then
        echo -e "${RED}CRITICAL: Failed to install kubernetes.core collection.${NC}"
        echo "Please ensure:"
        echo "  1. You have internet connectivity"
        echo "  2. Run Step 1 to set up the control node properly"
        echo "  3. Or manually install: ansible-galaxy collection install kubernetes.core -p $COLLECTIONS_DIR"
        exit 1
      fi
    fi
    echo -e "${GREEN}✓ Collection installed successfully${NC}"
  else
    echo -e "${GREEN}✓ Required collections found${NC}"
  fi

  echo "This will run:"
  echo "  ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml"
  echo ""
  echo -e "${YELLOW}If workers failed to join previously (e.g. cluster-info / join errors):${NC}"
  echo "  Reset workers first, then re-run the playbook:"
  echo "    ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a 'kubeadm reset -f'"
  echo "  See docs/TROUBLESHOOTING.md for details."
  echo ""

  if confirm "Run Ansible playbook now?"; then
    # Verify inventory is valid before running playbook
    VALIDATION_OUTPUT=$(cd "$PROJECT_ROOT" && "$ANSIBLE_INVENTORY" -i ansible/inventories/lab/hosts.ini --list 2>&1)
    VALIDATION_EXIT_CODE=$?
    if [ $VALIDATION_EXIT_CODE -ne 0 ]; then
      echo -e "${RED}Error: Inventory file validation failed!${NC}"
      echo "Ansible-inventory error output:"
      echo "$VALIDATION_OUTPUT"
      echo ""
      echo -e "${RED}Please fix Step 2 first.${NC}"
      exit 1
    fi
    # Check if any hosts are available
    HOST_COUNT=$(cd "$PROJECT_ROOT" && "$ANSIBLE_INVENTORY" -i ansible/inventories/lab/hosts.ini --list 2>/dev/null | grep -c '"ansible_host"' || echo "0")
    if [ "$HOST_COUNT" -eq "0" ]; then
      echo -e "${RED}Error: No hosts found in inventory. Please fix Step 2 first.${NC}"
      exit 1
    fi
    # Run playbook from project root (uses root ansible.cfg with correct paths)
    cd "$PROJECT_ROOT"
    if [ -x "$VENV_BIN/ansible-playbook" ]; then
      "$VENV_BIN/ansible-playbook" -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml || PLAYBOOK_FAILED=1
    else
      ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml || PLAYBOOK_FAILED=1
    fi
    if [ -n "${PLAYBOOK_FAILED:-}" ]; then
      echo -e "${RED}Playbook failed.${NC} Typical fixes:"
      echo "  - Join failures: reset workers then re-run: ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a 'kubeadm reset -f'"
      echo "  - See docs/TROUBLESHOOTING.md (cluster-info, kubectl on workers, etc.)"
      exit 1
    fi
    touch "$PLAYBOOK_RUN_FLAG"
    echo -e "${GREEN}Cluster deployment completed and recorded.${NC}"
  else
    echo -e "${YELLOW}Cluster deployment is required before moving to kubeconfig and verification.${NC}"
    exit 1
  fi
}

step4_copy_kubeconfig() {
  echo ""
  echo "Step 4: Copy kubeconfig to this machine"
  if [ -f "$KUBECONFIG_READY_FLAG" ]; then
    echo -e "${GREEN}✓ kubeconfig already copied (flag present).${NC}"
    return 0
  fi

  if [ ! -f "$PLAYBOOK_RUN_FLAG" ]; then
    echo -e "${RED}Playbook run is not marked as complete. Run Step 3 first.${NC}"
    exit 1
  fi

  echo "This will run: scripts/copy-kubeconfig.sh <user>@<master-ip>"
  echo "Example: ubuntu@192.168.1.10 or ubuntu@<ZeroTier-IP>"
  echo "kubectl is configured on the control plane; copy-kubeconfig copies it here so you can run kubectl locally."
  read -p "Enter control-plane SSH target (e.g. ubuntu@192.168.1.10): " CP_TARGET
  if [ -z "$CP_TARGET" ]; then
    echo -e "${RED}Control-plane target is required.${NC}"
    exit 1
  fi

  (cd "$PROJECT_ROOT" && bash scripts/copy-kubeconfig.sh "$CP_TARGET")
  if kubectl get nodes >/dev/null 2>&1; then
    touch "$KUBECONFIG_READY_FLAG"
    echo -e "${GREEN}kubeconfig copied and verified.${NC}"
  else
    echo -e "${RED}kubectl could not talk to the cluster. Please fix and re-run this step.${NC}"
    exit 1
  fi
}

step5_verify_cluster() {
  echo ""
  echo "Step 5: Verify cluster health"

  if ! check_command kubectl; then
    echo -e "${RED}kubectl is required for verification. Make sure kubeconfig is set up.${NC}"
    exit 1
  fi

  (cd "$PROJECT_ROOT" && bash scripts/verify-cluster.sh)
  echo -e "${GREEN}Cluster verification script completed. Review output above for any issues.${NC}"
}

echo ""
echo "Running pre-flight checks..."
check_command bash || exit 1

# Quick verification (non-blocking)
if [ -x "$PROJECT_ROOT/scripts/verify-setup.sh" ]; then
  echo "Verifying project setup..."
  "$PROJECT_ROOT/scripts/verify-setup.sh" || echo -e "${YELLOW}Warning: Some setup issues detected. Continuing anyway...${NC}"
  echo ""
fi

echo ""
step1_control_node_setup
step2_cluster_nodes_inventory
step3_run_playbook
step4_copy_kubeconfig
step5_verify_cluster

echo ""
echo -e "${GREEN}All guided steps completed!${NC}"
echo "Next: you can explore the self-healing demo, run backups with scripts/backup-etcd.sh, etc."
echo "Troubleshooting: docs/TROUBLESHOOTING.md (join failures, cluster-info, kubectl on workers, reset workers)"

