#!/bin/bash
# Script to copy kubeconfig from control plane to local machine

set -e

if [ -z "$1" ]; then
    echo "Usage: $0 <control-plane-user>@<control-plane-ip>"
    echo "Example: $0 ubuntu@192.168.1.10"
    exit 1
fi

CONTROL_PLANE=$1
KUBECONFIG_SOURCE="/etc/kubernetes/admin.conf"

echo "Copying kubeconfig from $CONTROL_PLANE..."

# Check if kubeconfig exists on remote host before attempting to copy
echo "Checking if kubeconfig exists on control plane..."
if ! ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no "$CONTROL_PLANE" "test -f $KUBECONFIG_SOURCE" 2>/dev/null; then
    echo "Error: kubeconfig file not found at $KUBECONFIG_SOURCE on $CONTROL_PLANE"
    echo ""
    echo "This usually means:"
    echo "  1) Kubernetes cluster has not been initialized yet (kubeadm init not run)"
    echo "  2) The playbook deployment failed or was skipped"
    echo ""
    echo "To fix:"
    echo "  1) Ensure Step 3 (Ansible playbook deployment) completed successfully"
    echo "  2) Check if kubeadm was initialized: ssh $CONTROL_PLANE 'sudo kubeadm version'"
    echo "  3) Verify cluster is running: ssh $CONTROL_PLANE 'sudo kubectl get nodes'"
    exit 1
fi

# Create .kube directory if it doesn't exist
mkdir -p ~/.kube

# Copy kubeconfig
scp "$CONTROL_PLANE:$KUBECONFIG_SOURCE" ~/.kube/config

# Set correct permissions
chmod 600 ~/.kube/config

echo "kubeconfig copied successfully!"
echo "Testing connection..."
kubectl get nodes

