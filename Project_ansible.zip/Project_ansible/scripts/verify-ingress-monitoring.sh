#!/bin/bash
# Comprehensive verification script for Ingress NGINX, Prometheus, and Grafana

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    local status=$1
    local message=$2
    
    case $status in
        "OK")
            echo -e "${GREEN}✓${NC} $message"
            ;;
        "FAIL")
            echo -e "${RED}✗${NC} $message"
            ;;
        "WARN")
            echo -e "${YELLOW}⚠${NC} $message"
            ;;
        "INFO")
            echo -e "${BLUE}ℹ${NC} $message"
            ;;
    esac
}

print_header() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    print_status "FAIL" "kubectl is not installed or not in PATH"
    exit 1
fi

# Check kubectl connectivity
if ! kubectl cluster-info &> /dev/null; then
    print_status "FAIL" "Cannot connect to Kubernetes cluster"
    print_status "INFO" "Make sure KUBECONFIG is set or kubeconfig is in ~/.kube/config"
    exit 1
fi

print_status "OK" "kubectl is working and connected to cluster"
echo ""

# ============================================
# INGRESS-NGINX VERIFICATION
# ============================================
print_header "Ingress NGINX Verification"

# Check namespace
if kubectl get namespace ingress-nginx &> /dev/null; then
    print_status "OK" "Namespace 'ingress-nginx' exists"
else
    print_status "FAIL" "Namespace 'ingress-nginx' not found"
    exit 1
fi

# Check Helm release
if kubectl get deployment -n ingress-nginx ingress-nginx-controller &> /dev/null; then
    print_status "OK" "Ingress NGINX controller deployment exists"
    
    # Check deployment status
    DESIRED=$(kubectl get deployment -n ingress-nginx ingress-nginx-controller -o jsonpath='{.spec.replicas}')
    READY=$(kubectl get deployment -n ingress-nginx ingress-nginx-controller -o jsonpath='{.status.readyReplicas}')
    
    if [ "$DESIRED" == "$READY" ] && [ "$READY" -gt 0 ]; then
        print_status "OK" "Ingress NGINX controller is ready ($READY/$DESIRED replicas)"
    else
        print_status "WARN" "Ingress NGINX controller not fully ready ($READY/$DESIRED replicas)"
    fi
else
    print_status "FAIL" "Ingress NGINX controller deployment not found"
fi

# Check pods
INGRESS_PODS=$(kubectl get pods -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)
if [ "$INGRESS_PODS" -gt 0 ]; then
    print_status "OK" "Ingress NGINX pods running: $INGRESS_PODS"
else
    print_status "FAIL" "No running Ingress NGINX pods found"
fi

# Check service
if kubectl get service -n ingress-nginx ingress-nginx-controller &> /dev/null; then
    print_status "OK" "Ingress NGINX controller service exists"
    
    SERVICE_TYPE=$(kubectl get service -n ingress-nginx ingress-nginx-controller -o jsonpath='{.spec.type}')
    print_status "INFO" "Service Type: $SERVICE_TYPE"
    
    if [ "$SERVICE_TYPE" == "LoadBalancer" ]; then
        EXTERNAL_IP=$(kubectl get service -n ingress-nginx ingress-nginx-controller -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
        if [ -z "$EXTERNAL_IP" ]; then
            print_status "WARN" "LoadBalancer External-IP is pending (use NodePort or install MetalLB)"
        else
            print_status "OK" "LoadBalancer External-IP: $EXTERNAL_IP"
        fi
    fi
    
    HTTP_NODEPORT=$(kubectl get service -n ingress-nginx ingress-nginx-controller -o jsonpath='{.spec.ports[?(@.name=="http")].nodePort}')
    HTTPS_NODEPORT=$(kubectl get service -n ingress-nginx ingress-nginx-controller -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}')
    
    if [ -n "$HTTP_NODEPORT" ]; then
        print_status "INFO" "HTTP NodePort: $HTTP_NODEPORT"
    fi
    if [ -n "$HTTPS_NODEPORT" ]; then
        print_status "INFO" "HTTPS NodePort: $HTTPS_NODEPORT"
    fi
else
    print_status "FAIL" "Ingress NGINX controller service not found"
fi

# ============================================
# MONITORING VERIFICATION
# ============================================
print_header "Monitoring Stack Verification"

# Check namespace
if kubectl get namespace monitoring &> /dev/null; then
    print_status "OK" "Namespace 'monitoring' exists"
else
    print_status "FAIL" "Namespace 'monitoring' not found"
    exit 1
fi

# ============================================
# PROMETHEUS VERIFICATION
# ============================================
print_header "Prometheus Verification"

# Check StatefulSet
if kubectl get statefulset -n monitoring prometheus-monitoring-kube-prometheus-prometheus &> /dev/null; then
    print_status "OK" "Prometheus StatefulSet exists"
    
    DESIRED=$(kubectl get statefulset -n monitoring prometheus-monitoring-kube-prometheus-prometheus -o jsonpath='{.spec.replicas}')
    READY=$(kubectl get statefulset -n monitoring prometheus-monitoring-kube-prometheus-prometheus -o jsonpath='{.status.readyReplicas}')
    
    if [ "$DESIRED" == "$READY" ] && [ "$READY" -gt 0 ]; then
        print_status "OK" "Prometheus is ready ($READY/$DESIRED replicas)"
    else
        print_status "WARN" "Prometheus not fully ready ($READY/$DESIRED replicas)"
    fi
else
    print_status "FAIL" "Prometheus StatefulSet not found"
fi

# Check Prometheus pods
PROM_PODS=$(kubectl get pods -n monitoring -l app.kubernetes.io/name=prometheus --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)
if [ "$PROM_PODS" -gt 0 ]; then
    print_status "OK" "Prometheus pods running: $PROM_PODS"
else
    print_status "FAIL" "No running Prometheus pods found"
fi

# Check Prometheus service
if kubectl get service -n monitoring monitoring-kube-prometheus-prometheus &> /dev/null; then
    print_status "OK" "Prometheus service exists"
else
    print_status "FAIL" "Prometheus service not found"
fi

# Check Prometheus Operator
if kubectl get deployment -n monitoring monitoring-kube-prometheus-operator &> /dev/null; then
    print_status "OK" "Prometheus Operator deployment exists"
    
    DESIRED=$(kubectl get deployment -n monitoring monitoring-kube-prometheus-operator -o jsonpath='{.spec.replicas}')
    READY=$(kubectl get deployment -n monitoring monitoring-kube-prometheus-operator -o jsonpath='{.status.readyReplicas}')
    
    if [ "$DESIRED" == "$READY" ] && [ "$READY" -gt 0 ]; then
        print_status "OK" "Prometheus Operator is ready ($READY/$DESIRED replicas)"
    else
        print_status "WARN" "Prometheus Operator not fully ready ($READY/$READY replicas)"
    fi
else
    print_status "FAIL" "Prometheus Operator deployment not found"
fi

# ============================================
# GRAFANA VERIFICATION
# ============================================
print_header "Grafana Verification"

# Check deployment
if kubectl get deployment -n monitoring monitoring-grafana &> /dev/null; then
    print_status "OK" "Grafana deployment exists"
    
    DESIRED=$(kubectl get deployment -n monitoring monitoring-grafana -o jsonpath='{.spec.replicas}')
    READY=$(kubectl get deployment -n monitoring monitoring-grafana -o jsonpath='{.status.readyReplicas}')
    
    if [ "$DESIRED" == "$READY" ] && [ "$READY" -gt 0 ]; then
        print_status "OK" "Grafana is ready ($READY/$DESIRED replicas)"
    else
        print_status "WARN" "Grafana not fully ready ($READY/$DESIRED replicas)"
    fi
else
    print_status "FAIL" "Grafana deployment not found"
fi

# Check Grafana pods
GRAFANA_PODS=$(kubectl get pods -n monitoring -l app.kubernetes.io/name=grafana --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)
if [ "$GRAFANA_PODS" -gt 0 ]; then
    print_status "OK" "Grafana pods running: $GRAFANA_PODS"
else
    print_status "FAIL" "No running Grafana pods found"
fi

# Check Grafana service
if kubectl get service -n monitoring monitoring-grafana &> /dev/null; then
    print_status "OK" "Grafana service exists"
else
    print_status "FAIL" "Grafana service not found"
fi

# ============================================
# ALERTMANAGER VERIFICATION
# ============================================
print_header "Alertmanager Verification"

# Check StatefulSet
if kubectl get statefulset -n monitoring alertmanager-monitoring-kube-prometheus-alertmanager &> /dev/null; then
    print_status "OK" "Alertmanager StatefulSet exists"
    
    DESIRED=$(kubectl get statefulset -n monitoring alertmanager-monitoring-kube-prometheus-alertmanager -o jsonpath='{.spec.replicas}')
    READY=$(kubectl get statefulset -n monitoring alertmanager-monitoring-kube-prometheus-alertmanager -o jsonpath='{.status.readyReplicas}')
    
    if [ "$DESIRED" == "$READY" ] && [ "$READY" -gt 0 ]; then
        print_status "OK" "Alertmanager is ready ($READY/$DESIRED replicas)"
    else
        print_status "WARN" "Alertmanager not fully ready ($READY/$DESIRED replicas)"
    fi
else
    print_status "FAIL" "Alertmanager StatefulSet not found"
fi

# Check Alertmanager pods
AM_PODS=$(kubectl get pods -n monitoring -l app.kubernetes.io/name=alertmanager --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)
if [ "$AM_PODS" -gt 0 ]; then
    print_status "OK" "Alertmanager pods running: $AM_PODS"
else
    print_status "FAIL" "No running Alertmanager pods found"
fi

# ============================================
# INGRESS RESOURCES VERIFICATION
# ============================================
print_header "Ingress Resources Verification"

# Check Grafana Ingress
if kubectl get ingress -n monitoring grafana-ingress &> /dev/null; then
    print_status "OK" "Grafana Ingress exists"
else
    print_status "WARN" "Grafana Ingress not found"
fi

# Check Prometheus Ingress
if kubectl get ingress -n monitoring prometheus-ingress &> /dev/null; then
    print_status "OK" "Prometheus Ingress exists"
else
    print_status "WARN" "Prometheus Ingress not found"
fi

# Check Alertmanager Ingress
if kubectl get ingress -n monitoring alertmanager-ingress &> /dev/null; then
    print_status "OK" "Alertmanager Ingress exists"
else
    print_status "WARN" "Alertmanager Ingress not found"
fi

# ============================================
# SERVICE MONITORS & SCRAPING
# ============================================
print_header "Service Monitors & Metrics"

# Count ServiceMonitors
SM_COUNT=$(kubectl get servicemonitors -n monitoring --no-headers 2>/dev/null | wc -l)
if [ "$SM_COUNT" -gt 0 ]; then
    print_status "OK" "ServiceMonitors configured: $SM_COUNT"
else
    print_status "WARN" "No ServiceMonitors found"
fi

# Check if ingress-nginx metrics are being scraped
if kubectl get servicemonitor -n monitoring ingress-nginx-controller &> /dev/null 2>&1; then
    print_status "OK" "Ingress NGINX metrics ServiceMonitor exists"
else
    print_status "INFO" "Ingress NGINX metrics may not be automatically scraped (no ServiceMonitor in monitoring namespace)"
fi

# ============================================
# ACCESS INFORMATION
# ============================================
print_header "Access Information"

echo ""
print_status "INFO" "Port-forward Commands:"
echo "  Grafana:      kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80"
echo "  Prometheus:   kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090"
echo "  Alertmanager: kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-alertmanager 9093:9093"

echo ""
if [ -n "$HTTP_NODEPORT" ]; then
    NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>/dev/null)
    
    print_status "INFO" "NodePort Access (use any node IP):"
    echo "  Node IP: $NODE_IP (or use any node IP)"
    echo "  Grafana:      http://$NODE_IP:$HTTP_NODEPORT/grafana"
    echo "  Prometheus:   http://$NODE_IP:$HTTP_NODEPORT/prometheus"
    echo "  Alertmanager: http://$NODE_IP:$HTTP_NODEPORT/alertmanager"
    
    echo ""
    print_status "INFO" "Hostname Access (add to /etc/hosts):"
    echo "  $NODE_IP grafana.local prometheus.local alertmanager.local"
    echo "  Then access:"
    echo "    http://grafana.local:$HTTP_NODEPORT"
    echo "    http://prometheus.local:$HTTP_NODEPORT"
    echo "    http://alertmanager.local:$HTTP_NODEPORT"
fi

echo ""
print_status "INFO" "Grafana Credentials:"
echo "  Username: admin"
echo "  Password: Check ansible/roles/monitoring/defaults/main.yml (default: admin123)"

echo ""
print_header "Verification Complete"
echo ""
