#!/bin/bash
# Copy SSH key to all cluster nodes (uses ansible inventory).
# Run from project root, as the user that runs Ansible (typically root on control node).
# You will be prompted for the password of each remote user unless keys are already copied.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
INV="${INVENTORY:-$PROJECT_ROOT/ansible/inventories/lab/hosts.ini}"

if [ ! -f "$INV" ]; then
    echo "Inventory not found: $INV"
    exit 1
fi

# Key from inventory or default
KEY=$(grep -E '^\s*ansible_ssh_private_key_file\s*=' "$INV" | sed -E 's/.*=\s*//' | tr -d '"'"'"' | head -1)
KEY="${KEY:-$HOME/.ssh/id_ed25519}"

if [ ! -f "$KEY" ]; then
    echo "SSH private key not found: $KEY"
    exit 1
fi
PUB="${KEY}.pub"
if [ ! -f "$PUB" ]; then
    echo "SSH public key not found: $PUB"
    exit 1
fi

echo "Using SSH key: $KEY"
echo "Inventory: $INV"
echo ""

# Extract user@host from lines with both ansible_host and ansible_user (skip comments)
get_targets() {
    sed -n '/^[[:space:]]*#/d; /ansible_host=.*ansible_user=/s/.*ansible_host=\([^ ]*\).*ansible_user=\([^ ]*\).*/\2@\1/p' "$INV"
}

count=0
while IFS= read -r target; do
    [ -z "$target" ] && continue
    echo "Copying key to $target ..."
    if ssh-copy-id -i "$PUB" -o StrictHostKeyChecking=no "$target"; then
        (( count++ )) || true
    else
        echo "Warning: ssh-copy-id to $target failed (wrong password or user?). Fix and re-run."
        exit 1
    fi
done < <(get_targets)

if [ "$count" -eq 0 ]; then
    echo "No inventory hosts found with ansible_host/ansible_user."
    exit 1
fi

echo ""
echo "Key copied to $count node(s). Test with:"
echo "  ansible -i $INV all -m ping"
