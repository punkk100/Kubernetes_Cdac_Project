# Helper Scripts

This directory contains helper scripts to automate various tasks.

## Setup Scripts (Ubuntu 22.04 only)

### `setup-control-node.sh`
Prepares the control node (where you run Ansible) with all required tools.

**Usage:**
```bash
chmod +x scripts/setup-control-node.sh
./scripts/setup-control-node.sh
```

**What it does:**
- Updates system packages
- Installs Ansible, Helm, kubectl
- Installs Python dependencies
- Installs Kubernetes Ansible collection
- Generates SSH key if needed

### `setup-cluster-nodes.sh` ⭐ **RECOMMENDED**
Interactive script to configure your cluster nodes. This is the easiest way to set up your cluster!

**Usage:**
```bash
chmod +x scripts/setup-cluster-nodes.sh
./scripts/setup-cluster-nodes.sh
```

**What it does:**
- Prompts for master node IP and username
- Prompts for worker node 1 IP and username
- Prompts for worker node 2 IP and username
- Validates IP addresses
- Tests SSH connectivity to all nodes
- Creates/updates inventory file automatically
- Copies SSH keys to all nodes
- Tests Ansible connectivity

**Example interaction:**
```
Enter Master Node (Control Plane) Details:
Master Node IP Address: 192.168.1.10
Master Node Username [default: ubuntu]: 

Enter Worker Node 1 Details:
Worker Node 1 IP Address: 192.168.1.11
Worker Node 1 Username [default: ubuntu]: 

Enter Worker Node 2 Details:
Worker Node 2 IP Address: 192.168.1.12
Worker Node 2 Username [default: ubuntu]: 
```

### `prepare-nodes.sh`
Prepares individual nodes for Kubernetes installation. Usually not needed as Ansible handles this, but useful for manual preparation.

**Usage:**
```bash
# On each node (master or worker)
chmod +x scripts/prepare-nodes.sh
sudo ./scripts/prepare-nodes.sh [master|worker]
```

**What it does:**
- Disables swap
- Loads kernel modules
- Configures sysctl
- Installs containerd
- Installs Kubernetes packages

## Utility Scripts

### `copy-kubeconfig.sh`
Copies kubeconfig from control plane to local machine.

**Usage:**
```bash
chmod +x scripts/copy-kubeconfig.sh
./scripts/copy-kubeconfig.sh ubuntu@192.168.1.10
```

**What it does:**
- Creates ~/.kube directory
- Copies admin.conf from control plane
- Sets correct permissions
- Tests kubectl connection

### `verify-cluster.sh`
Verifies cluster installation and shows status of all components.

**Usage:**
```bash
chmod +x scripts/verify-cluster.sh
./scripts/verify-cluster.sh
```

**What it checks:**
- Node status
- System pods
- CNI pods
- Ingress status
- Monitoring status
- Storage status
- Backup status
- Node resources

### `backup-etcd.sh`
Creates etcd backup on control plane node.

**Usage:**
```bash
# On control plane node
chmod +x scripts/backup-etcd.sh
sudo ./scripts/backup-etcd.sh
```

**What it does:**
- Creates etcd snapshot
- Saves to /backup/etcd/
- Cleans up old backups (default: 7 days retention)

**Environment variables:**
- `BACKUP_DIR`: Backup directory (default: /backup/etcd)
- `RETENTION_DAYS`: Days to keep backups (default: 7)

### `run-project.sh` ⭐ **MASTER WIZARD (Recommended)**
Guided end‑to‑end wizard that runs all key steps in order and stops if a step fails.

**Usage (on Ubuntu control node):**
```bash
chmod +x scripts/run-project.sh
./scripts/run-project.sh
```

**What it does:**
- Runs `setup-control-node.sh` (control node preparation)
- Runs `setup-cluster-nodes.sh` (inventory + SSH + Ansible ping)
- Runs the main Ansible playbook (`ansible/playbooks/site.yml`)
- Copies kubeconfig from the master node
- Runs `verify-cluster.sh`

It uses small `.state_*` files in the project root so you can safely re‑run it without repeating completed steps.

**If workers failed to join previously:** Reset workers before re-running the playbook:  
`ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"`  
See [TROUBLESHOOTING.md](../docs/TROUBLESHOOTING.md) for join, cluster-info, and kubectl-on-workers.

## Quick Start Workflow (manual)

1. **Setup control node (Ubuntu 22.04):**
   ```bash
   ./scripts/setup-control-node.sh
   ```

2. **Configure cluster nodes (inventory + SSH):**
   ```bash
   ./scripts/setup-cluster-nodes.sh
   ```

3. **Deploy cluster with Ansible:**
   ```bash
   cd ansible
   ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
   ```

4. **Copy kubeconfig:**
   ```bash
   cd ..
   ./scripts/copy-kubeconfig.sh ubuntu@<master-ip>
   ```

5. **Verify cluster:**
   ```bash
   ./scripts/verify-cluster.sh
   ```

## Notes

- All scripts should be run from the project root directory
- Some scripts require root/sudo access
- Scripts are designed for Ubuntu 22.04
- Make scripts executable: `chmod +x scripts/*.sh`

## Troubleshooting

If a script fails:
1. Check error messages
2. Verify prerequisites are met
3. Check file permissions
4. Review script output for clues
5. See main [TROUBLESHOOTING.md](../docs/TROUBLESHOOTING.md) (join failures, cluster-info, reset workers, kubectl on workers)

