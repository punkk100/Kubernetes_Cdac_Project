#!/bin/bash
# Standalone script to install required Ansible collections
# This can be run manually if collection installation fails

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
COLLECTIONS_DIR="$PROJECT_ROOT/ansible/collections"

echo "=========================================="
echo "Installing Ansible Collections"
echo "=========================================="
echo ""

# Ensure UTF-8 locale
export LANG=C.UTF-8
export LC_ALL=C.UTF-8

# Determine which ansible-galaxy to use
VENV_BIN="$PROJECT_ROOT/.venv/bin"
if [ -x "$VENV_BIN/ansible-galaxy" ]; then
  ANSIBLE_GALAXY="$VENV_BIN/ansible-galaxy"
  echo "Using virtual environment ansible-galaxy: $ANSIBLE_GALAXY"
else
  ANSIBLE_GALAXY="ansible-galaxy"
  echo "Using system ansible-galaxy: $ANSIBLE_GALAXY"
fi

# Create collections directory
mkdir -p "$COLLECTIONS_DIR"

# Install from requirements.yml if it exists
if [ -f "$COLLECTIONS_DIR/requirements.yml" ]; then
  echo "Installing collections from requirements.yml..."
  "$ANSIBLE_GALAXY" collection install -r "$COLLECTIONS_DIR/requirements.yml" -p "$COLLECTIONS_DIR"
else
  echo "Installing kubernetes.core collection..."
  "$ANSIBLE_GALAXY" collection install kubernetes.core -p "$COLLECTIONS_DIR"
fi

# Verify installation
if [ -d "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" ]; then
  echo ""
  echo "✓ Successfully installed kubernetes.core collection"
  echo "Location: $COLLECTIONS_DIR/ansible_collections/kubernetes/core"
else
  echo ""
  echo "✗ Failed to install collection. Trying force install..."
  "$ANSIBLE_GALAXY" collection install kubernetes.core --force -p "$COLLECTIONS_DIR"
  
  if [ -d "$COLLECTIONS_DIR/ansible_collections/kubernetes/core" ]; then
    echo "✓ Collection installed successfully (force mode)"
  else
    echo "✗ CRITICAL: Collection installation failed!"
    echo "Please check:"
    echo "  1. Internet connectivity"
    echo "  2. ansible-galaxy is working: $ANSIBLE_GALAXY --version"
    exit 1
  fi
fi

echo ""
echo "=========================================="
echo "Collection installation complete!"
echo "=========================================="
