#!/bin/bash
# Interactive script to setup master and worker nodes
# This script will prompt for IPs and configure the inventory

set -e

# Ensure Ansible sees a UTF-8 locale (required by newer versions)
export LANG=C.UTF-8
export LC_ALL=C.UTF-8

echo "=========================================="
echo "Kubernetes Cluster Node Setup"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
INVENTORY_FILE="$PROJECT_ROOT/ansible/inventories/lab/hosts.ini"

# When run with --auto, re-use existing inventory IPs/users and refresh hosts.ini
# so it matches the current admin environment (e.g., SSH key path under $HOME).
AUTO_MODE=false
if [ "${1:-}" = "--auto" ]; then
    AUTO_MODE=true
fi

CURRENT_ADMIN_USER="${SUDO_USER:-$USER}"

load_existing_inventory() {
    [ -f "$INVENTORY_FILE" ] || return 1

    MASTER_IP=""
    MASTER_USER="$CURRENT_ADMIN_USER"

    # Dynamic worker lists (support any number of workers)
    WORKER_IPS=()
    WORKER_USERS=()

    while IFS= read -r line; do
        # Skip comments/empty lines/section headers
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^\# ]] && continue
        [[ "$line" =~ ^\[.*\]$ ]] && continue

        case "$line" in
            k8s-cp-1\ *|k8s-cp-1)
                for tok in $line; do
                    case "$tok" in
                        ansible_host=*) MASTER_IP="${tok#ansible_host=}" ;;
                        ansible_user=*) MASTER_USER="${tok#ansible_user=}" ;;
                    esac
                done
                ;;
            k8s-worker-*\ *|k8s-worker-*)
                # Any k8s-worker-N host – collect IP/user
                w_ip=""
                w_user="$CURRENT_ADMIN_USER"
                for tok in $line; do
                    case "$tok" in
                        ansible_host=*) w_ip="${tok#ansible_host=}" ;;
                        ansible_user=*) w_user="${tok#ansible_user=}" ;;
                    esac
                done
                if [ -n "$w_ip" ]; then
                    WORKER_IPS+=("$w_ip")
                    WORKER_USERS+=("$w_user")
                fi
                ;;
        esac
    done < "$INVENTORY_FILE"

    # Ensure we got valid IPs
    validate_ip "$MASTER_IP" || return 1

    # Require at least one worker
    if [ "${#WORKER_IPS[@]}" -lt 1 ]; then
        return 1
    fi

    for ip in "${WORKER_IPS[@]}"; do
        validate_ip "$ip" || return 1
    done

    WORKER_COUNT="${#WORKER_IPS[@]}"
    return 0
}

VENV_BIN="$PROJECT_ROOT/.venv/bin"
if [ -x "$VENV_BIN/ansible" ]; then
    ANSIBLE="$VENV_BIN/ansible"
    ANSIBLE_INVENTORY="$VENV_BIN/ansible-inventory"
    ANSIBLE_PLAYBOOK="$VENV_BIN/ansible-playbook"
else
    ANSIBLE="ansible"
    ANSIBLE_INVENTORY="ansible-inventory"
    ANSIBLE_PLAYBOOK="ansible-playbook"
fi

# Function to validate IP address
validate_ip() {
    local ip=$1
    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        IFS='.' read -ra ADDR <<< "$ip"
        for i in "${ADDR[@]}"; do
            if [[ $i -gt 255 ]]; then
                return 1
            fi
        done
        return 0
    else
        return 1
    fi
}

# Function to test SSH connection
test_ssh() {
    local ip=$1
    local user=$2
    echo -n "Testing SSH connection to $user@$ip... "
    if ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no $user@$ip "echo 'OK'" &>/dev/null; then
        echo -e "${GREEN}✓${NC}"
        return 0
    else
        echo -e "${RED}✗${NC}"
        return 1
    fi
}

# Function to test passwordless sudo on a host (returns 0 if sudo won't prompt)
test_passwordless_sudo() {
    local ip=$1
    local user=$2
    # If user is root, sudo isn't needed
    if [ "$user" == "root" ]; then
        return 0
    fi
    ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no "$user@$ip" "sudo -n true" &>/dev/null
}

# Function to test whether root SSH works on a host
test_root_ssh() {
    local ip=$1
    ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no "root@$ip" "echo 'OK'" &>/dev/null
}

# If a non-root user can't sudo without a password, prefer root (if possible)
choose_best_user_for_host() {
    local ip=$1
    local user=$2
    local role_label=$3

    if [ "$user" == "root" ]; then
        echo -e "${GREEN}✓${NC} $role_label user is root (no sudo needed)" >&2
        echo "$user"
        return 0
    fi

    echo -n "Checking passwordless sudo for $role_label ($user@$ip)... " >&2
    if test_passwordless_sudo "$ip" "$user"; then
        echo -e "${GREEN}✓${NC}" >&2
        echo "$user"
        return 0
    fi

    echo -e "${YELLOW}✗${NC}" >&2
    echo -n "Trying root SSH for $role_label (root@$ip)... " >&2
    if test_root_ssh "$ip"; then
        echo -e "${GREEN}✓${NC}" >&2
        echo -e "${YELLOW}Info:${NC} $role_label user '$user' has no passwordless sudo; switching to 'root' for Ansible to avoid sudo password prompts." >&2
        echo "root"
        return 0
    fi

    echo -e "${RED}✗${NC}" >&2
    echo -e "${RED}Error:${NC} $role_label user '$user' cannot sudo without a password, and root SSH is not available." >&2
    echo "Fix one of these and re-run:" >&2
    echo "  1) Use a user with passwordless sudo (recommended, e.g. ubuntu with NOPASSWD)" >&2
    echo "  2) Enable root SSH with your key (lab-only approach)" >&2
    exit 1
}

if [ "$AUTO_MODE" = true ]; then
    echo -e "${YELLOW}Auto mode:${NC} refreshing inventory from existing $INVENTORY_FILE"
    if ! load_existing_inventory; then
        echo -e "${YELLOW}Auto mode requested, but no valid existing inventory found.${NC}"
        echo -e "${YELLOW}Falling back to interactive prompts...${NC}"
        AUTO_MODE=false
    else
        echo "Using:"
        echo "  Control plane: $MASTER_IP (user: $MASTER_USER)"
        idx=1
        for i in "${!WORKER_IPS[@]}"; do
            echo "  Worker $idx:      ${WORKER_IPS[$i]} (user: ${WORKER_USERS[$i]})"
            idx=$((idx + 1))
        done
    fi
fi

if [ "$AUTO_MODE" != true ]; then
    # Prompt for master node IP
    echo "Enter Master Node (Control Plane) Details:"
    echo "-------------------------------------------"
    read -p "Master Node IP Address: " MASTER_IP
    while ! validate_ip "$MASTER_IP"; do
        echo -e "${RED}Invalid IP address. Please try again.${NC}"
        read -p "Master Node IP Address: " MASTER_IP
    done

    read -p "Master Node Username [default: ubuntu]: " MASTER_USER
    MASTER_USER=${MASTER_USER:-ubuntu}

    # Prompt for how many worker nodes
    echo ""
    echo "Worker Nodes:"
    echo "-------------"
    read -p "How many worker nodes? [minimum 1, default 2]: " WORKER_COUNT
    WORKER_COUNT=${WORKER_COUNT:-2}
    while ! [[ "$WORKER_COUNT" =~ ^[0-9]+$ ]] || [ "$WORKER_COUNT" -lt 1 ]; do
        echo -e "${RED}Please enter an integer >= 1.${NC}"
        read -p "How many worker nodes? [minimum 1, default 2]: " WORKER_COUNT
        WORKER_COUNT=${WORKER_COUNT:-2}
    done

    # Collect worker details
    WORKER_IPS=()
    WORKER_USERS=()
    idx=1
    while [ "$idx" -le "$WORKER_COUNT" ]; do
        echo ""
        echo "Enter Worker Node $idx Details:"
        echo "-------------------------------"
        read -p "Worker Node $idx IP Address: " w_ip
        while ! validate_ip "$w_ip"; do
            echo -e "${RED}Invalid IP address. Please try again.${NC}"
            read -p "Worker Node $idx IP Address: " w_ip
        done

        read -p "Worker Node $idx Username [default: ubuntu]: " w_user
        w_user=${w_user:-ubuntu}

        WORKER_IPS+=("$w_ip")
        WORKER_USERS+=("$w_user")

        idx=$((idx + 1))
    done
fi

# (Optional) Check if all users are the same (not used currently, kept for future use)
COMMON_USER=""

# Prompt for SSH key location
echo ""
echo "SSH Configuration:"
echo "------------------"
if [ "$AUTO_MODE" = true ]; then
    SSH_KEY="$HOME/.ssh/id_ed25519"
    echo "Using SSH private key: $SSH_KEY"
else
    read -p "SSH Private Key Path [default: ~/.ssh/id_ed25519]: " SSH_KEY
    SSH_KEY=${SSH_KEY:-~/.ssh/id_ed25519}
fi

# Expand ~ to home directory
SSH_KEY="${SSH_KEY/#\~/$HOME}"

# Check if SSH key exists
if [ ! -f "$SSH_KEY" ]; then
    echo -e "${YELLOW}Warning: SSH key not found at $SSH_KEY${NC}"
    if [ "$AUTO_MODE" = true ]; then
        ssh-keygen -t ed25519 -C "k8s-lab" -f "$SSH_KEY" -N ""
        echo -e "${GREEN}SSH key generated at $SSH_KEY${NC}"
    else
        read -p "Generate new SSH key? (y/n) [default: y]: " GEN_KEY
        GEN_KEY=${GEN_KEY:-y}
        if [ "$GEN_KEY" == "y" ] || [ "$GEN_KEY" == "Y" ]; then
            ssh-keygen -t ed25519 -C "k8s-lab" -f "$SSH_KEY" -N ""
            echo -e "${GREEN}SSH key generated at $SSH_KEY${NC}"
        fi
    fi
fi

# Test SSH connections
echo ""
echo "Testing SSH Connections:"
echo "------------------------"

# Control plane
if [ "$AUTO_MODE" = true ]; then
    test_ssh "$MASTER_IP" "$MASTER_USER" || {
        echo -e "${RED}Error:${NC} Cannot SSH to control plane ($MASTER_USER@$MASTER_IP)."
        echo "Fix SSH/key access and re-run."
        exit 1
    }
else
    test_ssh "$MASTER_IP" "$MASTER_USER" || {
        echo -e "${YELLOW}Warning: Cannot connect to master node.${NC}"
        echo "Please ensure:"
        echo "  1. SSH is enabled on the node"
        echo "  2. Firewall allows SSH (port 22)"
        echo "  3. SSH key is copied: ssh-copy-id $MASTER_USER@$MASTER_IP"
        read -p "Continue anyway? (y/n): " CONTINUE
        if [ "$CONTINUE" != "y" ] && [ "$CONTINUE" != "Y" ]; then
            exit 1
        fi
    }
fi

# Workers
for i in "${!WORKER_IPS[@]}"; do
    w_ip="${WORKER_IPS[$i]}"
    w_user="${WORKER_USERS[$i]}"
    label_idx=$((i + 1))

    if [ "$AUTO_MODE" = true ]; then
        test_ssh "$w_ip" "$w_user" || {
            echo -e "${RED}Error:${NC} Cannot SSH to worker $label_idx ($w_user@$w_ip)."
            echo "Fix SSH/key access and re-run."
            exit 1
        }
    else
        test_ssh "$w_ip" "$w_user" || {
            echo -e "${YELLOW}Warning: Cannot connect to worker node $label_idx.${NC}"
            read -p "Continue anyway? (y/n): " CONTINUE
            if [ "$CONTINUE" != "y" ] && [ "$CONTINUE" != "Y" ]; then
                exit 1
            fi
        }
    fi
done

# Auto-select best user per host (passwordless sudo or root)
echo ""
echo "Selecting best Ansible user per host (avoid sudo password prompts):"
echo "---------------------------------------------------------------"
MASTER_USER="$(choose_best_user_for_host "$MASTER_IP" "$MASTER_USER" "Control plane")"
for i in "${!WORKER_IPS[@]}"; do
    w_ip="${WORKER_IPS[$i]}"
    w_user="${WORKER_USERS[$i]}"
    label_idx=$((i + 1))
    WORKER_USERS[$i]="$(choose_best_user_for_host "$w_ip" "$w_user" "Worker $label_idx")"
done

# Create inventory file
echo ""
echo "Creating inventory file..."
echo "--------------------------"

# Backup existing inventory if it exists
if [ -f "$INVENTORY_FILE" ]; then
    cp "$INVENTORY_FILE" "$INVENTORY_FILE.backup.$(date +%Y%m%d-%H%M%S)"
    echo "Backed up existing inventory to $INVENTORY_FILE.backup.*"
fi

# Create inventory directory if it doesn't exist
mkdir -p "$(dirname "$INVENTORY_FILE")"

# Write inventory file (using the usernames selected for each node)
{
  echo "[k8s_control_plane]"
  echo "k8s-cp-1 ansible_host=$MASTER_IP ansible_user=$MASTER_USER"
  echo ""
  echo "[k8s_workers]"
  idx=1
  for i in "${!WORKER_IPS[@]}"; do
      echo "k8s-worker-$idx ansible_host=${WORKER_IPS[$i]} ansible_user=${WORKER_USERS[$i]}"
      idx=$((idx + 1))
  done
  echo ""
  echo "[k8s_cluster:children]"
  echo "k8s_control_plane"
  echo "k8s_workers"
  echo ""
  echo "[all:vars]"
  echo "ansible_ssh_private_key_file=$SSH_KEY"
  echo "ansible_python_interpreter=/usr/bin/python3"
  echo "ansible_ssh_common_args='-o StrictHostKeyChecking=no'"
} > "$INVENTORY_FILE"

echo -e "${GREEN}Inventory file created at: $INVENTORY_FILE${NC}"

# Validate inventory file can be parsed by Ansible
echo "Validating inventory file format..."
VALIDATION_OUTPUT=$(cd "$PROJECT_ROOT/ansible" && "$ANSIBLE_INVENTORY" -i inventories/lab/hosts.ini --list 2>&1)
VALIDATION_EXIT_CODE=$?
if [ $VALIDATION_EXIT_CODE -ne 0 ]; then
    echo -e "${RED}Error: Created inventory file validation failed!${NC}"
    echo "Ansible-inventory error output:"
    echo "$VALIDATION_OUTPUT"
    echo ""
    echo "Inventory file contents:"
    cat "$INVENTORY_FILE"
    echo ""
    echo "Trying alternative validation method..."
    # Try using ansible-playbook --list-hosts as alternative validation
    if (cd "$PROJECT_ROOT" && "$ANSIBLE_PLAYBOOK" --list-hosts -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml >/dev/null 2>&1); then
        echo -e "${YELLOW}Warning: ansible-inventory failed, but ansible-playbook can parse the inventory.${NC}"
        echo -e "${YELLOW}Continuing anyway...${NC}"
    else
        echo -e "${RED}Both validation methods failed. Please check the inventory file manually.${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✓ Inventory file format is valid${NC}"
fi

# Display inventory
echo ""
echo "Inventory Configuration:"
echo "======================="
cat "$INVENTORY_FILE"
echo ""

# Ask to copy SSH keys
echo "SSH Key Setup:"
echo "--------------"
if [ "$AUTO_MODE" = true ]; then
    COPY_KEYS="n"
    echo "Auto mode: skipping ssh-copy-id prompts."
else
    read -p "Copy SSH key to all nodes? (y/n) [default: y]: " COPY_KEYS
    COPY_KEYS=${COPY_KEYS:-y}
fi

if [ "$COPY_KEYS" == "y" ] || [ "$COPY_KEYS" == "Y" ]; then
    echo "Copying SSH key to master node..."
    ssh-copy-id -i "$SSH_KEY.pub" "$MASTER_USER@$MASTER_IP" 2>/dev/null || echo -e "${YELLOW}Warning: Could not copy key to master (may already be copied)${NC}"
    
    idx=1
    for i in "${!WORKER_IPS[@]}"; do
        echo "Copying SSH key to worker node $idx..."
        ssh-copy-id -i "$SSH_KEY.pub" "${WORKER_USERS[$i]}@${WORKER_IPS[$i]}" 2>/dev/null || echo -e "${YELLOW}Warning: Could not copy key to worker $idx (may already be copied)${NC}"
        idx=$((idx + 1))
    done
    
    echo -e "${GREEN}SSH keys copied!${NC}"
fi

# Test Ansible connectivity
echo ""
echo "Testing Ansible Connectivity:"
echo "-------------------------------"
cd "$PROJECT_ROOT/ansible"
if "$ANSIBLE" -i inventories/lab/hosts.ini all -m ping; then
    echo -e "${GREEN}✓ All nodes are reachable via Ansible!${NC}"
else
    echo -e "${RED}✗ Some nodes are not reachable. Please check your SSH configuration.${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}=========================================="
echo "Setup Complete!"
echo "==========================================${NC}"
echo ""
echo "Next steps:"
echo "1. Review inventory: cat $INVENTORY_FILE"
echo "2. Customize variables: edit ansible/inventories/lab/group_vars/all.yml"
echo "3. Deploy cluster (from project root):"
echo "   ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml"
echo "   OR (from ansible/ directory):"
echo "   cd ansible && ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml"
echo ""

