#!/bin/bash
# Cluster verification script

set -e

echo "=== Kubernetes Cluster Verification ==="
echo ""

echo "1. Checking nodes..."
kubectl get nodes
echo ""

echo "2. Checking system pods..."
kubectl get pods -n kube-system
echo ""

echo "3. Checking CNI pods..."
kubectl get pods -n kube-flannel 2>/dev/null || echo "Flannel CNI not found"
echo ""

echo "4. Checking ingress..."
kubectl get pods -n ingress-nginx 2>/dev/null || echo "Ingress not installed"
echo ""

echo "5. Checking monitoring..."
kubectl get pods -n monitoring 2>/dev/null || echo "Monitoring not installed"
echo ""

echo "6. Checking storage..."
kubectl get storageclass truenas-nfs 2>/dev/null || echo "TrueNAS storage not installed"
echo ""

echo "7. Checking backup..."
kubectl get pods -n velero 2>/dev/null || echo "Velero not installed"
echo ""

echo "8. Checking demo (self-healing)..."
kubectl get pods -n self-healing-demo 2>/dev/null || echo "Self-healing demo not installed"
echo ""

echo "9. Node resources..."
kubectl top nodes 2>/dev/null || echo "Metrics server not available"
echo ""

echo "=== Verification Complete ==="
echo ""
echo "Summary: See VERIFICATION.md for what runs when and how to run missing parts (monitoring, storage, backup, demo)."

