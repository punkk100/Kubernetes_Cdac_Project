# Contributing Guide

Thank you for your interest in contributing to this Kubernetes cluster automation project!

## How to Contribute

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/your-feature-name`
3. **Make your changes**
4. **Test your changes** thoroughly
5. **Commit your changes**: `git commit -m "Add feature: description"`
6. **Push to your fork**: `git push origin feature/your-feature-name`
7. **Create a Pull Request**

## Development Guidelines

### Code Style

- Follow Ansible best practices
- Use meaningful variable and task names
- Add comments for complex logic
- Keep playbooks idempotent

### Testing

Before submitting:
- Test on a clean environment
- Verify idempotency (run playbook twice)
- Check all roles work independently
- Test on different Ubuntu versions if possible

### Documentation

- Update README.md for new features
- Add examples for new roles
- Update troubleshooting guide for common issues
- Document any new variables

## Areas for Contribution

- Additional CNI plugins (Cilium, Flannel)
- More monitoring integrations
- Additional storage backends
- Security hardening
- Performance optimizations
- Documentation improvements
- Bug fixes

## Questions?

Open an issue for questions or discussions.

