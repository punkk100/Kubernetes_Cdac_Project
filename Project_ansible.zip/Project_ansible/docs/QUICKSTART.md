# Quick Start Guide

Get your Kubernetes cluster up and running in 30 minutes!

## Prerequisites

- 3 laptops with VMware
- Ubuntu 22.04 VMs (1 per laptop) **(required – scripts and playbooks assume Ubuntu 22.04)**
- All VMs reachable on the network (same WiFi or via a ZeroTier network)
- SSH access between VMs

## 5-Minute Setup

### 1. Prepare Control Node (5 min)

```bash
# Run setup script
chmod +x scripts/setup-control-node.sh
./scripts/setup-control-node.sh
```

### 2. Configure Cluster Nodes (Interactive) (2 min)

**Use the interactive script - it will prompt for IPs and configure everything:**

```bash
chmod +x scripts/setup-cluster-nodes.sh
./scripts/setup-cluster-nodes.sh
```

The script will:
- Ask for master node IP and username
- Ask for worker node 1 IP and username  
- Ask for worker node 2 IP and username
- Test SSH connections
- Create inventory file automatically
- Copy SSH keys to all nodes
- Test Ansible connectivity

**Example:**
```
Enter Master Node (Control Plane) Details:
Master Node IP Address: 192.168.1.10
Master Node Username [default: ubuntu]: 

Enter Worker Node 1 Details:
Worker Node 1 IP Address: 192.168.1.11
Worker Node 1 Username [default: ubuntu]: 

Enter Worker Node 2 Details:
Worker Node 2 IP Address: 192.168.1.12
Worker Node 2 Username [default: ubuntu]: 
```

**Alternative - Manual Configuration:**

If you prefer manual setup, edit `ansible/inventories/lab/hosts.ini` with your IPs.

### 3. Test Connection (1 min)

```bash
cd ansible
ansible -i inventories/lab/hosts.ini all -m ping
```

### 4. Deploy Cluster (20 min)

On the **Ubuntu control node**:

```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

By default this will install:
- Kubernetes + Flannel CNI
- Ingress NGINX
- Monitoring (Prometheus, Grafana)
- Storage (TrueNAS NFS, if enabled)
- Backup (Velero, if enabled)
- Self-healing demo (if enabled)

To disable optional components, edit `ansible/inventories/lab/group_vars/all.yml`:

```yaml
truenas_storage_enabled: false   # disable TrueNAS storage
velero_enabled: false            # disable Velero
self_healing_enabled: false      # disable self-healing demo
```

### 5. Verify (2 min)

```bash
# Copy kubeconfig
./scripts/copy-kubeconfig.sh ubuntu@<k8s-cp-1-ip>

# Verify cluster
./scripts/verify-cluster.sh
```

## Access Services

### Grafana
```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# http://localhost:3000 (admin/admin123)
```

### Prometheus
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
# http://localhost:9090
```

## Self-Healing Demo (if enabled)

When `self_healing_enabled: true`, the playbook deploys a demo in `self-healing-demo`:

```bash
kubectl get pods -n self-healing-demo
kubectl get svc -n self-healing-demo
```

## Test Self-Healing

```bash
# Delete a pod
kubectl delete pod <pod-name> -n self-healing-demo

# Watch it recreate
kubectl get pods -n self-healing-demo -w
```

## Next Steps

- Read [SETUP_GUIDE.md](docs/SETUP_GUIDE.md) for detailed instructions
- Check [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) if you encounter issues
- Review [DISASTER_RECOVERY.md](docs/DISASTER_RECOVERY.md) for backup procedures

## Common Issues

**Nodes not ready?**
```bash
kubectl get pods -n kube-flannel
```

**Can't connect?**
```bash
ansible -i inventories/lab/hosts.ini all -m ping
```

**Need help?**
See [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

