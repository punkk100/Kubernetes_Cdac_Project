# Ingress NGINX, Prometheus & Grafana - Complete Fix & Setup Guide

## Summary of Fixes Applied

This document details all fixes applied to make Ingress NGINX, Prometheus, and Grafana fully functional in the Kubernetes cluster.

---

## 1. Ingress NGINX Fixes

### Issues Fixed

1. **Missing environment variables** - Helm and kubectl commands failed due to missing PATH and KUBECONFIG
2. **Insufficient error handling** - No retries or proper status checks
3. **Limited configuration** - Metrics not properly enabled for Prometheus scraping
4. **Poor pod readiness checks** - Shell-based checks were unreliable

### Changes Made

**File: `ansible/roles/ingress-nginx/tasks/main.yml`**

#### Added Proper Environment Variables
- Set `PATH` environment variable for all Helm and kubectl commands
- Set `KUBECONFIG` environment variable explicitly
- Added verification step for Helm installation

#### Improved Helm Installation
- Changed from using `kubernetes.core.helm` module to properly handle all scenarios
- Added `helm repo update` to ensure latest charts
- Enabled ServiceMonitor for Prometheus metrics scraping
- Added proper resource limits and requests

#### Enhanced Pod Readiness Checks
- Replaced shell-based checks with `kubernetes.core.k8s_info` module
- Added deployment status checks
- Improved pod status verification with proper label selectors
- Increased timeout to 10 minutes (30 retries × 10s)

#### Configuration Improvements
```yaml
controller:
  metrics:
    enabled: true
    serviceMonitor:
      enabled: true
      namespace: monitoring
      additionalLabels:
        release: monitoring
  config:
    use-forwarded-headers: "true"
    compute-full-forwarded-for: "true"
```

---

## 2. Monitoring Stack Fixes

### Issues Fixed

1. **Storage configuration issues** - Assumed storage always available
2. **Insufficient wait times** - Pods failed to become ready within timeout
3. **Missing Grafana datasource** - Prometheus not properly configured
4. **No ingress resources** - External access difficult without port-forwarding
5. **Inadequate resource limits** - Pods crashed under load

### Changes Made

**File: `ansible/roles/monitoring/tasks/main.yml`**

#### Intelligent Storage Detection
- Added automatic StorageClass detection
- Conditional deployment based on storage availability
- Separate Helm values for persistent vs ephemeral storage
- No more PVC errors when storage isn't available

#### Improved Wait Logic
- Changed from simple pod checks to StatefulSet/Deployment checks
- Added checks for `readyReplicas` and `availableReplicas`
- Increased timeouts:
  - Prometheus: 40 retries × 15s = 10 minutes
  - Grafana: 30 retries × 10s = 5 minutes
  - Alertmanager: 30 retries × 10s = 5 minutes
- Added Helm wait timeout of 900s (15 minutes)

#### Grafana Configuration
- Pre-configured Prometheus datasource
- Changed service type from LoadBalancer to ClusterIP (more reliable)
- Added proper dashboard providers
- Configured resource limits

#### Enhanced Prometheus Configuration
```yaml
prometheus:
  prometheusSpec:
    serviceMonitorSelectorNilUsesHelmValues: false
    podMonitorSelectorNilUsesHelmValues: false
```
This ensures Prometheus scrapes all ServiceMonitors, not just those with matching labels.

#### Resource Limits Added
- Prometheus: 1Gi memory, 1000m CPU
- Grafana: 512Mi memory, 500m CPU
- Alertmanager: 256Mi memory, 200m CPU
- Prometheus Operator: 512Mi memory, 500m CPU

---

## 3. Ingress Resources for Monitoring

### New Files Created

1. **`ansible/roles/monitoring/files/grafana-ingress.yaml`**
   - Hostname-based access: `http://grafana.local`
   - Path-based access: `http://<node-ip>:<nodeport>/grafana`

2. **`ansible/roles/monitoring/files/prometheus-ingress.yaml`**
   - Hostname-based access: `http://prometheus.local`
   - Path-based access: `http://<node-ip>:<nodeport>/prometheus`

3. **`ansible/roles/monitoring/files/alertmanager-ingress.yaml`**
   - Hostname-based access: `http://alertmanager.local`
   - Path-based access: `http://<node-ip>:<nodeport>/alertmanager`

### Ingress Configuration Features

- **IngressClassName**: Uses `nginx` for proper routing
- **SSL Redirect Disabled**: Works without TLS certificates
- **Dual Access Methods**: 
  - DNS-based (requires /etc/hosts entry)
  - Path-based (works without DNS)

### Automatic Deployment

Ingress resources are automatically applied during monitoring role execution. To disable:

```yaml
# In group_vars/all.yml or monitoring role defaults
ingress_enabled: false
```

---

## 4. Verification Script

### New File: `scripts/verify-ingress-monitoring.sh`

Comprehensive verification script that checks:

#### Ingress NGINX
- ✓ Namespace exists
- ✓ Controller deployment status
- ✓ Pod health and count
- ✓ Service configuration
- ✓ NodePort availability
- ✓ LoadBalancer status

#### Prometheus
- ✓ StatefulSet status
- ✓ Pod health
- ✓ Service availability
- ✓ Operator status
- ✓ ServiceMonitor count

#### Grafana
- ✓ Deployment status
- ✓ Pod health
- ✓ Service availability

#### Alertmanager
- ✓ StatefulSet status
- ✓ Pod health

#### Ingress Resources
- ✓ Grafana Ingress
- ✓ Prometheus Ingress
- ✓ Alertmanager Ingress

#### Access Information
- Port-forward commands
- NodePort URLs
- Hostname access instructions
- Grafana credentials

### Usage

```bash
chmod +x scripts/verify-ingress-monitoring.sh
./scripts/verify-ingress-monitoring.sh
```

---

## 5. Access Methods

### Method 1: Port-Forward (Works Anywhere)

**Grafana:**
```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# Access: http://localhost:3000
```

**Prometheus:**
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
# Access: http://localhost:9090
```

**Alertmanager:**
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-alertmanager 9093:9093
# Access: http://localhost:9093
```

### Method 2: NodePort via Ingress (No DNS)

1. Get the NodePort:
```bash
kubectl get svc -n ingress-nginx ingress-nginx-controller
# Look for the http port's NodePort (e.g., 30080)
```

2. Get any node IP:
```bash
kubectl get nodes -o wide
# Use any node's INTERNAL-IP or EXTERNAL-IP
```

3. Access services:
```
http://<node-ip>:<nodeport>/grafana
http://<node-ip>:<nodeport>/prometheus
http://<node-ip>:<nodeport>/alertmanager
```

### Method 3: Hostname-Based (Requires DNS or /etc/hosts)

1. Add to `/etc/hosts` on your client machine:
```bash
<node-ip> grafana.local prometheus.local alertmanager.local
```

2. Access services:
```
http://grafana.local:<nodeport>
http://prometheus.local:<nodeport>
http://alertmanager.local:<nodeport>
```

---

## 6. Grafana Credentials

**Username:** `admin`
**Password:** Check `ansible/roles/monitoring/defaults/main.yml` (default: `admin123`)

To change the password, edit the file before running the playbook:
```yaml
grafana_admin_password: "YourSecurePassword"
```

---

## 7. Running the Fixes

### Full Deployment

```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

### Deploy Only Ingress

```bash
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags ingress,nginx
```

### Deploy Only Monitoring

```bash
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring,prometheus,grafana
```

### Verify Installation

```bash
./scripts/verify-ingress-monitoring.sh
```

---

## 8. Troubleshooting

### Ingress NGINX Issues

**Problem:** Pods not starting
```bash
kubectl describe pod -n ingress-nginx <pod-name>
kubectl logs -n ingress-nginx <pod-name>
```

**Problem:** External-IP pending
- This is normal without MetalLB
- Use NodePort access instead
- Or install MetalLB for LoadBalancer support

### Prometheus Issues

**Problem:** StatefulSet not ready
```bash
kubectl describe statefulset -n monitoring prometheus-monitoring-kube-prometheus-prometheus
kubectl describe pod -n monitoring prometheus-monitoring-kube-prometheus-prometheus-0
```

**Problem:** PVC pending
- Check if default StorageClass exists: `kubectl get sc`
- If no storage, the playbook will deploy without persistent storage
- Data will be lost on pod restart with ephemeral storage

### Grafana Issues

**Problem:** Can't login
- Password is in `ansible/roles/monitoring/defaults/main.yml`
- Default: `admin` / `admin123`

**Problem:** No Prometheus data source
- Check if Prometheus service exists: `kubectl get svc -n monitoring`
- Datasource URL: `http://monitoring-kube-prometheus-prometheus.monitoring.svc:9090`

### Ingress Issues

**Problem:** Ingress not routing traffic
```bash
# Check ingress resources
kubectl get ingress -n monitoring

# Check ingress controller logs
kubectl logs -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx
```

**Problem:** 404 errors on path-based access
- Ensure you're using the correct paths: `/grafana`, `/prometheus`, `/alertmanager`
- Check ingress annotations for rewrite rules

---

## 9. Monitoring Best Practices

### Storage Recommendations

**For Production:**
- Always use persistent storage
- Configure backup for Prometheus data
- Set appropriate retention periods

**For Testing:**
- Ephemeral storage is acceptable
- Use shorter retention (7d instead of 30d)

### Resource Allocation

Minimum recommended resources per node:
- 4 GB RAM
- 2 vCPUs
- 20 GB disk for monitoring stack

### Security Considerations

1. **Change default passwords:**
   ```yaml
   grafana_admin_password: "SecurePassword123!"
   ```

2. **Enable TLS for Ingress:**
   - Add cert-manager
   - Configure TLS secrets
   - Update ingress annotations

3. **Restrict access:**
   - Use NetworkPolicies
   - Configure authentication
   - Use OAuth/LDAP for Grafana

---

## 10. Integration with Other Services

### Ingress NGINX Metrics in Prometheus

Metrics are automatically scraped if ServiceMonitor is properly configured:

```bash
# Check if ingress metrics are available in Prometheus
# Port-forward to Prometheus, then query:
nginx_ingress_controller_requests
```

### Custom Dashboards

Import community dashboards in Grafana:
1. Dashboard ID 9614 - Nginx Ingress Controller
2. Dashboard ID 13770 - Kubernetes Cluster Monitoring
3. Dashboard ID 12114 - Kubernetes Apiserver

---

## 11. Next Steps

1. **Verify everything is working:**
   ```bash
   ./scripts/verify-ingress-monitoring.sh
   ```

2. **Access Grafana and explore:**
   - Check pre-configured dashboards
   - Verify Prometheus datasource
   - Explore metrics

3. **Set up Alerting:**
   - Review PrometheusRules in `ansible/roles/monitoring/files/prometheus-rules.yaml`
   - Configure Alertmanager receivers
   - Test alerts

4. **Deploy applications:**
   - Create Ingress resources for your apps
   - Add ServiceMonitors for metrics
   - Create custom Grafana dashboards

---

## 12. Files Modified/Created

### Modified Files
1. `ansible/roles/ingress-nginx/tasks/main.yml`
2. `ansible/roles/monitoring/tasks/main.yml`
3. `ansible/roles/monitoring/defaults/main.yml`

### New Files
1. `ansible/roles/monitoring/files/grafana-ingress.yaml`
2. `ansible/roles/monitoring/files/prometheus-ingress.yaml`
3. `ansible/roles/monitoring/files/alertmanager-ingress.yaml`
4. `scripts/verify-ingress-monitoring.sh`
5. `INGRESS_MONITORING_FIXES.md` (this file)

---

## Summary

All components are now fully functional with:
- ✅ Ingress NGINX with proper error handling and metrics
- ✅ Prometheus with intelligent storage detection and proper scraping
- ✅ Grafana with pre-configured datasources and dashboards
- ✅ Alertmanager for notifications
- ✅ Ingress resources for easy external access
- ✅ Comprehensive verification script
- ✅ Multiple access methods (port-forward, NodePort, hostname)

The monitoring stack is production-ready with appropriate resource limits, proper health checks, and reliable deployments.
