# Project Overview – K8s AutoOps (3‑Node Kubernetes Lab with Ansible)

This project provisions a **3‑node Kubernetes cluster** (1 control plane + 2 workers) using **Ansible**, and adds **networking, ingress, monitoring, storage, backup, and self‑healing** on top.  
It is designed as a **hands‑on lab** that feels close to a production setup, runnable on 3 laptops/VMs.

### Problem Statement

- **Real‑world Kubernetes is complex**: standing up a cluster with proper networking, ingress, monitoring, storage, backup, and security is a lot of manual work.
- **Most tutorials stop at “cluster is up”**: they don’t cover observability, DR, or operational best practices.
- **Teams need repeatable automation**: to rebuild or reset a lab/cluster reliably for training, demos, and experimentation.

**This project solves that by:**

- Using **Ansible** to automate end‑to‑end cluster provisioning.
- Bundling **“day‑2” capabilities** (monitoring, storage, backup, DR, self‑healing).
- Providing **guided scripts and documentation** so the cluster can be brought up, verified, and recovered in a structured way.

---

## What This Project Covers

- **Cluster provisioning**
  - 3‑node Kubernetes cluster (1 control plane, 2 workers).
  - Uses `kubeadm` + `containerd` on **Ubuntu 22.04**.
- **Networking & ingress**
  - **Flannel** as CNI for pod networking (VXLAN overlay).
  - **NGINX Ingress Controller** for HTTP/S ingress (Helm; service type LoadBalancer).
- **Monitoring & observability**
  - **Prometheus** for metrics.
  - **Grafana** for dashboards.
  - **Alertmanager** for alerts.
  - Example rules in the monitoring role.
- **Storage**
  - **TrueNAS** for external NFS storage and dynamic PVC provisioning (optional).
- **Backup & disaster recovery**
  - **Velero** for Kubernetes object + volume backups (MinIO or S3) (optional).
  - **etcd snapshot** script for backing up cluster state.
  - DR runbooks in `docs/DISASTER_RECOVERY.md`.
- **Self‑healing demo**
  - **Self‑healing** role: namespace, deployment with health probes, PodDisruptionBudget (optional).
- **Developer / operator experience**
  - Scripts for **guided setup**, verification, and backup.
  - Docs: quick start, setup guide, run guide, troubleshooting, DR.

---

## High‑Level Architecture

### Topology

- **Node 1**: `k8s-cp-1` – control plane (and where Ansible runs Helm/kubectl for cluster add‑ons).
- **Node 2**: `k8s-worker-1` – worker.
- **Node 3**: `k8s-worker-2` – worker.

### Core Components and How They’re Used

- **Kubernetes v1.28+**
  - **Why**: Stable release; modern APIs and ecosystem.
  - **How**: Installed via the `kubernetes` role; orchestrated in `playbooks/site.yml`.

- **containerd**
  - **Why**: CNCF‑standard container runtime for K8s.
  - **How**: Configured in `common` and `kubernetes` roles.

- **Flannel (CNI)**
  - **What**: Pod-to-pod networking across nodes (VXLAN overlay).
  - **How**: `flannel` role applies Flannel manifest from the control plane; see “CNI Installation” in `site.yml`.

- **NGINX Ingress Controller**
  - **Why**: Common ingress solution for HTTP/HTTPS routing.
  - **How**: `ingress-nginx` role adds the Helm repo and runs `helm upgrade -i` (compatible with Helm 3 and 4); uses `kubeconfig_path` for API access.

- **Monitoring stack (Prometheus, Grafana, Alertmanager)**
  - **Why**: Observability for nodes, pods, and cluster; dashboards and alerts.
  - **How**: `monitoring` role uses `helm_repository` and `helm` (kube-prometheus-stack), applies custom Prometheus rules from `files/`.

- **TrueNAS Storage**
  - **What**: External NFS (and optional iSCSI) backend for persistent volumes.
  - **How**: `truenas-storage` role installs NFS provisioner via Helm when `truenas_storage_enabled: true`.

- **Velero**
  - **Why**: Object and volume backup/restore; MinIO or S3.
  - **How**: `velero` role installs Velero and optional MinIO when `velero_enabled: true`; see `docs/DISASTER_RECOVERY.md`.

- **Self‑healing demo**
  - **Why**: Demonstrate health probes and PodDisruptionBudget.
  - **How**: `self-healing` role creates namespace, deployment, and PDB when `self_healing_enabled: true`.

---

## How the Automation Is Structured

### Ansible Layout

- **Inventory & variables**
  - `ansible/inventories/lab/hosts.ini`: defines `k8s_control_plane`, `k8s_workers`, and `k8s_cluster`.
  - `ansible/inventories/lab/group_vars/all.yml`: global config (e.g. `kubeconfig_path`, pod CIDR, Flannel URL, TrueNAS settings, toggles for storage/velero/self-healing).

- **Main playbook**
  - `ansible/playbooks/site.yml` runs in order:
    - **Common** (`common`) on `hosts: all`
    - **Kubernetes** (`kubernetes`) on `hosts: k8s_cluster`
    - **CNI** (`flannel`) on control plane
    - **Ingress** (`ingress-nginx`) on control plane
    - **Monitoring** (`monitoring`) on control plane
    - **Storage** (`truenas-storage`) on `k8s_cluster` – optional via `truenas_storage_enabled`
    - **Backup/DR** (`velero`) on control plane – optional via `velero_enabled`
    - **Security & policies** – placeholder (no roles in minimal deploy)
    - **Demo** (`self-healing`) on control plane – optional via `self_healing_enabled`
    - **Post‑install** – wait for pods, print status

- **Role tags**
  - Run subsets with tags, e.g.:
    - `--tags kubernetes`
    - `--tags cni,flannel,networking`
    - `--tags ingress,nginx`
    - `--tags monitoring,prometheus,grafana`
    - `--tags storage,truenas,nfs`
    - `--tags backup,velero,dr`
    - `--tags demo,self-healing`

### Kubeconfig

- All roles that talk to the cluster (Helm installs, `kubernetes.core.k8s`, `k8s_info`) use **`kubeconfig_path`** (default `/root/.kube/config`) so they run correctly from the control plane.

### Helper Scripts

- **`scripts/setup-control-node.sh`**
  - Prepares the machine where you run Ansible: apt update, Ansible, Helm, kubectl, Python/venv, `kubernetes.core` collection, SSH key if needed.

- **`scripts/setup-cluster-nodes.sh`**
  - Interactive: asks for control plane and worker IPs/users, validates IPs, tests SSH, writes `ansible/inventories/lab/hosts.ini`, copies SSH keys, runs `ansible -m ping`.

- **`scripts/run-project.sh`**
  - Guided run: control node setup → inventory/nodes → playbook → copy kubeconfig → verify cluster.

- **`scripts/copy-kubeconfig.sh`**
  - Copies `/etc/kubernetes/admin.conf` from control plane to local `~/.kube/config` and runs a quick `kubectl get nodes` check.

- **`scripts/verify-cluster.sh`**
  - Lightweight health check: nodes, kube-system pods, Flannel, ingress-nginx, monitoring, storage, Velero namespaces; optional `kubectl top nodes`.

- **`scripts/backup-etcd.sh`**
  - etcd snapshot with retention under `/backup/etcd/` for DR.

- **`scripts/prepare-nodes.sh`**
  - Optional manual node prep (swap, kernel modules, sysctl, containerd, k8s packages) if not using Ansible for that.

- **`scripts/install-collections.sh`**
  - Installs the `kubernetes.core` Ansible collection.

- **`scripts/copy-ssh-keys-to-nodes.sh`**
  - Copies SSH keys to cluster nodes.

- **`scripts/verify-setup.sh`**
  - Verifies environment/setup.

---

## Requirements

### Hardware

- **3 machines** (VMs or physical) with **Ubuntu 22.04**:
  - **RAM**: 8 GB minimum per node recommended.
  - **Disk**: 50 GB per node.
  - **CPU**: 2 vCPUs or more per node.

### Network

- All nodes must be able to reach each other (e.g. same LAN or overlay like ZeroTier).
- **SSH**: Control node must reach all cluster nodes (passwordless SSH recommended; scripts can copy keys).

### Software (control node)

- **OS**: Ubuntu 22.04.
- **Packages** (installed by scripts or manually): Ansible 2.14+, Python 3.8+ with venv, Helm 3+, kubectl (matching target K8s version), Git, OpenSSH client.
- **Ansible**: `kubernetes.core` collection (see `ansible/collections/requirements.yml`).

---

## Key Features (What You Get)

- **End‑to‑end automated cluster**
  - From prepared nodes to a working cluster with one playbook run (or `run-project.sh`).

- **Networking & ingress**
  - **Flannel** CNI (VXLAN).
  - **NGINX Ingress** via Helm (LoadBalancer service).

- **Observability**
  - **Prometheus + Grafana + Alertmanager** (kube-prometheus-stack) with example rules.

- **Storage & backup**
  - **TrueNAS** NFS (optional) for PVCs.
  - **Velero** (optional) for backups to MinIO/S3.
  - **etcd snapshot** script for cluster state.

- **Self‑healing demo**
  - Optional **self-healing** role: deployment with probes and PodDisruptionBudget.

- **Disaster recovery**
  - **docs/DISASTER_RECOVERY.md**: etcd restore, Velero restore, failure scenarios.

- **Flexible & extensible**
  - Toggles in `group_vars/all.yml`:
    - `truenas_storage_enabled`, `velero_enabled`, `self_healing_enabled`.
  - `kubeconfig_path` for all cluster API calls from Ansible.
  - New roles can be added under `ansible/roles/` and wired into `site.yml`.

---

## How to Use This Document

- **New to the project?**  
  Read this overview, then follow **QUICKSTART.md** or **HOW_TO_RUN.md**.
- **Want file-level details?**  
  See **PROJECT_STRUCTURE.md**, **docs/SETUP_GUIDE.md**, **docs/TROUBLESHOOTING.md**, **docs/DISASTER_RECOVERY.md**.
- **Want to extend the project?**  
  Add a new role under `ansible/roles/`, add it to `playbooks/site.yml`, and expose any options in `group_vars/all.yml` or role defaults.
