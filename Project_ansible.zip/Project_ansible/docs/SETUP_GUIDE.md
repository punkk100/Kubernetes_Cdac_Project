# Detailed Setup Guide

This guide provides step-by-step instructions for setting up your Kubernetes cluster on 3 laptops using VMware.

## Prerequisites Checklist

- [ ] 3 laptops with VMware Workstation/Player installed
- [ ] Ubuntu 22.04 LTS ISO downloaded
- [ ] All laptops can reach each other over the network (same WiFi **or via a ZeroTier network**)
- [ ] At least 8GB RAM per laptop
- [ ] 50GB+ free disk space per VM

## Step 1: VMware Setup

### 1.1 Create Ubuntu VMs

On each laptop:

1. Open VMware Workstation/Player
2. Create a new virtual machine
3. Select "Typical" installation
4. Choose "I will install the operating system later"
5. Select "Linux" → "Ubuntu 64-bit"
6. Name: `k8s-cp-1` (Laptop 1), `k8s-worker-1` (Laptop 2), `k8s-worker-2` (Laptop 3)
7. Disk size: 50GB (split into multiple files)
8. Customize hardware:
   - Memory: 4GB minimum (8GB recommended)
   - Processors: 2 cores
   - Network Adapter: Bridged (replicate physical network; if you use ZeroTier, you can instead rely on the ZeroTier adapter and its IPs)

### 1.2 Install Ubuntu

1. Attach Ubuntu 22.04 ISO to VM
2. Start VM and install Ubuntu:
   - Username: `ubuntu` (or your preference)
   - Hostname: Match VM name (`k8s-cp-1`, `k8s-worker-1`, `k8s-worker-2`)
   - Install OpenSSH server when prompted
   - Enable automatic updates (optional)

### 1.3 Configure Network

1. Ensure network adapter is set to "Bridged" **or** that each VM has a reachable **ZeroTier IP** (if you are using a ZeroTier overlay network)
2. After installation, verify IP addresses:
   ```bash
   ip addr show
   ```
3. Note the IP addresses for each VM

### 1.4 Verify Connectivity

From each VM, ping the others:

```bash
# On k8s-cp-1
ping <k8s-worker-1-ip>
ping <k8s-worker-2-ip>

# On k8s-worker-1
ping <k8s-cp-1-ip>
ping <k8s-worker-2-ip>

# On k8s-worker-2
ping <k8s-cp-1-ip>
ping <k8s-worker-1-ip>
```

All pings should succeed.

## Step 2: Prepare Control Node

Choose one VM (typically `k8s-cp-1`) as your control node where you'll run Ansible.

### 2.1 Update System

```bash
sudo apt update
sudo apt upgrade -y
sudo reboot
```

### 2.2 Install Ansible and Python tooling

```bash
sudo apt install -y ansible git openssh-client python3-pip python3-venv
ansible --version
```

### 2.3 Install Helm

```bash
sudo snap install helm --classic
helm version
```

### 2.4 Install kubectl

```bash
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
kubectl version --client
```

### 2.5 Install Kubernetes Collection for Ansible (using virtual environment)

From the project root:

```bash
cd ~/Project_ansible  # or wherever you cloned/copied the project

# Create and activate a Python virtual environment (if not already created)
python3 -m venv .venv
source .venv/bin/activate

# Install Ansible-related Python dependencies into the virtual environment
pip install --upgrade pip
pip install -r requirements.txt

# Install Kubernetes collection for Ansible
ansible-galaxy collection install kubernetes.core
```

> **Note:** Whenever you work with this project’s Python tooling manually, activate the venv first:
> ```bash
> source .venv/bin/activate
> ```

## Step 3: Configure SSH Access

### 3.1 Generate SSH Key

On control node:

```bash
ssh-keygen -t ed25519 -C "k8s-lab" -f ~/.ssh/id_ed25519
# Press Enter to accept default location
# Press Enter twice for no passphrase (or set one)
```

### 3.2 Copy SSH Key to All Nodes

```bash
# Replace <user> and IPs with your values
ssh-copy-id <user>@<k8s-cp-1-ip>
ssh-copy-id <user>@<k8s-worker-1-ip>
ssh-copy-id <user>@<k8s-worker-2-ip>
```

### 3.3 Test SSH Access

```bash
ssh <user>@<k8s-cp-1-ip> hostname
ssh <user>@<k8s-worker-1-ip> hostname
ssh <user>@<k8s-worker-2-ip> hostname
```

All should return their respective hostnames without password prompts.

## Step 4: Configure Project

### 4.1 Clone/Copy Project

```bash
cd ~
# If using git
git clone <your-repo-url> Project_ansible
cd Project_ansible

# Or copy files manually
```

### 4.2 Edit Inventory

Edit `ansible/inventories/lab/hosts.ini`:

```ini
[k8s_control_plane]
k8s-cp-1 ansible_host=192.168.1.10  # Replace with actual IP

[k8s_workers]
k8s-worker-1 ansible_host=192.168.1.11  # Replace with actual IP
k8s-worker-2 ansible_host=192.168.1.12  # Replace with actual IP

[k8s_cluster:children]
k8s_control_plane
k8s_workers

[all:vars]
ansible_user=ubuntu  # Replace with your username
ansible_ssh_private_key_file=~/.ssh/id_ed25519
ansible_python_interpreter=/usr/bin/python3
```

### 4.3 Customize Variables (Optional)

Edit `ansible/inventories/lab/group_vars/all.yml` to adjust:
- Kubernetes version (if defined in role defaults)
- kubeconfig_path (default `/root/.kube/config`)
- Monitoring retention
- Storage settings (TrueNAS, velero, self-healing toggles)

## Step 5: Test Ansible Connectivity

```bash
cd ansible
ansible -i inventories/lab/hosts.ini all -m ping
```

Expected output:
```
k8s-cp-1 | SUCCESS => {...}
k8s-worker-1 | SUCCESS => {...}
k8s-worker-2 | SUCCESS => {...}
```

## Step 6: Deploy Cluster

### 6.1 Guided Wizard (Recommended)

From the project root on the Ubuntu control node:

```bash
chmod +x scripts/run-project.sh
./scripts/run-project.sh
```

This master script will:
- Ensure the control node is prepared
- Configure inventory and SSH connectivity
- Run the Ansible playbook
- Copy kubeconfig
- Run the verification script

### 6.2 Full Deployment (manual)

```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

This will take 15-30 minutes depending on your network speed.

### 6.3 Staged Deployment (Optional)

If you prefer to deploy in stages:

```bash
# 1. System preparation
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags common

# 2. Kubernetes installation
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags kubernetes

# 3. CNI installation
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags cni

# 4. Ingress and load balancing
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags ingress,nginx

# 5. Monitoring
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring

# 6. Storage
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags storage

# 7. Backup and DR
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags backup,velero,dr
```

## Step 7: Verify Installation

### 7.1 Copy kubeconfig

```bash
mkdir -p ~/.kube
scp <user>@<k8s-cp-1-ip>:/etc/kubernetes/admin.conf ~/.kube/config
chmod 600 ~/.kube/config
```

### 7.2 Check Cluster Status

```bash
kubectl get nodes
```

Expected:
```
NAME           STATUS   ROLES           AGE   VERSION
k8s-cp-1       Ready    control-plane   5m    v1.28.0
k8s-worker-1   Ready    <none>          4m    v1.28.0
k8s-worker-2   Ready    <none>          4m    v1.28.0
```

### 7.3 Check Pods

```bash
kubectl get pods -A
```

All pods should be in `Running` state.

## Step 8: Access Services

### 8.1 Grafana

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

Open http://localhost:3000
- Username: `admin`
- Password: (from `group_vars/all.yml`, default: `admin123`)

### 8.2 Prometheus

```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
```

Open http://localhost:9090

## Step 9: Self-Healing Demo (if enabled)

When `self_healing_enabled: true`, the playbook deploys a demo in `self-healing-demo`:

```bash
kubectl get pods -n self-healing-demo
kubectl get svc -n self-healing-demo
```

## Step 10: Test Self-Healing

### 10.1 Pod Recreation

```bash
# Get a pod name
kubectl get pods -n self-healing-demo

# Delete it
kubectl delete pod <pod-name> -n self-healing-demo

# Watch it recreate
kubectl get pods -n self-healing-demo -w
```

### 10.2 Node Failure

1. Stop one worker VM (shutdown or suspend)
2. Wait 2-3 minutes
3. Check pods rescheduling:
   ```bash
   kubectl get pods -A -o wide
   ```

## Troubleshooting

If you encounter issues, see [TROUBLESHOOTING.md](TROUBLESHOOTING.md).

## Next Steps

- Configure additional monitoring dashboards
- Set up backup schedules
- Deploy your applications
- Configure network policies
- Review security settings

