# Quick Deployment Guide - Flannel CNI

## Prerequisites Checklist

- [ ] All nodes are accessible via SSH
- [ ] Ansible is installed on your control machine
- [ ] Inventory file is configured correctly
- [ ] If cluster exists, it has been reset (see below)

## Reset Existing Cluster (If Applicable)

**Run on ALL nodes:**

```bash
# Reset Kubernetes
sudo kubeadm reset -f

# Clean CNI directories
sudo rm -rf /etc/cni/net.d/*
sudo rm -rf /var/lib/cni/*

# Clean iptables
sudo iptables -F && sudo iptables -t nat -F && sudo iptables -t mangle -F && sudo iptables -X
```

## Deploy Cluster with Flannel

```bash
cd d:\Project_ansible\ansible
ansible-playbook -i inventories/lab/hosts.yml playbooks/site.yml
```

## Quick Verification

```bash
# SSH to control plane
ssh <control-plane-ip>

# Check nodes (all should be Ready)
kubectl get nodes

# Check Flannel pods (all should be Running)
kubectl get pods -n kube-flannel

# Test pod networking
kubectl run test --image=busybox --command -- sleep 3600
kubectl get pods -o wide
```

## Key Configuration Changes

- **Pod Network CIDR**: `10.244.0.0/16` (Flannel default)
- **CNI**: Flannel (VXLAN backend)
- **Manifest**: Latest from flannel-io/flannel GitHub

## Troubleshooting Quick Commands

```bash
# Check Flannel logs
kubectl logs -n kube-flannel -l app=flannel

# Check node status
kubectl get nodes -o wide

# Check kubelet logs (on node)
journalctl -u kubelet -f

# Restart Flannel
kubectl rollout restart daemonset/kube-flannel-ds -n kube-flannel
```

## Success Indicators

✅ All nodes show `Ready` status  
✅ All Flannel pods are `Running`  
✅ CoreDNS pods are `Running`  
✅ Pods can ping each other across nodes  
✅ DNS resolution works  

## Need Help?

See the full [walkthrough.md](file:///C:/Users/Administrator/.gemini/antigravity/brain/bae7b4d6-7a51-45b5-8651-eaa78047d3b8/walkthrough.md) for detailed instructions and troubleshooting.
