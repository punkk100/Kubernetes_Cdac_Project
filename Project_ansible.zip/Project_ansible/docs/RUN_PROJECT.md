# How to Run This Project - Simple Guide

## 🎯 Overview

This project automates the setup of a 3-node Kubernetes cluster with monitoring, storage, and backup.

## 📋 Prerequisites

- 3 laptops with VMware
- Ubuntu 22.04 VMs (1 per laptop)
- All VMs reachable over the network (same WiFi **or ZeroTier overlay network**)
- SSH access between VMs

## 🚀 Step-by-Step Instructions

### Step 1: Create VMs (15 min)

On each laptop:
1. Create Ubuntu 22.04 VM in VMware
2. Set network to **Bridged** (or use the **ZeroTier IP** if your nodes are on a ZeroTier network)
3. Install Ubuntu with SSH enabled
4. Note the IP address of each VM (physical or ZeroTier)

### Step 2: Run Setup Scripts (5 min)

On your control node (one of the VMs or your laptop):

```bash
# 1. Prepare control node
chmod +x scripts/setup-control-node.sh
./scripts/setup-control-node.sh

# 2. Configure cluster nodes (INTERACTIVE - Enter IPs when prompted)
chmod +x scripts/setup-cluster-nodes.sh
./scripts/setup-cluster-nodes.sh
```

**When running `setup-cluster-nodes.sh`, you'll be asked:**
```
Enter Master Node (Control Plane) Details:
Master Node IP Address: [Enter your master IP, e.g., 192.168.1.10]
Master Node Username [default: ubuntu]: [Press Enter or type username]

Enter Worker Node 1 Details:
Worker Node 1 IP Address: [Enter worker 1 IP, e.g., 192.168.1.11]
Worker Node 1 Username [default: ubuntu]: [Press Enter or type username]

Enter Worker Node 2 Details:
Worker Node 2 IP Address: [Enter worker 2 IP, e.g., 192.168.1.12]
Worker Node 2 Username [default: ubuntu]: [Press Enter or type username]
```

The script will automatically:
- ✅ Test SSH connections
- ✅ Create inventory file
- ✅ Copy SSH keys
- ✅ Verify Ansible connectivity

### Step 3: Deploy Cluster (20-30 min)

You can run from either location:

**From project root:**
```bash
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml
```

**From ansible directory:**
```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

> **Note:** Both methods work - there are `ansible.cfg` files configured in both locations.

**What happens (by default):**
- Prepares all nodes
- Installs Kubernetes
- Sets up networking (Flannel)
- Installs Ingress NGINX
- Installs Monitoring (Prometheus, Grafana)
- Installs Storage (TrueNAS NFS)
- Installs Backup (Velero)

> To skip optional components, set `truenas_storage_enabled: false`, `velero_enabled: false`, or `self_healing_enabled: false` in `ansible/inventories/lab/group_vars/all.yml` as needed.

**Wait for completion** - This takes 20-30 minutes.

### Step 4: Verify Installation (2 min)

```bash
# Copy kubeconfig
./scripts/copy-kubeconfig.sh ubuntu@<master-ip>

# Verify cluster
./scripts/verify-cluster.sh
```

You should see all nodes as `Ready`:
```
NAME           STATUS   ROLES           AGE   VERSION
k8s-cp-1       Ready    control-plane   5m    v1.28.0
k8s-worker-1   Ready    <none>          4m    v1.28.0
k8s-worker-2   Ready    <none>          4m    v1.28.0
```

### Step 5: Access Services

#### Grafana (Monitoring Dashboard)
```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```
Open: http://localhost:3000
- Username: `admin`
- Password: `admin123` (or check `ansible/inventories/lab/group_vars/all.yml`)

#### Prometheus (Metrics)
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
```
Open: http://localhost:9090

## 📝 Quick Reference

### Essential Commands

```bash
# Test connectivity
ansible -i ansible/inventories/lab/hosts.ini all -m ping

# Deploy cluster
cd ansible && ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml

# Check cluster status
kubectl get nodes
kubectl get pods -A

# Access Grafana
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

### Common Tasks

**Self-healing demo (deployed by playbook when `self_healing_enabled: true`):**
```bash
kubectl get pods -n self-healing-demo
kubectl get svc -n self-healing-demo
```

**Test self-healing:**
```bash
kubectl delete pod <pod-name> -n self-healing-demo
kubectl get pods -n self-healing-demo -w
```

**View all resources:**
```bash
kubectl get all -A
```

## 🐛 Troubleshooting

**Workers failed to join (cluster-info / join errors)?**
```bash
ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags k8s,cni
```
See [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for details.

**kubectl on workers: "connection refused" (localhost:8080)?**  
Use `kubectl` from the **control plane** (or after copying kubeconfig to your machine). Workers do not run the API server.

**Nodes not ready?**
```bash
kubectl get pods -n kube-flannel
```

**Can't connect via Ansible?**
```bash
ansible -i ansible/inventories/lab/hosts.ini all -m ping
```

**Need more help?**
- See [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) (join, cluster-info, reset workers, kubectl)
- See [HOW_TO_RUN.md](HOW_TO_RUN.md) for detailed guide

## ✅ Success Checklist

- [ ] All 3 VMs created and on same network
- [ ] Control node setup script completed
- [ ] Cluster nodes configured (inventory created)
- [ ] Ansible connectivity test passed
- [ ] Cluster deployment completed
- [ ] All nodes show as Ready
- [ ] Can access Grafana dashboard
- [ ] Self-healing demo running (if enabled): `kubectl get pods -n self-healing-demo`

## 🎉 You're Done!

Your Kubernetes cluster is now running with:
- ✅ Monitoring (Prometheus + Grafana)
- ✅ Ingress and Load Balancing
- ✅ Storage (TrueNAS)
- ✅ Backup (Velero)
- ✅ Self-healing capabilities

## Next Steps

1. Deploy your applications
2. Configure custom dashboards
3. Set up additional alerts
4. Test backup and restore
5. Review security settings

---

**For detailed instructions, see [HOW_TO_RUN.md](HOW_TO_RUN.md).**  
**Troubleshooting (join, cluster-info, reset workers): [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)**

