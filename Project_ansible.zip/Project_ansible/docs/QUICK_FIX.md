# Quick Fix Guide - Collection Installation Error

If you see: `ERROR! couldn't resolve module/action 'kubernetes.core.k8s_info'`

## Quick Fix (Run on Control Node)

```bash
cd /home/ubuntu1/Desktop/Project_ansible

# Option 1: Use the install script
chmod +x scripts/install-collections.sh
./scripts/install-collections.sh

# Option 2: Manual installation
mkdir -p ansible/collections
ansible-galaxy collection install kubernetes.core -p ansible/collections

# Verify it's installed
ls -la ansible/collections/ansible_collections/kubernetes/core/

# Then re-run
./scripts/run-project.sh
```

## If Still Failing

1. **Check ansible.cfg paths:**
   ```bash
   # From project root, ansible.cfg should have:
   # collections_path = ansible/collections
   
   # From ansible/ directory, ansible.cfg should have:
   # collections_path = collections
   ```

2. **Verify collection location:**
   ```bash
   # Collection should be at:
   ansible/collections/ansible_collections/kubernetes/core/
   ```

3. **Re-run Step 1:**
   ```bash
   rm -f .state_control_node_ready
   ./scripts/run-project.sh
   # Step 1 -> y
   ```

4. **Check virtual environment:**
   ```bash
   source .venv/bin/activate
   ansible-galaxy collection list
   ```

## Common Issues

- **Wrong path**: Make sure you're running from project root
- **Collection not installed**: Run `./scripts/install-collections.sh`
- **Virtual env issue**: Re-run Step 1 to recreate venv
