# Troubleshooting Guide

Common issues and solutions for the Kubernetes cluster setup.

## General Issues

### Ansible Connection Failures

**Problem:** `ansible -m ping` fails with connection errors.

**Solutions:**
1. Verify SSH access manually:
   ```bash
   ssh <user>@<node-ip>
   ```

2. Check SSH key is copied:
   ```bash
   ssh-copy-id <user>@<node-ip>
   ```

3. Verify inventory file has correct IPs and username

4. Check firewall rules:
   ```bash
   sudo ufw allow 22/tcp
   ```

### Nodes Not Ready

**Problem:** `kubectl get nodes` shows nodes as `NotReady`.

**Solutions:**
1. Check CNI pods:
   ```bash
   kubectl get pods -n kube-flannel
   ```

2. If Flannel pods are not running:
   ```bash
   kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml
   ```

3. Check kubelet status:
   ```bash
   sudo systemctl status kubelet
   sudo journalctl -u kubelet -f
   ```

4. Verify network connectivity between nodes:
   ```bash
   ping <other-node-ip>
   ```

### kubectl on Workers: "connection refused" (localhost:8080)

**Problem:** When you SSH to a worker and run `kubectl get pods`, you see:
```
The connection to the server localhost:8080 was refused
```

**Explanation:** Workers do not run the API server. Without a kubeconfig, `kubectl` defaults to `http://localhost:8080`, so it fails.

**Solutions:**
1. **Use kubectl from the control plane** (recommended): SSH to the control plane node and run `kubectl` there. The playbook configures `/root/.kube/config` on the control plane.
2. **Copy kubeconfig to your local machine:** Use `scripts/copy-kubeconfig.sh` to copy admin.conf from the control plane to the machine where you run `kubectl` (e.g. your laptop).
3. **(Optional)** Copy admin.conf to workers for `kubectl` there: Copy `/etc/kubernetes/admin.conf` from the control plane to each worker (e.g. `/root/.kube/config`) and set `KUBECONFIG` or use `kubectl --kubeconfig=...`.

### Pods Stuck in Pending

**Problem:** Pods remain in `Pending` state.

**Solutions:**
1. Check pod events:
   ```bash
   kubectl describe pod <pod-name> -n <namespace>
   ```

2. Check node resources:
   ```bash
   kubectl describe node <node-name>
   ```

3. Check for taints:
   ```bash
   kubectl get nodes -o custom-columns=NAME:.metadata.name,TAINTS:.spec.taints
   ```

4. Remove master taint (if needed):
   ```bash
   kubectl taint nodes --all node-role.kubernetes.io/control-plane-
   ```

## Kubernetes Installation Issues

### kubeadm init Fails

**Problem:** `kubeadm init` fails with preflight errors.

**Solutions:**
1. Check swap is disabled:
   ```bash
   sudo swapoff -a
   free -h
   ```

2. Verify kernel modules:
   ```bash
   lsmod | grep br_netfilter
   lsmod | grep overlay
   ```

3. Check sysctl settings:
   ```bash
   sysctl net.bridge.bridge-nf-call-iptables
   sysctl net.ipv4.ip_forward
   ```

4. Reset and retry:
   ```bash
   sudo kubeadm reset -f
   sudo kubeadm init --pod-network-cidr=10.244.0.0/16
   ```

### Worker Nodes Can't Join

**Problem:** Worker nodes fail to join the cluster.

**Solutions:**
1. **"configmaps 'cluster-info' not found" or "forbidden"**
   The playbook ensures the `cluster-info` ConfigMap and RBAC exist by running `kubeadm init phase bootstrap-token` and applying `cluster-info-rbac.yaml` on the control plane. If you see these errors:
   - **Reset workers** (required after a failed join), then re-run the playbook:
     ```bash
     ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"
     ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags k8s,cni
     ```
   - On the control plane, ensure cluster-info exists:
     ```bash
     kubectl -n kube-public get configmap cluster-info
     ```
   - Manually run bootstrap-token phase if needed:
     ```bash
     sudo kubeadm init phase bootstrap-token --kubeconfig=/root/.kube/config --skip-token-print
     ```

2. Verify join command:
   ```bash
   # On control plane
   kubeadm token create --print-join-command
   ```

3. Check token expiration:
   ```bash
   kubeadm token list
   ```

4. Verify control plane endpoint is reachable:
   ```bash
   # From worker node
   curl -k https://<control-plane-ip>:6443/healthz
   ```

5. Check firewall allows port 6443:
   ```bash
   sudo ufw allow 6443/tcp
   ```

6. **Always reset workers before re-running the playbook after join failures:**
   ```bash
   ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"
   ```

## Networking Issues

### Pods Can't Communicate

**Problem:** Pods on different nodes can't ping each other.

**Solutions:**
1. Check Flannel pods:
   ```bash
   kubectl get pods -n kube-flannel -l app=flannel
   ```

2. Check Flannel logs:
   ```bash
   kubectl logs -n kube-flannel -l app=flannel
   ```

3. Verify pod network CIDR:
   ```bash
   kubectl cluster-info dump | grep -i cidr
   ```

4. Restart Flannel:
   ```bash
   kubectl rollout restart daemonset/kube-flannel-ds -n kube-flannel
   ```

### LoadBalancer / Ingress External IP Pending

**Note:** This project does not include MetalLB. NGINX Ingress is installed with `service.type: LoadBalancer`; in bare-metal or lab environments the External IP may stay `<pending>` until you add a load balancer (e.g. MetalLB) or use NodePort. You can still use Ingress via NodePort or port-forward.

**If you add MetalLB separately** and IPs stay pending:
1. Check MetalLB pods: `kubectl get pods -n metallb-system`
2. Verify IP pool and L2Advertisement: `kubectl get ipaddresspool -n metallb-system`
3. Check MetalLB controller logs: `kubectl logs -n metallb-system -l app=metallb,component=controller`
4. Ensure the IP range does not conflict with your network

## Monitoring Issues

### Grafana Not Accessible

**Problem:** Can't access Grafana UI.

**Solutions:**
1. Check Grafana pod:
   ```bash
   kubectl get pods -n monitoring -l app.kubernetes.io/name=grafana
   ```

2. Check service:
   ```bash
   kubectl get svc -n monitoring -l app.kubernetes.io/name=grafana
   ```

3. Port-forward directly:
   ```bash
   kubectl port-forward -n monitoring deployment/monitoring-grafana 3000:3000
   ```

4. Check logs:
   ```bash
   kubectl logs -n monitoring -l app.kubernetes.io/name=grafana
   ```

### Prometheus Not Collecting Metrics

**Problem:** No metrics in Prometheus.

**Solutions:**
1. Check Prometheus pod:
   ```bash
   kubectl get pods -n monitoring -l app.kubernetes.io/name=prometheus
   ```

2. Check service discovery:
   ```bash
   # Port-forward to Prometheus
   kubectl port-forward -n monitoring svc/monitoring-kube-prometheus-prometheus 9090:9090
   # Open http://localhost:9090/targets
   ```

3. Check ServiceMonitor resources:
   ```bash
   kubectl get servicemonitor -A
   ```

## Storage Issues

### TrueNAS NFS Not Working

**Problem:** PVCs can't be created or mounted.

**Solutions:**
1. Check NFS provisioner pods:
   ```bash
   kubectl get pods -n kube-system -l app=nfs-subdir-external-provisioner
   ```

2. Check NFS provisioner logs:
   ```bash
   kubectl logs -n kube-system -l app=nfs-subdir-external-provisioner
   ```

3. Verify storage class:
   ```bash
   kubectl get storageclass
   ```

4. Test NFS connectivity from nodes:
   ```bash
   showmount -e <truenas-ip>
   sudo mount -t nfs <truenas-ip>:/mnt/tank/k8s-storage /mnt/test
   ```

5. Check TrueNAS NFS service:
   - Ensure NFS service is running on TrueNAS
   - Verify export exists and is accessible
   - Check authorized networks include Kubernetes subnet

## Backup Issues

### Velero Not Working

**Problem:** Backups fail or Velero pods crash.

**Solutions:**
1. Check Velero pods:
   ```bash
   kubectl get pods -n velero
   ```

2. Check Velero logs:
   ```bash
   kubectl logs -n velero -l component=velero
   ```

3. Verify backup location:
   ```bash
   velero backup-location get
   ```

4. Test backup manually:
   ```bash
   velero backup create test-backup
   velero backup describe test-backup
   ```

## Performance Issues

### High Resource Usage

**Problem:** Cluster is slow or nodes are resource-constrained.

**Solutions:**
1. Check node resources:
   ```bash
   kubectl top nodes
   kubectl top pods -A
   ```

2. Reduce monitoring retention:
   ```bash
   # Edit monitoring values
   helm upgrade monitoring prometheus-community/kube-prometheus-stack \
     -n monitoring \
     --set prometheus.prometheusSpec.retention=7d
   ```

3. Limit resource requests/limits for pods

4. Consider adding more nodes or resources

## Common Commands

### Reset Cluster

**Full reset (all nodes):**
```bash
# On each node
sudo kubeadm reset -f
sudo rm -rf /etc/cni/net.d
sudo rm -rf /var/lib/etcd
sudo rm -rf ~/.kube
```

**Reset only workers (e.g. before re-running playbook after join failures):**
```bash
ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"
```

### Clean Up Ansible Run

```bash
# Remove failed state
rm -f *.retry
```

### View All Resources

```bash
kubectl get all -A
```

### Check Events

```bash
kubectl get events -A --sort-by='.lastTimestamp'
```

## Getting Help

1. Check logs:
   ```bash
   kubectl logs <pod-name> -n <namespace>
   ```

2. Describe resources:
   ```bash
   kubectl describe <resource-type> <resource-name> -n <namespace>
   ```

3. Check cluster info:
   ```bash
   kubectl cluster-info dump
   ```

4. Review Ansible playbook output for errors

5. Check system logs:
   ```bash
   sudo journalctl -u kubelet -f
   ```

