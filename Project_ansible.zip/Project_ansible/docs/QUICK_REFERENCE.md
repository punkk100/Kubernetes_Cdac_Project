# Quick Reference - Ingress & Monitoring Access

## 🚀 Quick Start

### Deploy
```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

### Verify
```bash
chmod +x scripts/verify-ingress-monitoring.sh
./scripts/verify-ingress-monitoring.sh
```

---

## 📊 Access Services

### Get NodePort & Node IP
```bash
# Get NodePort (look for 'http' port)
kubectl get svc -n ingress-nginx ingress-nginx-controller

# Get Node IP (use any node)
kubectl get nodes -o wide
```

### Grafana
```bash
# Method 1: Port-forward (easiest)
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# → http://localhost:3000

# Method 2: NodePort (no DNS)
# → http://<node-ip>:<nodeport>/grafana

# Method 3: Hostname (add to /etc/hosts: <node-ip> grafana.local)
# → http://grafana.local:<nodeport>

# Login: admin / admin123
```

### Prometheus
```bash
# Method 1: Port-forward
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
# → http://localhost:9090

# Method 2: NodePort
# → http://<node-ip>:<nodeport>/prometheus

# Method 3: Hostname (add to /etc/hosts: <node-ip> prometheus.local)
# → http://prometheus.local:<nodeport>
```

### Alertmanager
```bash
# Method 1: Port-forward
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-alertmanager 9093:9093
# → http://localhost:9093

# Method 2: NodePort
# → http://<node-ip>:<nodeport>/alertmanager

# Method 3: Hostname (add to /etc/hosts: <node-ip> alertmanager.local)
# → http://alertmanager.local:<nodeport>
```

---

## 🔍 Quick Checks

### Ingress NGINX
```bash
kubectl get pods -n ingress-nginx
kubectl get svc -n ingress-nginx
```

### Monitoring Stack
```bash
kubectl get pods -n monitoring
kubectl get svc -n monitoring
kubectl get ingress -n monitoring
```

### All Components
```bash
./scripts/verify-ingress-monitoring.sh
```

---

## 🛠️ Troubleshooting

### View Logs
```bash
# Ingress NGINX
kubectl logs -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx

# Prometheus
kubectl logs -n monitoring prometheus-monitoring-kube-prometheus-prometheus-0

# Grafana
kubectl logs -n monitoring -l app.kubernetes.io/name=grafana
```

### Restart Services
```bash
# Ingress
kubectl rollout restart deployment -n ingress-nginx ingress-nginx-controller

# Grafana
kubectl rollout restart deployment -n monitoring monitoring-grafana

# Prometheus (will cause brief downtime)
kubectl delete pod -n monitoring prometheus-monitoring-kube-prometheus-prometheus-0
```

### Check Ingress Routing
```bash
kubectl get ingress -n monitoring
kubectl describe ingress -n monitoring grafana-ingress
```

---

## 📁 Key Files

### Configuration
- **Group vars:** `ansible/inventories/lab/group_vars/all.yml`
- **Ingress role:** `ansible/roles/ingress-nginx/tasks/main.yml`
- **Monitoring role:** `ansible/roles/monitoring/tasks/main.yml`
- **Monitoring defaults:** `ansible/roles/monitoring/defaults/main.yml`

### Ingress Resources
- **Grafana:** `ansible/roles/monitoring/files/grafana-ingress.yaml`
- **Prometheus:** `ansible/roles/monitoring/files/prometheus-ingress.yaml`
- **Alertmanager:** `ansible/roles/monitoring/files/alertmanager-ingress.yaml`

### Documentation
- **Fix details:** `INGRESS_MONITORING_FIXES.md`
- **Analysis:** `PROJECT_ANALYSIS_SUMMARY.md`
- **Summary:** `PROJECT_FIX_SUMMARY.md`
- **Main README:** `README.md`

---

## ⚙️ Configuration Variables

### Monitoring Defaults
```yaml
# File: ansible/roles/monitoring/defaults/main.yml
prometheus_retention: "30d"
grafana_admin_password: "admin123"
ingress_enabled: true
```

### Group Variables
```yaml
# File: ansible/inventories/lab/group_vars/all.yml
kubeconfig_path: /root/.kube/config
pod_network_cidr: "10.244.0.0/16"
service_cidr: "10.96.0.0/12"
```

---

## 🎯 Common Tasks

### Change Grafana Password
```yaml
# Edit: ansible/roles/monitoring/defaults/main.yml
grafana_admin_password: "YourNewPassword"

# Redeploy monitoring
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring
```

### Disable Ingress Resources
```yaml
# Edit: ansible/roles/monitoring/defaults/main.yml
ingress_enabled: false

# Redeploy monitoring
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring
```

### Check Prometheus Targets
```bash
# Port-forward to Prometheus
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090

# Open: http://localhost:9090/targets
```

### Import Grafana Dashboard
1. Login to Grafana
2. Click '+' → Import
3. Enter dashboard ID:
   - **9614** - Nginx Ingress Controller
   - **13770** - Kubernetes Cluster Monitoring
   - **12114** - Kubernetes Apiserver

---

## 📊 Useful Dashboards

### Pre-installed (included with kube-prometheus-stack)
- Kubernetes / Compute Resources / Cluster
- Kubernetes / Compute Resources / Namespace
- Kubernetes / Compute Resources / Pod
- Node Exporter / Nodes
- Prometheus / Overview

### Community Dashboards to Import
- **9614** - Nginx Ingress Controller
- **13770** - Kubernetes Cluster Monitoring (comprehensive)
- **12114** - Kubernetes Apiserver
- **8588** - Kubernetes Deployment Statefulset Daemonset metrics
- **6417** - Kubernetes Cluster Overview

---

## 🔐 Security Notes

### Production Checklist
- [ ] Change Grafana admin password
- [ ] Enable TLS for Ingress
- [ ] Configure OAuth/LDAP authentication
- [ ] Implement NetworkPolicies
- [ ] Restrict access to monitoring namespace
- [ ] Set up backup for Prometheus data

### Quick Security Fix
```yaml
# Change password before deployment
# File: ansible/roles/monitoring/defaults/main.yml
grafana_admin_password: "$(openssl rand -base64 32)"
```

---

## 📞 Support

### Documentation
- [INGRESS_MONITORING_FIXES.md](INGRESS_MONITORING_FIXES.md) - Detailed technical guide
- [PROJECT_ANALYSIS_SUMMARY.md](PROJECT_ANALYSIS_SUMMARY.md) - Complete analysis
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) - General troubleshooting
- [VERIFICATION.md](VERIFICATION.md) - Component verification

### Verification Script
```bash
./scripts/verify-ingress-monitoring.sh
```

### Logs
```bash
# Ansible logs (if using run-project.sh)
cat /tmp/ansible-playbook-*.log

# Kubernetes events
kubectl get events -A --sort-by='.lastTimestamp'

# Pod logs
kubectl logs -n <namespace> <pod-name>
```

---

**Status:** ✅ All components fully working and documented

**Last Updated:** $(date)
