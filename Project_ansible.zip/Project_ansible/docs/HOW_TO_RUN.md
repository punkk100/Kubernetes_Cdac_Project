# How to Run This Project

Complete step-by-step guide to deploy your Kubernetes cluster.

## Prerequisites Checklist

Before starting, ensure you have:

- [ ] 3 laptops with VMware Workstation/Player installed
- [ ] Ubuntu 22.04 LTS ISO downloaded
- [ ] All laptops can reach each other over the network (same WiFi **or via a ZeroTier network**)
- [ ] At least 8GB RAM per laptop
- [ ] 50GB+ free disk space per VM

> **Platform note:** All scripts and playbooks are designed and tested for **Ubuntu 22.04** on both the control node and all cluster nodes.

## Step-by-Step Guide

### Step 1: Create Ubuntu VMs (15 minutes)

On each laptop:

1. **Open VMware** and create a new virtual machine
2. **Select "Typical"** installation
3. **Choose "I will install the operating system later"**
4. **Select Linux → Ubuntu 64-bit**
5. **Name your VMs:**
   - Laptop 1: `k8s-cp-1` (Control Plane)
   - Laptop 2: `k8s-worker-1` (Worker Node)
   - Laptop 3: `k8s-worker-2` (Worker Node)
6. **Configure hardware:**
   - Memory: 4GB minimum (8GB recommended)
   - Processors: 2 cores
   - **Network Adapter: Bridged** (Important if using local LAN; if you use ZeroTier, you can rely on the ZeroTier virtual NIC and its IPs)
   - Disk: 50GB
7. **Install Ubuntu 22.04:**
   - Attach Ubuntu ISO
   - Install with username `ubuntu` (or your preference)
   - **Enable OpenSSH server** during installation
   - Complete installation

### Step 2: Configure Network (5 minutes)

1. **Verify bridged networking** is enabled for all VMs
2. **Get IP addresses** from each VM:
   ```bash
   ip addr show
   ```
3. **Test connectivity** between VMs:
   ```bash
   # From each VM, ping the others
   ping <other-vm-ip>
   ```
   All pings should succeed.

### Step 3: Set Hostnames (2 minutes)

On each VM, set the hostname:

```bash
# On Laptop 1 VM
sudo hostnamectl set-hostname k8s-cp-1

# On Laptop 2 VM
sudo hostnamectl set-hostname k8s-worker-1

# On Laptop 3 VM
sudo hostnamectl set-hostname k8s-worker-2
```

### Step 4: Prepare Control Node (10 minutes)

Choose one VM (typically `k8s-cp-1`) as your control node where you'll run Ansible.

#### Option A: Automated Setup (Recommended)

```bash
# Copy project to control node (or clone if using git)
cd /path/to/Project_ansible

# Run setup script
chmod +x scripts/setup-control-node.sh
./scripts/setup-control-node.sh
```

#### Option B: Manual Setup (with virtual environment)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Ansible and Python tooling
sudo apt install -y ansible git openssh-client python3-pip python3-venv

# Install Helm
sudo snap install helm --classic

# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Create and activate a Python virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install Python dependencies into the virtual environment
pip install --upgrade pip
pip install -r requirements.txt

# Install Kubernetes collection
ansible-galaxy collection install kubernetes.core

# Generate SSH key (if not exists)
ssh-keygen -t ed25519 -C "k8s-lab" -f ~/.ssh/id_ed25519
```

### Step 5: Configure Cluster Nodes (5 minutes)

Use the interactive setup script to configure your cluster:

```bash
cd /path/to/Project_ansible
chmod +x scripts/setup-cluster-nodes.sh
./scripts/setup-cluster-nodes.sh
```

The script will:
1. Prompt for master node IP and username
2. Prompt for worker node 1 IP and username
3. Prompt for worker node 2 IP and username
4. Test SSH connections
5. Create/update inventory file
6. Copy SSH keys to all nodes
7. Test Ansible connectivity

**Example interaction:**
```
Enter Master Node (Control Plane) Details:
Master Node IP Address: 192.168.1.10
Master Node Username [default: ubuntu]: ubuntu

Enter Worker Node 1 Details:
Worker Node 1 IP Address: 192.168.1.11
Worker Node 1 Username [default: ubuntu]: ubuntu

Enter Worker Node 2 Details:
Worker Node 2 IP Address: 192.168.1.12
Worker Node 2 Username [default: ubuntu]: ubuntu
```

**Alternative: Manual Configuration**

If you prefer to configure manually, edit the inventory file:

```bash
nano ansible/inventories/lab/hosts.ini
```

Update with your IPs:
```ini
[k8s_control_plane]
k8s-cp-1 ansible_host=192.168.1.10

[k8s_workers]
k8s-worker-1 ansible_host=192.168.1.11
k8s-worker-2 ansible_host=192.168.1.12

[all:vars]
ansible_user=ubuntu
ansible_ssh_private_key_file=~/.ssh/id_ed25519
```

Then copy SSH keys manually:
```bash
ssh-copy-id ubuntu@192.168.1.10
ssh-copy-id ubuntu@192.168.1.11
ssh-copy-id ubuntu@192.168.1.12
```

### Step 6: Test Ansible Connectivity (1 minute)

```bash
cd ansible
ansible -i inventories/lab/hosts.ini all -m ping
```

Expected output:
```
k8s-cp-1 | SUCCESS => {...}
k8s-worker-1 | SUCCESS => {...}
k8s-worker-2 | SUCCESS => {...}
```

If you see `SUCCESS` for all nodes, you're ready to deploy!

### Step 7: (Optional) Customize Configuration

Edit variables if needed:

```bash
nano ansible/inventories/lab/group_vars/all.yml
```

Common customizations:
- Kubernetes version
- (Optional) TrueNAS NFS server and path; storage/velero/self-healing toggles
- Monitoring retention period
- Storage settings

### Step 8: Deploy the Cluster (20-30 minutes)

#### Option A: Guided Wizard (Recommended)

On the Ubuntu control node you can run the master script:

```bash
cd /path/to/Project_ansible
chmod +x scripts/run-project.sh
./scripts/run-project.sh
```

This will:
- Prepare the control node
- Configure inventory and SSH access
- Run the main Ansible playbook
- Copy kubeconfig
- Run the verification checks

#### Option B: Full Deployment (manual)

You can run the playbook from either location:

**From project root:**
```bash
cd /path/to/Project_ansible
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml
```

**From ansible directory (also works):**
```bash
cd /path/to/Project_ansible/ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

> **Note:** Both methods work because there are `ansible.cfg` files in both locations configured with the correct paths.

This will (by default):
1. Prepare all nodes (disable swap, configure kernel)
2. Install Kubernetes on all nodes
3. Initialize control plane
4. Ensure bootstrap-token / cluster-info (for join discovery), then join worker nodes
5. Install Flannel CNI
6. Install Ingress NGINX
7. Install Monitoring stack (Prometheus, Grafana)
8. Install TrueNAS storage (if `truenas_storage_enabled: true`)
9. Install Velero backup (if `velero_enabled: true`)
10. Deploy self-healing demo (if `self_healing_enabled: true`)

**Expected time:** 20-30 minutes depending on network speed.

#### Staged Deployment (Optional)

If you prefer to deploy in stages:

```bash
cd ansible

# 1. System preparation
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags common

# 2. Kubernetes installation
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags kubernetes

# 3. CNI installation
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags cni

# 4. Ingress and load balancing
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags ingress,nginx

# 5. Monitoring
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring

# 6. Storage
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags storage

# 7. Backup and DR
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags backup,velero,dr
```

### Step 9: Verify Installation (5 minutes)

#### Copy kubeconfig

```bash
# From control node
./scripts/copy-kubeconfig.sh ubuntu@<master-ip>

# Or manually
mkdir -p ~/.kube
scp ubuntu@<master-ip>:/etc/kubernetes/admin.conf ~/.kube/config
chmod 600 ~/.kube/config
```

#### Verify Cluster

```bash
# Run verification script
./scripts/verify-cluster.sh

# Or manually check
kubectl get nodes
kubectl get pods -A
```

Expected output:
```
NAME           STATUS   ROLES           AGE   VERSION
k8s-cp-1       Ready    control-plane   5m    v1.28.0
k8s-worker-1   Ready    <none>          4m    v1.28.0
k8s-worker-2   Ready    <none>          4m    v1.28.0
```

All nodes should show `Ready` status.

### Step 10: Access Services

#### Grafana (Monitoring Dashboard)

```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```

Open browser: http://localhost:3000
- Username: `admin`
- Password: Check `ansible/inventories/lab/group_vars/all.yml` (default: `admin123`)

#### Prometheus (Metrics)

```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
```

Open browser: http://localhost:9090

#### TrueNAS Storage

```bash
# Access TrueNAS web UI directly at:
# http://<truenas-ip>
```

### Step 11: Self-Healing Demo (if enabled)

When `self_healing_enabled: true`, the playbook deploys a demo in namespace `self-healing-demo`:

```bash
kubectl get pods -n self-healing-demo
kubectl get svc -n self-healing-demo
```

### Step 12: Test Self-Healing

#### Test Pod Recreation

```bash
# Get a pod name
kubectl get pods -n self-healing-demo

# Delete it
kubectl delete pod <pod-name> -n self-healing-demo

# Watch it recreate
kubectl get pods -n self-healing-demo -w
```

#### Test Node Failure

1. Stop one worker VM (suspend or shutdown)
2. Wait 2-3 minutes
3. Check pods rescheduling:
   ```bash
   kubectl get pods -A -o wide
   ```
   Pods should be rescheduled to the remaining worker node.

## Troubleshooting

If you encounter issues:

1. **Check [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** for common issues (join, cluster-info, kubectl on workers, reset).
2. **Workers failed to join** (e.g. "cluster-info not found" / "forbidden"): Reset workers, then re-run:
   ```bash
   ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"
   ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags k8s,cni
   ```
3. **kubectl on workers "connection refused" (localhost:8080):** Use `kubectl` from the **control plane** or after copying kubeconfig to your machine. Workers do not run the API server.
4. **Review Ansible output** for error messages.
5. **Check pod logs:**
   ```bash
   kubectl logs <pod-name> -n <namespace>
   ```
6. **Check node status:**
   ```bash
   kubectl describe node <node-name>
   ```

## Quick Reference Commands

```bash
# Test Ansible connectivity
ansible -i ansible/inventories/lab/hosts.ini all -m ping

# Deploy cluster
cd ansible && ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml

# Check cluster status
kubectl get nodes
kubectl get pods -A

# Access Grafana
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80

# View all resources
kubectl get all -A
```

## Next Steps

After successful deployment:

1. **Deploy your applications**
2. **Configure custom monitoring dashboards**
3. **Set up additional alerts**
4. **Test backup and restore procedures**
5. **Review security settings**

## Support

- **Documentation:** See `docs/` directory
- **Troubleshooting:** See `docs/TROUBLESHOOTING.md`
- **Quick Start:** See `QUICKSTART.md`

## Summary

**Total time:** ~1 hour (including VM setup)

**Key commands:**
1. `./scripts/setup-cluster-nodes.sh` - Configure nodes
2. `ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml` - Deploy cluster
3. `kubectl get nodes` - Verify cluster

That's it! Your Kubernetes cluster is ready! 🎉

