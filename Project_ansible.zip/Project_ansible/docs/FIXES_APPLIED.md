# Fixes Applied - Complete Project Overhaul

## Summary
This document lists all fixes applied to make the project fully functional.

## Critical Fixes

### 1. Collection Installation (kubernetes.core)
**Problem**: Collection not found when running playbooks
**Fix**:
- Created `ansible/collections/requirements.yml` for collection management
- Enhanced `scripts/setup-control-node.sh` with robust collection installation
- Added automatic collection check/install in `scripts/run-project.sh` Step 3
- Created standalone `scripts/install-collections.sh` for manual installation
- Added verification script `scripts/verify-setup.sh`

**Files Modified**:
- `scripts/setup-control-node.sh`
- `scripts/run-project.sh`
- `ansible/collections/requirements.yml` (new)
- `scripts/install-collections.sh` (new)
- `scripts/verify-setup.sh` (new)

### 2. Dpkg Lock Issues (unattended-upgrades)
**Problem**: dpkg locks preventing package installation
**Fix**:
- Stop and disable `unattended-upgrades` service in common role
- Disable via apt configuration files
- Kill processes holding locks aggressively
- Wait for locks with retries
- Added retry logic to package installation

**Files Modified**:
- `ansible/roles/common/tasks/main.yml`
- `ansible/roles/kubernetes/tasks/main.yml`

### 3. Inventory Auto-Refresh
**Problem**: hosts.ini hardcoded, doesn't adapt to current admin
**Fix**:
- Added `--auto` mode to `setup-cluster-nodes.sh`
- Auto-refreshes inventory on Step 2 if flag exists
- Updates SSH key path to current admin's $HOME
- Re-checks best ansible_user per host

**Files Modified**:
- `scripts/setup-cluster-nodes.sh`
- `scripts/run-project.sh`

### 4. Locale Encoding Issues
**Problem**: Ansible requires UTF-8 locale
**Fix**:
- Added `export LANG=C.UTF-8` and `export LC_ALL=C.UTF-8` to all scripts

**Files Modified**:
- `scripts/setup-control-node.sh`
- `scripts/setup-cluster-nodes.sh`
- `scripts/run-project.sh`

### 5. Kubernetes Role Improvements
**Problem**: Various issues with kubeadm init, join, node readiness
**Fix**:
- Run `kubeadm init phase bootstrap-token` to create `cluster-info` ConfigMap (required for join discovery)
- Apply `cluster-info-rbac.yaml` so unauthenticated clients can read cluster-info
- Join workers via `shell` with `async`/`poll`/`throttle`; fail fast if join fails
- "Wait for node" checks **registered** only (delegate to control plane, `kubectl get node`), not Ready (CNI install is later)
- Added wait tasks before package operations and retry logic

**Files Modified**:
- `ansible/roles/kubernetes/tasks/main.yml`
- `ansible/roles/kubernetes/files/cluster-info-rbac.yaml` (new)

### 6. Missing Variables
**Problem**: `control_plane_endpoint` and `calico_manifest_url` undefined
**Fix**:
- Added variables to `ansible/inventories/lab/group_vars/all.yml`

**Files Modified**:
- `ansible/inventories/lab/group_vars/all.yml`

### 7. CNI Migration: Calico → Flannel
**Problem**: Nodes experiencing join issues with Calico CNI; complex BGP configuration causing network problems
**Fix**:
- Migrated from Calico to Flannel CNI for simpler, more reliable networking
- Changed pod network CIDR from `192.168.0.0/16` to `10.244.0.0/16` (Flannel default)
- Created new `flannel` role with VXLAN overlay networking
- Removed `calico` role entirely
- Updated all documentation to reference Flannel
- Flannel uses VXLAN which works across NAT and complex network topologies

**Benefits**:
- Simpler configuration (no BGP)
- Better compatibility across network types
- Easier troubleshooting
- Faster deployment
- More reliable node joining

**Files Modified**:
- `ansible/inventories/lab/group_vars/all.yml` (pod_network_cidr, manifest URL)
- `ansible/playbooks/site.yml` (role reference)
- `ansible/roles/kubernetes/defaults/main.yml` (cni_plugin)
- `ansible/roles/flannel/` (new role created)
- `ansible/roles/calico/` (deleted)
- All documentation files updated (README, QUICKSTART, PROJECT_OVERVIEW, etc.)

### 8. Storage Migration: Longhorn → TrueNAS
**Problem**: Longhorn distributed storage consumes significant node resources and adds complexity
**Fix**:
- Migrated from Longhorn to TrueNAS NFS external storage
- Created new `truenas-storage` role with NFS provisioner
- Removed `longhorn` role entirely
- Updated all documentation to reference TrueNAS
- Changed storage play to run on all nodes (for NFS client installation)
- Uses nfs-subdir-external-provisioner for dynamic provisioning

**Benefits**:
- Centralized storage management via TrueNAS UI
- No storage overhead on Kubernetes nodes
- Enterprise ZFS features (snapshots, replication, compression)
- ReadWriteMany (RWX) volume support
- Better scalability and data protection

**Files Modified**:
- `ansible/inventories/lab/group_vars/all.yml` (removed Longhorn repo, added TrueNAS config)
- `ansible/playbooks/site.yml` (role reference, changed to k8s_cluster hosts)
- `ansible/roles/truenas-storage/` (new role created)
- `ansible/roles/longhorn/` (deleted)
- All documentation files updated (README, QUICKSTART, PROJECT_OVERVIEW, etc.)

### 9. run-project.sh and Documentation
**Updates**:
- Before playbook run: note to reset workers if join failed previously; link to TROUBLESHOOTING
- On playbook failure: print quick fixes (reset workers, TROUBLESHOOTING)
- Step 4 (kubeconfig): note that kubectl is for control plane / local machine
- Final message: link to TROUBLESHOOTING
- **TROUBLESHOOTING.md**: cluster-info / bootstrap-token, reset workers, kubectl on workers ("connection refused")
- **DEPLOYMENT_CHECKLIST.md**, **HOW_TO_RUN.md**, **RUN_PROJECT.md**, **README.md**: join/reset and kubectl pointers

**Files Modified**:
- `scripts/run-project.sh`
- `docs/TROUBLESHOOTING.md`
- `DEPLOYMENT_CHECKLIST.md`
- `HOW_TO_RUN.md`
- `RUN_PROJECT.md`
- `README.md`

## How to Use

### First Time Setup
```bash
cd /path/to/Project_ansible
chmod +x scripts/*.sh
./scripts/run-project.sh
```

### If Collection Error Occurs
```bash
# Quick fix
./scripts/install-collections.sh

# Or re-run Step 1
rm -f .state_control_node_ready
./scripts/run-project.sh
```

### Verify Setup
```bash
./scripts/verify-setup.sh
```

## Testing Checklist

- [ ] Step 1: Control node setup completes
- [ ] Step 2: Inventory created/refreshed
- [ ] Step 3: Playbook runs without collection errors
- [ ] Step 3: No dpkg lock errors
- [ ] Step 3: Kubernetes packages install successfully
- [ ] Step 3: Control plane initializes
- [ ] Step 3: Workers join cluster
- [ ] Step 4: kubeconfig copied
- [ ] Step 5: Cluster verification passes

## Known Issues Fixed

1. ✅ Collection not found → Auto-installation added
2. ✅ Dpkg locks → unattended-upgrades disabled + aggressive cleanup
3. ✅ Hardcoded inventory → Auto-refresh implemented
4. ✅ Locale errors → UTF-8 enforced
5. ✅ Missing variables → Added to group_vars
6. ✅ kubeadm timeout → Made async
7. ✅ Python library errors → delegate_to localhost

## Project Structure

```
Project_ansible/
├── ansible/
│   ├── ansible.cfg (collections_path = collections)
│   ├── collections/
│   │   ├── requirements.yml
│   │   └── ansible_collections/kubernetes/core/
│   ├── inventories/lab/
│   │   ├── hosts.ini
│   │   └── group_vars/all.yml
│   ├── playbooks/site.yml
│   └── roles/...
├── scripts/
│   ├── run-project.sh (main wizard)
│   ├── setup-control-node.sh
│   ├── setup-cluster-nodes.sh
│   ├── install-collections.sh (new)
│   └── verify-setup.sh (new)
├── ansible.cfg (collections_path = ansible/collections)
└── requirements.txt
```

## Important Notes

1. **Always run from project root** - The root `ansible.cfg` has correct paths
2. **Collections must be in** `ansible/collections/ansible_collections/kubernetes/core/`
3. **Virtual environment** is in `.venv/` - Step 1 creates it
4. **State flags** prevent re-running steps - Delete flags to re-run

## Support

If issues persist:
1. Run `./scripts/verify-setup.sh` to diagnose
2. Check `QUICK_FIX.md` for common issues
3. Re-run Step 1 to reset environment
4. Check logs in `/tmp/ansible_facts` for debugging
