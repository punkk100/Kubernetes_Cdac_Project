# How to Know Everything Is Running and Up

This guide explains **what the playbook runs**, **when each part runs**, and **how to verify** each component.

## What Runs When (Playbook Order)

| Play | Runs when | Tags to run only this |
|------|-----------|------------------------|
| **1. Common** | Always (all nodes) | `common` |
| **2. Kubernetes** | Always (cluster) | `kubernetes`, `k8s` |
| **3. CNI (Flannel)** | Always (control plane) | `cni`, `flannel`, `networking` |
| **4. Ingress NGINX** | Always (control plane) | `ingress`, `nginx` |
| **5. Monitoring** (Prometheus, Grafana, Alertmanager) | Always (control plane) | `monitoring`, `prometheus`, `grafana` |
| **6. Storage (TrueNAS)** | Only if `truenas_storage_enabled: true` (default: true) | `storage`, `truenas`, `nfs` |
| **7. Backup (Velero)** | Only if `velero_enabled: true` (default: true) | `backup`, `velero`, `dr` |
| **8. Security and Policies** | Always (no roles in minimal deploy) | — |
| **9. Demo (self-healing)** | Only if `self_healing_enabled: true` (default: true) | `demo`, `self-healing` |
| **10. Post-installation** | Always (control plane) | — |

Toggles are in **`ansible/inventories/lab/group_vars/all.yml`**:
- `truenas_storage_enabled: true/false`
- `velero_enabled: true/false`
- `self_healing_enabled: true/false`

If you ran the playbook **with tags** (e.g. only `--tags ingress,nginx`), then **only those plays ran**. Monitoring, TrueNAS, demo, and post-install would not have run.

---

## One-Command Verification

From a host that has `kubectl` and kubeconfig (e.g. control plane or after copying kubeconfig):

```bash
./scripts/verify-cluster.sh
```

This checks nodes, system pods, Flannel, ingress, monitoring, storage, Velero, and (optionally) the demo app.

---

## Check Each Component Manually

Run these **after** copying kubeconfig from the control plane (e.g. `./scripts/copy-kubeconfig.sh user@<control-plane-ip>`).

### 1. Nodes

```bash
kubectl get nodes
```

All should show `Ready`.

### 2. System pods (Kubernetes core)

```bash
kubectl get pods -n kube-system
```

CoreDNS, etcd, kube-apiserver, kube-controller-manager, kube-scheduler, kube-proxy should be `Running`.

### 3. CNI (Flannel)

```bash
kubectl get pods -n kube-flannel
```

One Flannel pod per node, all `Running`.

### 4. Ingress NGINX

```bash
kubectl get pods -n ingress-nginx
kubectl get svc -n ingress-nginx
```

- Pods: `ingress-nginx-controller-*` should be `Running`.
- Service: `ingress-nginx-controller` is type `LoadBalancer`; `EXTERNAL-IP` may be `<pending>` on bare metal until you add something like MetalLB (ingress still works via NodePort).

### 5. Monitoring (Prometheus, Grafana, Alertmanager)

```bash
kubectl get pods -n monitoring
```

You should see pods for Prometheus, Grafana, Alertmanager, and the Prometheus Operator. All should become `Running` (may take a few minutes after install).

**If you see no pods or namespace:** the Monitoring play may not have run (e.g. you used `--tags` that excluded it), or it failed (e.g. missing Python `kubernetes` library on the control plane). Run the full playbook or only monitoring:

```bash
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags monitoring,prometheus,grafana
```

**Access Grafana:**  
`kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80` then open http://localhost:3000 (password in monitoring role defaults / group_vars).

**Access Prometheus:**  
`kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090` then open http://localhost:9090.

### 6. Storage (TrueNAS NFS)

```bash
kubectl get pods -n kube-system | grep nfs
# or
kubectl get storageclass
```

If TrueNAS was enabled and NFS is reachable, you should see an NFS provisioner pod and a storage class (e.g. `truenas-nfs`). If the TrueNAS server (e.g. `truenas_nfs_server` in group_vars) is not reachable, the storage role may fail or skip.

### 7. Backup (Velero)

```bash
kubectl get pods -n velero
```

If Velero was enabled, you should see Velero (and optionally MinIO) pods. If the play was skipped (`velero_enabled: false`), the namespace may not exist.

### 8. Demo application (self-healing)

```bash
kubectl get pods -n self-healing-demo
kubectl get pdb -n self-healing-demo
```

If the demo play ran (`self_healing_enabled: true`), you should see a deployment and a PodDisruptionBudget. If the play was skipped, the namespace may not exist.

### 9. Post-installation

Post-installation is an Ansible play that runs at the end of the playbook. It does not create a separate namespace. It:
- Waits for `kube-system` pods (best-effort)
- Prints “Cluster setup complete! Run 'kubectl get nodes' to verify.”

If you see that message at the end of the Ansible run, post-installation ran. There is nothing extra to “check” for post-install beyond cluster health (nodes and pods above).

---

## Run Only What’s Missing

If you ran with limited tags or some plays failed, run the missing parts:

```bash
# From project root
cd ansible  # or use -i ansible/inventories/lab/hosts.ini from root

# Monitoring only (Prometheus, Grafana)
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring,prometheus,grafana

# Storage only (TrueNAS)
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags storage,truenas,nfs

# Backup only (Velero)
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags backup,velero,dr

# Demo only (self-healing)
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags demo,self-healing
```

Or run the **full playbook** (all plays, respecting toggles):

```bash
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml
```

---

## Quick Summary Table

| Component            | Namespace / Where   | Command to check |
|----------------------|---------------------|-------------------|
| Nodes                | —                   | `kubectl get nodes` |
| System pods          | `kube-system`       | `kubectl get pods -n kube-system` |
| Flannel CNI          | `kube-flannel`      | `kubectl get pods -n kube-flannel` |
| Ingress NGINX        | `ingress-nginx`     | `kubectl get pods -n ingress-nginx` |
| Prometheus / Grafana | `monitoring`        | `kubectl get pods -n monitoring` |
| TrueNAS NFS          | `kube-system` + StorageClass | `kubectl get storageclass` |
| Velero               | `velero`            | `kubectl get pods -n velero` |
| Self-healing demo    | `self-healing-demo` | `kubectl get pods -n self-healing-demo` |

If a namespace or resource doesn’t exist, that play was either skipped (toggle or tags) or failed during the run; check the Ansible output and run the corresponding play with the tags above.
