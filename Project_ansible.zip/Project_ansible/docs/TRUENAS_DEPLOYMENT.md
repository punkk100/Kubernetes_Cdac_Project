# TrueNAS Storage - Quick Deployment Guide

## Prerequisites

### 1. TrueNAS Server Setup

**Create NFS Dataset:**
- Storage → Pools → Add Dataset
- Name: `k8s-storage`
- Path: `/mnt/tank/k8s-storage`

**Create NFS Share:**
- Sharing → Unix Shares (NFS) → Add
- Path: `/mnt/tank/k8s-storage`
- Authorized Networks: `10.118.129.0/24` (your Kubernetes subnet)
- Maproot User: `root`
- Maproot Group: `root`

**Enable NFS Service:**
- Services → NFS → Start
- Check "Start Automatically"

**Test NFS Export:**
```bash
showmount -e <truenas-ip>
# Should show: /mnt/tank/k8s-storage
```

---

## Configuration

### Update Variables

Edit `ansible/inventories/lab/group_vars/all.yml`:

```yaml
# TrueNAS Storage Configuration
truenas_storage_enabled: true
storage_backend: "nfs"
truenas_nfs_server: "192.168.1.100"  # YOUR TrueNAS IP
truenas_nfs_path: "/mnt/tank/k8s-storage"  # YOUR NFS export path
```

---

## Deployment

### Remove Longhorn (If Installed)

```bash
# SSH to control plane
ssh <control-plane-ip>

# Uninstall Longhorn
helm uninstall longhorn -n longhorn-system
kubectl delete crd $(kubectl get crd | grep longhorn | awk '{print $1}')
kubectl delete namespace longhorn-system
```

### Deploy TrueNAS Storage

```bash
cd d:\Project_ansible\ansible
ansible-playbook -i inventories/lab/hosts.yml playbooks/site.yml --tags storage,truenas
```

---

## Verification

```bash
# Check StorageClass
kubectl get storageclass

# Check NFS provisioner
kubectl get pods -n kube-system -l app=nfs-subdir-external-provisioner

# Create test PVC
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: test-pvc
spec:
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 1Gi
  storageClassName: truenas-nfs
EOF

# Check PVC status
kubectl get pvc test-pvc
# Should show: Bound
```

---

## Troubleshooting

### NFS Connectivity Test

```bash
# From any Kubernetes node
showmount -e <truenas-ip>
sudo mount -t nfs <truenas-ip>:/mnt/tank/k8s-storage /mnt/test
ls -la /mnt/test
sudo umount /mnt/test
```

### Check Provisioner Logs

```bash
kubectl logs -n kube-system -l app=nfs-subdir-external-provisioner
```

### Common Issues

1. **NFS server unreachable**: Check firewall, network connectivity
2. **Permission denied**: Verify Maproot User/Group set to `root`
3. **Export not found**: Ensure NFS share is created and service is running

---

## Important Notes

⚠️ **Before Deployment:**
- Update `truenas_nfs_server` with your TrueNAS IP
- Update `truenas_nfs_path` with your NFS export path
- Ensure TrueNAS NFS service is running
- Verify network connectivity from all nodes

📊 **After Deployment:**
- Monitor TrueNAS storage usage
- Set dataset quotas to prevent runaway storage
- Configure TrueNAS snapshots for data protection
- Test PVC creation and pod mounting

---

## Documentation

- **Full Walkthrough**: See `truenas_walkthrough.md` in artifacts
- **Role README**: `ansible/roles/truenas-storage/README.md`
- **Implementation Plan**: `truenas_implementation_plan.md` in artifacts
- **Troubleshooting**: `docs/TROUBLESHOOTING.md`

---

## Quick Commands

```bash
# Deploy storage
ansible-playbook -i inventories/lab/hosts.yml playbooks/site.yml --tags storage

# Check status
kubectl get storageclass
kubectl get pods -n kube-system -l app=nfs-subdir-external-provisioner

# Test PVC
kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: test-pvc
spec:
  accessModes: [ReadWriteMany]
  resources:
    requests:
      storage: 1Gi
  storageClassName: truenas-nfs
EOF

# Cleanup test
kubectl delete pvc test-pvc
```

---

**Ready to deploy!** 🚀
