# Project Structure

Complete overview of the project structure and file organization.

```
Project_ansible/
│
├── README.md                          # Main project documentation
├── PROJECT_OVERVIEW.md                # High-level architecture and design
├── PROJECT_STRUCTURE.md              # This file
├── VERIFICATION.md                    # How to know all components are running (checks, tags, toggles)
├── QUICKSTART.md                      # Quick start guide
├── HOW_TO_RUN.md                      # How to run the project
├── RUN_PROJECT.md                     # Run project guide
├── DEPLOYMENT_CHECKLIST.md            # Deployment checklist
├── CONTRIBUTING.md                    # Contribution guidelines
├── LICENSE                            # MIT License
├── requirements.txt                   # Python dependencies (if using venv)
├── ansible.cfg                        # Root Ansible config (optional)
├── .gitignore                         # Git ignore rules
│
├── FIXES_APPLIED.md                   # Applied fixes log
├── FLANNEL_DEPLOYMENT.md              # Flannel CNI notes
├── QUICK_FIX.md                       # Quick fix reference
├── TRUENAS_DEPLOYMENT.md              # TrueNAS storage notes
│
├── ansible/
│   ├── ansible.cfg                    # Ansible config (inventory, SSH, roles path)
│   ├── collections/
│   │   └── requirements.yml           # Ansible collections (kubernetes.core)
│   │
│   ├── inventories/
│   │   └── lab/
│   │       ├── hosts.ini              # Inventory: k8s_control_plane, k8s_workers
│   │       └── group_vars/
│   │           └── all.yml            # Global variables (kubeconfig_path, CNI, storage, etc.)
│   │
│   ├── playbooks/
│   │   └── site.yml                   # Main playbook (orchestrates all roles)
│   │
│   └── roles/
│       ├── common/                    # System preparation (all nodes)
│       │   └── tasks/
│       │       └── main.yml           # Disable auto-updates, swap, kernel modules, sysctl, containerd
│       │
│       ├── kubernetes/                # Kubernetes installation
│       │   ├── defaults/
│       │   │   └── main.yml           # Kubernetes-related defaults
│       │   ├── files/
│       │   │   ├── cluster-info-rbac.yaml
│       │   │   └── kubeadm-config-rbac.yaml
│       │   ├── handlers/
│       │   │   └── main.yml           # Service restart handlers
│       │   └── tasks/
│       │       └── main.yml           # kubeadm, kubelet, kubectl, containerd, init/join
│       │
│       ├── flannel/                    # CNI plugin
│       │   ├── defaults/
│       │   │   └── main.yml           # Flannel defaults (pod_network_cidr, manifest URL)
│       │   ├── README.md             # Flannel role notes
│       │   └── tasks/
│       │       └── main.yml           # Apply Flannel manifest, wait for pods/nodes
│       │
│       ├── ingress-nginx/              # Ingress controller
│       │   └── tasks/
│       │       └── main.yml           # Helm repo, helm upgrade -i NGINX Ingress (LoadBalancer), wait for pods
│       │
│       ├── monitoring/                # Monitoring stack
│       │   ├── defaults/
│       │   │   └── main.yml           # Prometheus retention, Grafana password, etc.
│       │   ├── files/
│       │   │   └── prometheus-rules.yaml
│       │   └── tasks/
│       │       └── main.yml           # Helm repo, namespace, kube-prometheus-stack, wait, apply rules
│       │
│       ├── truenas-storage/           # TrueNAS NFS storage
│       │   ├── defaults/
│       │   │   └── main.yml           # NFS provisioner namespace, storage class, TrueNAS options
│       │   ├── README.md             # TrueNAS role notes
│       │   └── tasks/
│       │       └── main.yml           # NFS/iscsi packages, Helm NFS provisioner, optional iSCSI
│       │
│       ├── velero/                     # Backup and DR
│       │   ├── defaults/
│       │   │   └── main.yml           # Velero schedule, backup location, S3/MinIO options
│       │   ├── files/
│       │   │   └── minio.yaml         # MinIO deployment for local Velero backups
│       │   └── tasks/
│       │       └── main.yml           # Velero binary, namespace, MinIO, install, schedule
│       │
│       └── self-healing/               # Self-healing / PDB demo
│           ├── defaults/
│           │   └── main.yml           # Namespace name, app name
│           ├── files/
│           │   └── pod-disruption-budget.yaml
│           └── tasks/
│               └── main.yml           # Namespace, deployment (nginx), PDB
│
├── scripts/
│   ├── README.md                      # Scripts documentation
│   ├── setup-control-node.sh          # Install Ansible, Helm, kubectl, collections on control node
│   ├── setup-cluster-nodes.sh        # Interactive: IPs, SSH, inventory, copy keys
│   ├── run-project.sh                # Guided wizard: setup → inventory → playbook → kubeconfig → verify
│   ├── copy-kubeconfig.sh            # Copy admin.conf from control plane to local ~/.kube/config
│   ├── copy-ssh-keys-to-nodes.sh     # Copy SSH keys to cluster nodes
│   ├── verify-cluster.sh             # Check nodes, pods, namespaces (kube-system, flannel, ingress, etc.)
│   ├── verify-setup.sh               # Verify environment/setup
│   ├── prepare-nodes.sh              # Manual node prep (swap, modules, sysctl, containerd, k8s packages)
│   ├── install-collections.sh       # Install kubernetes.core collection
│   └── backup-etcd.sh                # etcd snapshot with retention
│
└── docs/
    ├── SETUP_GUIDE.md                # Detailed setup instructions
    ├── TROUBLESHOOTING.md             # Common issues and solutions
    └── DISASTER_RECOVERY.md           # Backup and restore procedures
```

## Key Files Explained

### Configuration Files

- **ansible/ansible.cfg**: Inventory path, SSH settings, roles path, fact caching, stdout callback.
- **ansible/inventories/lab/hosts.ini**: Define cluster nodes (`k8s_control_plane`, `k8s_workers`), IPs, users, SSH key.
- **ansible/inventories/lab/group_vars/all.yml**: Global variables:
  - `kubeconfig_path`: Path to kubeconfig on control plane (used by Helm/k8s modules).
  - System: `swap_off`, `kernel_modules`, `sysctl_settings`.
  - Cluster: `pod_network_cidr`, `service_cidr`, `control_plane_endpoint`.
  - Flannel: `flannel_manifest_url`.
  - TrueNAS: `truenas_storage_enabled`, `storage_backend`, `truenas_nfs_server`, `truenas_nfs_path`.

### Main Playbook

- **ansible/playbooks/site.yml**: Orchestrates all roles in order:
  1. **Common** (hosts: all) – system prep
  2. **Kubernetes** (hosts: k8s_cluster) – kubeadm, containerd, init/join
  3. **Flannel** (hosts: k8s_control_plane) – CNI
  4. **Ingress and Load Balancing** (hosts: k8s_control_plane) – ingress-nginx
  5. **Monitoring** (hosts: k8s_control_plane) – Prometheus, Grafana, Alertmanager
  6. **Storage** (hosts: k8s_cluster) – truenas-storage (when enabled)
  7. **Backup and DR** (hosts: k8s_control_plane) – velero (when enabled)
  8. **Security and Policies** – placeholder (no roles in minimal deploy)
  9. **Demo Applications** (hosts: k8s_control_plane) – self-healing (when enabled)
  10. **Post-installation** – wait for pods, display status

### Roles and Tags

Run subsets with tags:

```bash
# From project root (or set ANSIBLE_CONFIG / -i appropriately)
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags common
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags kubernetes,k8s
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags cni,flannel,networking
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags ingress,nginx
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags monitoring,prometheus,grafana
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags storage,truenas,nfs
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags backup,velero,dr
ansible-playbook -i ansible/inventories/lab/hosts.ini ansible/playbooks/site.yml --tags demo,self-healing
```

### Scripts

- **setup-control-node.sh**: Prepares the machine where you run Ansible (Ansible, Helm, kubectl, Python deps, kubernetes.core).
- **setup-cluster-nodes.sh**: Interactive; prompts for control plane and worker IPs/users, writes inventory, copies SSH keys, tests ping.
- **run-project.sh**: Full guided run (control node → inventory → playbook → kubeconfig → verify).
- **copy-kubeconfig.sh**: Copies `/etc/kubernetes/admin.conf` from control plane to local `~/.kube/config`.
- **verify-cluster.sh**: Lightweight health check (nodes, kube-system, flannel, ingress, monitoring, storage, velero).
- **backup-etcd.sh**: etcd snapshot with retention for DR.

### Documentation

- **README.md**: Overview, quick start, manual steps, configuration, troubleshooting links.
- **PROJECT_OVERVIEW.md**: Architecture, components, automation layout, requirements.
- **QUICKSTART.md**, **HOW_TO_RUN.md**, **RUN_PROJECT.md**: Run guides.
- **docs/SETUP_GUIDE.md**: Detailed setup.
- **docs/TROUBLESHOOTING.md**: Common issues and fixes.
- **docs/DISASTER_RECOVERY.md**: Backup and restore.

## Customization

### Kubeconfig path

Edit `ansible/inventories/lab/group_vars/all.yml` if kubeconfig is not at `/root/.kube/config` on the control plane:

```yaml
kubeconfig_path: /root/.kube/config
```

### Pod network CIDR

Must match Flannel default if using default Flannel manifest:

```yaml
pod_network_cidr: "10.244.0.0/16"
```

### TrueNAS / storage

```yaml
truenas_storage_enabled: true
storage_backend: "nfs"   # or iscsi, both
truenas_nfs_server: "192.168.1.100"
truenas_nfs_path: "/mnt/tank/k8s-storage"
```

### Disable optional components

In `group_vars/all.yml` (or host/group vars):

```yaml
truenas_storage_enabled: false
velero_enabled: false
self_healing_enabled: false
```

## Adding New Components

1. Create a new role under `ansible/roles/<name>/` (e.g. `tasks/main.yml`, optional `defaults/main.yml`, `files/`).
2. Add the role to `ansible/playbooks/site.yml` with appropriate `hosts` and `tags`.
3. Add any variables to `ansible/inventories/lab/group_vars/all.yml` or role defaults.
4. Update this document and README.md.

## File Permissions

Scripts should be executable on Linux/macOS:

```bash
chmod +x scripts/*.sh
```

## Best Practices

- Keep roles idempotent (safe to run multiple times).
- Use variables for configurable values; use `kubeconfig_path` in roles that call Helm or kubernetes.core against the cluster.
- Document new features in README and PROJECT_STRUCTURE.
- Test on a clean environment before committing.
