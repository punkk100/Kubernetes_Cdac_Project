# Deployment Checklist

Use this checklist to ensure a successful cluster deployment.

## Pre-Deployment

### Hardware & Network
- [ ] 3 laptops available with VMware installed
- [ ] Ubuntu 22.04 ISO downloaded
- [ ] All laptops can reach each other over the network (same WiFi **or via a ZeroTier network**)
- [ ] At least 8GB RAM per laptop
- [ ] 50GB+ free disk space per VM

### VMware Setup
- [ ] Created 3 Ubuntu VMs (one per laptop)
- [ ] Set VM hostnames: `k8s-cp-1`, `k8s-worker-1`, `k8s-worker-2`
- [ ] Configured bridged networking for all VMs **or** verified that each VM has a reachable ZeroTier IP
- [ ] Installed Ubuntu 22.04 on all VMs
- [ ] Enabled SSH on all VMs
- [ ] Noted IP addresses of all VMs (LAN or ZeroTier)

### Network Verification
- [ ] All VMs can ping each other
- [ ] All VMs can SSH to each other
- [ ] No firewall blocking required ports (22, 6443, etc.)

## Control Node Setup

- [ ] Selected control node (typically `k8s-cp-1`)
- [ ] Updated system packages
- [ ] Installed Ansible
- [ ] Installed Helm
- [ ] Installed kubectl
- [ ] Installed Python dependencies
- [ ] Installed Kubernetes Ansible collection
- [ ] Generated SSH key pair
- [ ] Copied SSH key to all cluster nodes
- [ ] Tested passwordless SSH to all nodes

## Project Configuration

- [ ] Cloned/copied project to control node
- [ ] Edited `ansible/inventories/lab/hosts.ini` with correct IPs
- [ ] Edited `ansible/inventories/lab/hosts.ini` with correct username
- [ ] (Optional) Customized `ansible/inventories/lab/group_vars/all.yml`
- [ ] Tested Ansible connectivity: `ansible -i inventories/lab/hosts.ini all -m ping`

## Deployment

### Phase 1: System Preparation
- [ ] Ran common role (or full playbook)
- [ ] Verified swap is disabled on all nodes
- [ ] Verified kernel modules loaded
- [ ] Verified sysctl settings applied

### Phase 2: Kubernetes Installation
- [ ] Kubernetes packages installed on all nodes
- [ ] containerd configured and running
- [ ] Control plane initialized successfully
- [ ] Bootstrap-token phase run (cluster-info ConfigMap + RBAC for join discovery)
- [ ] Worker nodes joined cluster
- [ ] All nodes show as Ready (or at least registered; CNI install comes next): `kubectl get nodes`
- [ ] **If join previously failed:** Reset workers (`ansible ... k8s_workers -m command -a "kubeadm reset -f"`) before re-running the playbook

### Phase 3: Networking
- [ ] Flannel CNI installed
- [ ] Flannel pods running on all nodes
- [ ] Pod-to-pod communication working
- [ ] CoreDNS pods running

### Phase 4: Ingress & Load Balancing
- [ ] NGINX Ingress Controller installed
- [ ] Ingress controller pods running: `kubectl get pods -n ingress-nginx`
- [ ] Ingress service has type LoadBalancer (or NodePort): `kubectl get svc -n ingress-nginx`

### Phase 5: Monitoring
- [ ] Prometheus installed and running
- [ ] Grafana installed and accessible
- [ ] Alertmanager installed
- [ ] Custom PrometheusRules applied
- [ ] Can access Grafana UI (port-forward)
- [ ] Can access Prometheus UI (port-forward)

### Phase 6: Storage
- [ ] TrueNAS storage configured
- [ ] NFS provisioner running
- [ ] StorageClass created
- [ ] Storage class available: `kubectl get storageclass`

### Phase 7: Backup
- [ ] Velero installed
- [ ] MinIO deployed (if using local backup)
- [ ] Backup schedule created
- [ ] Test backup completed successfully

## Post-Deployment Verification

### Cluster Health
- [ ] All nodes Ready: `kubectl get nodes`
- [ ] All system pods Running: `kubectl get pods -A`
- [ ] No CrashLoopBackOff pods
- [ ] No Error states

### Service Access
- [ ] Grafana accessible via port-forward
- [ ] Prometheus accessible via port-forward
- [ ] TrueNAS storage accessible (if enabled)
- [ ] Can create and list resources

### Demo Application (Self-Healing)
- [ ] Self-healing demo deployed (when `self_healing_enabled: true`): `kubectl get pods -n self-healing-demo`
- [ ] Demo deployment pods running
- [ ] PodDisruptionBudget applied; can test pod recreation

### Self-Healing Tests
- [ ] Pod recreation test passed (delete pod, watch recreate)
- [ ] Node failure test passed (stop worker, pods reschedule)
- [ ] Health probe test passed (simulate failure, pod restarts)

### Monitoring
- [ ] Grafana dashboards showing data
- [ ] Node metrics visible
- [ ] Pod metrics visible
- [ ] Alerts configured and testable

### Backup
- [ ] Manual backup created: `velero backup create test`
- [ ] Backup visible in Velero: `velero backup get`
- [ ] Scheduled backup working (check after schedule time)

## Documentation

- [ ] Read README.md
- [ ] Reviewed SETUP_GUIDE.md
- [ ] Bookmarked TROUBLESHOOTING.md
- [ ] Reviewed DISASTER_RECOVERY.md
- [ ] Documented custom configurations
- [ ] Saved kubeconfig location
- [ ] Noted service access URLs

## Security (Optional but Recommended)

- [ ] Changed default Grafana password
- [ ] Reviewed RBAC policies
- [ ] Configured network policies (if needed)
- [ ] Secured etcd backups
- [ ] Reviewed firewall rules

## Troubleshooting

If any item fails:
1. Check [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) (includes **join / cluster-info**, **kubectl on workers**, **reset workers**)
2. **Join failures:** Reset workers, then re-run: `ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"` then re-run playbook
3. Review Ansible playbook output for errors
4. Use `kubectl` from the **control plane** (or after copying kubeconfig); workers do not run the API server
5. Check pod logs: `kubectl logs <pod-name> -n <namespace>`
6. Check node status: `kubectl describe node <node-name>`
7. Review system logs: `journalctl -u kubelet`

## Success Criteria

✅ All nodes Ready
✅ All system pods Running
✅ Monitoring stack operational
✅ Can deploy and access applications
✅ Self-healing working
✅ Backups functional

## Next Steps

After successful deployment:
- [ ] Deploy your applications
- [ ] Configure custom monitoring dashboards
- [ ] Set up additional alerts
- [ ] Test disaster recovery procedures
- [ ] Document your specific setup
- [ ] Plan regular maintenance schedule

---

**Deployment Date:** _______________
**Deployed By:** _______________
**Cluster Name:** _______________
**Notes:** _______________

