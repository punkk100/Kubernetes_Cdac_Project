# Disaster Recovery Guide

This guide covers backup and disaster recovery procedures for your Kubernetes cluster.

## Backup Strategy

### Components to Backup

1. **etcd Data** - Cluster state, configurations, secrets
2. **Application Data** - Persistent volumes
3. **Configuration** - Manifests, ConfigMaps, Secrets
4. **Monitoring Data** - Prometheus metrics (optional)

## etcd Backup

### Manual etcd Snapshot

```bash
# On control plane node
sudo ETCDCTL_API=3 etcdctl snapshot save /backup/etcd-snapshot-$(date +%Y%m%d-%H%M%S).db \
  --endpoints=https://127.0.0.1:2379 \
  --cacert=/etc/kubernetes/pki/etcd/ca.crt \
  --cert=/etc/kubernetes/pki/etcd/server.crt \
  --key=/etc/kubernetes/pki/etcd/server.key
```

### Automated etcd Backup Script

Create `/usr/local/bin/etcd-backup.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/backup/etcd"
DATE=$(date +%Y%m%d-%H%M%S)
RETENTION_DAYS=7

mkdir -p $BACKUP_DIR

sudo ETCDCTL_API=3 etcdctl snapshot save $BACKUP_DIR/etcd-snapshot-$DATE.db \
  --endpoints=https://127.0.0.1:2379 \
  --cacert=/etc/kubernetes/pki/etcd/ca.crt \
  --cert=/etc/kubernetes/pki/etcd/server.crt \
  --key=/etc/kubernetes/pki/etcd/server.key

# Cleanup old backups
find $BACKUP_DIR -name "etcd-snapshot-*.db" -mtime +$RETENTION_DAYS -delete
```

Make it executable:
```bash
sudo chmod +x /usr/local/bin/etcd-backup.sh
```

### Schedule etcd Backups

```bash
# Add to crontab
sudo crontab -e

# Daily backup at 2 AM
0 2 * * * /usr/local/bin/etcd-backup.sh
```

## Velero Backup

### Initial Setup

Velero should be installed during cluster setup. Verify:

```bash
kubectl get pods -n velero
velero version
```

### Manual Backup

```bash
# Backup entire cluster
velero backup create cluster-backup-$(date +%Y%m%d)

# Backup specific namespace
velero backup create app-backup --include-namespaces self-healing-demo

# Backup with specific resources
velero backup create selective-backup \
  --include-resources deployments,services,configmaps
```

### Scheduled Backups

Backup schedule should be created during installation. Verify:

```bash
velero schedule get
```

Create custom schedule:

```bash
velero schedule create daily-backup \
  --schedule="0 2 * * *" \
  --ttl=720h0m0s
```

### Backup Verification

```bash
# List backups
velero backup get

# Describe backup
velero backup describe <backup-name>

# View backup logs
velero backup logs <backup-name>
```

## Restore Procedures

### Restore from Velero Backup

#### Full Cluster Restore

```bash
# List available backups
velero backup get

# Create restore
velero restore create --from-backup <backup-name>

# Monitor restore
velero restore describe <restore-name>
velero restore logs <restore-name>
```

#### Selective Restore

```bash
# Restore specific namespace
velero restore create --from-backup <backup-name> \
  --include-namespaces self-healing-demo

# Restore specific resources
velero restore create --from-backup <backup-name> \
  --include-resources deployments,services
```

### Restore from etcd Snapshot

#### Prerequisites

- Access to control plane node
- etcd snapshot file
- Kubernetes certificates

#### Steps

1. **Stop kubelet and etcd:**

```bash
sudo systemctl stop kubelet
sudo systemctl stop etcd
```

2. **Backup current etcd data:**

```bash
sudo mv /var/lib/etcd /var/lib/etcd.backup
```

3. **Restore from snapshot:**

```bash
sudo ETCDCTL_API=3 etcdctl snapshot restore /backup/etcd-snapshot-YYYYMMDD-HHMMSS.db \
  --data-dir /var/lib/etcd/new \
  --name k8s-cp-1 \
  --initial-cluster k8s-cp-1=https://127.0.0.1:2380 \
  --initial-cluster-token etcd-cluster-1 \
  --initial-advertise-peer-urls https://127.0.0.1:2380
```

4. **Update etcd data directory:**

```bash
sudo mv /var/lib/etcd/new /var/lib/etcd
sudo chown -R etcd:etcd /var/lib/etcd
```

5. **Restart services:**

```bash
sudo systemctl start etcd
sudo systemctl start kubelet
```

6. **Verify cluster:**

```bash
kubectl get nodes
kubectl get pods -A
```

## Disaster Recovery Scenarios

### Scenario 1: Control Plane Node Failure

If the control plane node fails completely:

1. **Restore from etcd backup on new node:**
   - Install Kubernetes on new VM
   - Copy etcd snapshot and certificates
   - Follow etcd restore procedure above

2. **Rejoin worker nodes:**
   ```bash
   # On each worker, reset and rejoin
   sudo kubeadm reset -f
   # Get new join command from restored control plane
   sudo kubeadm join <control-plane-ip>:6443 --token <token> --discovery-token-ca-cert-hash <hash>
   ```

### Scenario 2: Worker Node Failure

1. **Pods automatically reschedule** to other nodes
2. **If using Longhorn**, volumes are replicated
3. **No manual intervention needed** if other nodes have capacity

### Scenario 3: Complete Cluster Failure

1. **Restore etcd** on new control plane (see above)
2. **Restore from Velero backup:**
   ```bash
   velero restore create --from-backup <latest-backup>
   ```
3. **Verify applications:**
   ```bash
   kubectl get pods -A
   kubectl get pvc -A
   ```

### Scenario 4: Data Corruption

1. **Identify affected resources**
2. **Restore from Velero backup:**
   ```bash
   velero restore create --from-backup <backup-name> \
     --include-namespaces <affected-namespace>
   ```
3. **Verify data integrity**

## Backup Storage Locations

### Local Storage (Default)

Backups stored in MinIO (deployed in cluster):
- Access: `kubectl port-forward -n minio svc/minio 9000:9000`
- UI: `kubectl port-forward -n minio svc/minio-console 9001:9001`
- Credentials: minio / minio123

### External S3 Storage

To use external S3:

1. **Create S3 bucket**
2. **Configure Velero:**
   ```bash
   velero install \
     --provider aws \
     --plugins velero/velero-plugin-for-aws:v1.7.0 \
     --bucket <bucket-name> \
     --secret-file ./credentials-velero \
     --backup-location-config region=<region>
   ```

3. **Create credentials file:**
   ```
   [default]
   aws_access_key_id=<access-key>
   aws_secret_access_key=<secret-key>
   ```

## Best Practices

### Backup Frequency

- **etcd:** Daily (or more frequent for production)
- **Velero:** Daily for full cluster, hourly for critical apps
- **Application data:** Per application requirements

### Backup Retention

- **etcd snapshots:** 7-30 days
- **Velero backups:** 30-90 days
- **Off-site copies:** Monthly

### Testing Restores

1. **Test restore procedures regularly** (monthly)
2. **Use separate test cluster** for restore testing
3. **Document restore times** and procedures
4. **Verify application functionality** after restore

### Monitoring Backups

1. **Set up alerts** for backup failures
2. **Monitor backup storage** usage
3. **Review backup logs** regularly
4. **Test restore procedures** periodically

## Backup Verification Checklist

- [ ] etcd snapshots created successfully
- [ ] Velero backups completing without errors
- [ ] Backup storage has sufficient space
- [ ] Backups are accessible and readable
- [ ] Restore procedures tested and documented
- [ ] Backup retention policies configured
- [ ] Alerts configured for backup failures
- [ ] Off-site backup copies maintained

## Emergency Contacts

Document:
- Cluster administrator contacts
- Backup storage locations
- Restore procedure locations
- Escalation procedures

## Recovery Time Objectives (RTO)

- **Control plane failure:** 30 minutes
- **Worker node failure:** Automatic (self-healing)
- **Application failure:** 5-15 minutes
- **Complete cluster failure:** 1-2 hours

## Recovery Point Objectives (RPO)

- **etcd data:** 24 hours (daily backups)
- **Application data:** Per application (typically 1-24 hours)
- **Configuration:** Real-time (GitOps) or daily backups

## Additional Resources

- [Velero Documentation](https://velero.io/docs/)
- [etcd Backup Guide](https://etcd.io/docs/latest/op-guide/recovery/)
- [Kubernetes Disaster Recovery](https://kubernetes.io/docs/tasks/administer-cluster/cluster-management/)

