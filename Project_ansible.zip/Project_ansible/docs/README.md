# K8s AutoOps: Ansible Provisioning + Prometheus Monitoring

A complete Kubernetes cluster setup using Ansible for a 3-node deployment (1 control plane + 2 workers) with monitoring, self-healing, and disaster recovery capabilities.

## Architecture

### Topology

- **Node 1:** `k8s-cp-1` (Control Plane) – runs control plane components and Ansible-driven add-ons (Helm/kubectl).
- **Node 2:** `k8s-worker-1` (Worker).
- **Node 3:** `k8s-worker-2` (Worker).

### Components

- **Kubernetes:** v1.28+ cluster with containerd runtime.
- **CNI:** Flannel for pod networking (VXLAN).
- **Ingress:** NGINX Ingress Controller (Helm; LoadBalancer service).
- **Monitoring:** Prometheus + Grafana + Alertmanager (kube-prometheus-stack).
- **Storage:** TrueNAS NFS for persistent volumes (optional).
- **Backup/DR:** Velero for cluster backups; etcd snapshot script (optional).
- **Self-healing:** Demo deployment with health probes and PodDisruptionBudget (optional).

## Prerequisites

### Hardware

- 3 machines (VMs or physical) with Ubuntu 22.04 LTS.
- 8 GB RAM per node recommended; 50 GB disk; 2+ vCPUs.

### Network

- All nodes on same network (or overlay, e.g. ZeroTier).
- SSH from control node to all cluster nodes; passwordless SSH recommended.

### Software (control node)

- Ubuntu 22.04 LTS.
- Ansible 2.14+.
- Python 3.8+ (with venv recommended).
- Helm 3.12+.
- kubectl 1.28+.
- **Ansible collection:** `kubernetes.core` (see `ansible/collections/requirements.yml`).

## Quick Start

> For more detail, see [HOW_TO_RUN.md](HOW_TO_RUN.md) and [QUICKSTART.md](QUICKSTART.md).

### 1. Prepare control node

```bash
chmod +x scripts/setup-control-node.sh
./scripts/setup-control-node.sh
```

### 2. Configure cluster nodes (interactive)

```bash
chmod +x scripts/setup-cluster-nodes.sh
./scripts/setup-cluster-nodes.sh
```

This script will prompt for control plane and worker IPs and users, test SSH, create/update the inventory, copy SSH keys, and verify Ansible connectivity.

### 3. Run the playbook

**Guided (all steps):**

```bash
chmod +x scripts/run-project.sh
./scripts/run-project.sh
```

**Manual:**

```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

### 4. Verify

```bash
./scripts/copy-kubeconfig.sh <user>@<control-plane-ip>
./scripts/verify-cluster.sh
```

## Project Structure

```
Project_ansible/
├── README.md                 # This file
├── PROJECT_OVERVIEW.md       # Architecture and design
├── PROJECT_STRUCTURE.md      # File and folder reference
├── ansible/
│   ├── ansible.cfg
│   ├── collections/requirements.yml   # kubernetes.core
│   ├── inventories/lab/
│   │   ├── hosts.ini         # Edit with your node IPs/users
│   │   └── group_vars/all.yml
│   ├── playbooks/
│   │   └── site.yml          # Main playbook
│   └── roles/
│       ├── common/           # System prep (all nodes)
│       ├── kubernetes/       # kubeadm, containerd, init/join
│       ├── flannel/          # CNI
│       ├── ingress-nginx/   # NGINX Ingress (Helm)
│       ├── monitoring/      # Prometheus, Grafana, Alertmanager
│       ├── truenas-storage/  # NFS provisioner (optional)
│       ├── velero/           # Backup/DR (optional)
│       └── self-healing/     # Demo PDB (optional)
├── scripts/                  # Setup, verify, backup
└── docs/
    ├── SETUP_GUIDE.md
    ├── TROUBLESHOOTING.md
    └── DISASTER_RECOVERY.md
```

See [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) for a full file-by-file description.

## Run by stage (tags)

```bash
cd ansible

# Full run
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml

# By stage
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags kubernetes
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags cni,flannel,networking
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags ingress,nginx
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring,prometheus,grafana
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags storage,truenas,nfs
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags backup,velero,dr
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags demo,self-healing
```

## Configuration

Edit `ansible/inventories/lab/group_vars/all.yml` to customize:

- **kubeconfig_path:** Path to kubeconfig on control plane (default `/root/.kube/config`). Used by Helm and Kubernetes Ansible modules.
- **Pod network:** `pod_network_cidr` (must match Flannel default if using default manifest).
- **TrueNAS:** `truenas_storage_enabled`, `truenas_nfs_server`, `truenas_nfs_path`, `storage_backend`.
- **Optional components:**
  - `truenas_storage_enabled: false` – skip TrueNAS NFS.
  - `velero_enabled: false` – skip Velero.
  - `self_healing_enabled: false` – skip self-healing demo.

## Accessing services

### Grafana

**Port-forward method:**
```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# Open http://localhost:3000 — credentials in monitoring role defaults / group_vars
```

**NodePort via Ingress (no DNS required):**
```bash
# Get NodePort
kubectl get svc -n ingress-nginx ingress-nginx-controller
# Access via: http://<any-node-ip>:<http-nodeport>/grafana
```

**Hostname-based (add to /etc/hosts):**
```bash
# Add to /etc/hosts: <node-ip> grafana.local
# Access via: http://grafana.local:<http-nodeport>
```

See [INGRESS_MONITORING_FIXES.md](INGRESS_MONITORING_FIXES.md) for detailed access instructions.

### Prometheus

**Port-forward method:**
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
# Open http://localhost:9090
```

**Via Ingress:**
```bash
# NodePort: http://<node-ip>:<nodeport>/prometheus
# Hostname: http://prometheus.local:<nodeport>
```

### Ingress NGINX

```bash
kubectl get svc -n ingress-nginx
# Use LoadBalancer EXTERNAL-IP or NodePort for HTTP(S).
```

For comprehensive verification:
```bash
./scripts/verify-ingress-monitoring.sh
```

## Troubleshooting

- **Common issues:** [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).
- **Workers fail to join:** Reset workers (`ansible -i ansible/inventories/lab/hosts.ini k8s_workers -m command -a "kubeadm reset -f"`), then re-run the playbook.
- **Quick checks:**
  - `kubectl get nodes`
  - `kubectl get pods -A`
  - `kubectl get pods -n kube-flannel`
  - `kubectl get pods -n ingress-nginx`

## Documentation

- [INGRESS_MONITORING_FIXES.md](INGRESS_MONITORING_FIXES.md) – **Complete fix guide for Ingress NGINX, Prometheus & Grafana** (access methods, troubleshooting, all fixes applied).
- [VERIFICATION.md](VERIFICATION.md) – **How to know everything is running** (what runs when, how to check each component).
- [PROJECT_OVERVIEW.md](PROJECT_OVERVIEW.md) – Architecture and automation layout.
- [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) – Files and folders reference.
- [HOW_TO_RUN.md](HOW_TO_RUN.md) – How to run the project.
- [QUICKSTART.md](QUICKSTART.md) – Short setup guide.
- [docs/SETUP_GUIDE.md](docs/SETUP_GUIDE.md) – Detailed setup.
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) – Common issues and fixes.
- [docs/DISASTER_RECOVERY.md](docs/DISASTER_RECOVERY.md) – Backup and restore.

## License

MIT License – see [LICENSE](LICENSE).

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).
