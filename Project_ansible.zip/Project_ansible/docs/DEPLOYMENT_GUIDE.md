# Complete Deployment Guide - Ingress & Monitoring

This guide walks you through deploying the fixed Ingress NGINX and Monitoring stack.

---

## Prerequisites

### Before You Begin

**Hardware:**
- 3 nodes (1 control plane + 2 workers)
- 8 GB RAM per node minimum
- 50 GB disk per node
- 2+ vCPUs per node

**Network:**
- All nodes on same network or overlay (e.g., ZeroTier)
- SSH access from control node to all cluster nodes
- Passwordless SSH recommended

**Software (Control Node):**
- Ubuntu 22.04 LTS
- Ansible 2.14+
- Python 3.8+
- Helm 3.12+
- kubectl 1.28+

---

## Step 1: Prepare Control Node

Run the setup script:

```bash
cd /path/to/Project_ansible
chmod +x scripts/setup-control-node.sh
./scripts/setup-control-node.sh
```

This installs:
- Python virtual environment
- Ansible
- Ansible collections (kubernetes.core)
- kubectl
- Helm

**Verify:**
```bash
ansible --version
kubectl version --client
helm version
```

---

## Step 2: Configure Cluster Nodes

### Option A: Interactive Setup (Recommended)

```bash
chmod +x scripts/setup-cluster-nodes.sh
./scripts/setup-cluster-nodes.sh
```

Follow prompts to:
1. Enter control plane IP and user
2. Enter worker node IPs and users
3. Test SSH connectivity
4. Copy SSH keys
5. Verify Ansible connectivity

### Option B: Manual Configuration

Edit inventory file:

```bash
nano ansible/inventories/lab/hosts.ini
```

```ini
[k8s_control_plane]
k8s-cp-1 ansible_host=10.118.129.3 ansible_user=root

[k8s_workers]
k8s-worker-1 ansible_host=10.118.129.36 ansible_user=master
k8s-worker-2 ansible_host=10.118.129.102 ansible_user=worker1

[k8s_cluster:children]
k8s_control_plane
k8s_workers

[all:vars]
ansible_ssh_private_key_file=/root/.ssh/id_ed25519
ansible_python_interpreter=/usr/bin/python3
ansible_ssh_common_args='-o StrictHostKeyChecking=no'
```

**Test connectivity:**
```bash
ansible -i ansible/inventories/lab/hosts.ini all -m ping
```

---

## Step 3: Configure Settings (Optional)

### Group Variables

Edit `ansible/inventories/lab/group_vars/all.yml`:

```yaml
# Kubeconfig path on control plane
kubeconfig_path: /root/.kube/config

# Network configuration
pod_network_cidr: "10.244.0.0/16"  # Must match Flannel default
service_cidr: "10.96.0.0/12"

# Optional components
truenas_storage_enabled: true   # Set to false if no TrueNAS
velero_enabled: true            # Set to false to skip Velero
self_healing_enabled: true      # Set to false to skip demo app
```

### Monitoring Configuration

Edit `ansible/roles/monitoring/defaults/main.yml`:

```yaml
prometheus_retention: "30d"           # Change to "7d" for testing
grafana_admin_password: "admin123"   # CHANGE THIS for production!
ingress_enabled: true                 # Set to false to skip Ingress
```

**⚠️ IMPORTANT:** Change `grafana_admin_password` for production deployments!

---

## Step 4: Deploy the Cluster

### Full Deployment (All Components)

```bash
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml
```

This deploys:
1. Common setup (all nodes)
2. Kubernetes cluster (control plane + workers)
3. Flannel CNI
4. Ingress NGINX
5. Monitoring stack (Prometheus, Grafana, Alertmanager)
6. TrueNAS storage (if enabled)
7. Velero backup (if enabled)
8. Self-healing demo (if enabled)

**Expected duration:** 15-30 minutes (depending on network speed)

### Partial Deployment (Specific Components)

**Ingress Only:**
```bash
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags ingress,nginx
```

**Monitoring Only:**
```bash
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring,prometheus,grafana
```

**Kubernetes + CNI Only:**
```bash
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags kubernetes,k8s,cni,flannel
```

---

## Step 5: Verify Deployment

### Automated Verification

```bash
chmod +x scripts/verify-ingress-monitoring.sh
./scripts/verify-ingress-monitoring.sh
```

**Expected output:**
- ✓ All green checkmarks for components
- Service information and access details
- NodePort and access instructions

### Manual Verification

**Check cluster:**
```bash
kubectl get nodes
# All nodes should show "Ready"

kubectl get pods -A
# All pods should be "Running"
```

**Check Ingress NGINX:**
```bash
kubectl get pods -n ingress-nginx
kubectl get svc -n ingress-nginx
```

**Check Monitoring:**
```bash
kubectl get pods -n monitoring
kubectl get svc -n monitoring
kubectl get ingress -n monitoring
```

---

## Step 6: Access Services

### Get Access Information

**Get NodePort:**
```bash
kubectl get svc -n ingress-nginx ingress-nginx-controller
```

Look for output like:
```
NAME                       TYPE           CLUSTER-IP      EXTERNAL-IP   PORT(S)                      AGE
ingress-nginx-controller   LoadBalancer   10.96.xxx.xxx   <pending>     80:30080/TCP,443:30443/TCP   5m
```

NodePort for HTTP: **30080** (in this example)

**Get Node IP:**
```bash
kubectl get nodes -o wide
```

Use any node's INTERNAL-IP (e.g., 10.118.129.3)

### Access Grafana

**Method 1: Port-forward (Easiest)**
```bash
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
```
Open: http://localhost:3000

**Method 2: NodePort (No DNS)**
```
http://10.118.129.3:30080/grafana
```
Replace with your node IP and NodePort

**Method 3: Hostname (With DNS or /etc/hosts)**

Add to `/etc/hosts`:
```
10.118.129.3 grafana.local
```

Access:
```
http://grafana.local:30080
```

**Login Credentials:**
- Username: `admin`
- Password: `admin123` (or what you set in defaults)

### Access Prometheus

**Method 1: Port-forward**
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090
```
Open: http://localhost:9090

**Method 2: NodePort**
```
http://10.118.129.3:30080/prometheus
```

**Method 3: Hostname**
```
http://prometheus.local:30080
```

### Access Alertmanager

**Method 1: Port-forward**
```bash
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-alertmanager 9093:9093
```
Open: http://localhost:9093

**Method 2: NodePort**
```
http://10.118.129.3:30080/alertmanager
```

**Method 3: Hostname**
```
http://alertmanager.local:30080
```

---

## Step 7: Verify Monitoring is Working

### Check Grafana

1. **Login to Grafana** (see access methods above)

2. **Verify Datasource:**
   - Go to: Configuration → Data Sources
   - Should see "Prometheus" with green checkmark
   - URL should be: `http://monitoring-kube-prometheus-prometheus.monitoring.svc:9090`

3. **Explore Dashboards:**
   - Click on Dashboards (left sidebar)
   - Browse → Default
   - Open "Kubernetes / Compute Resources / Cluster"
   - You should see metrics and graphs

### Check Prometheus

1. **Access Prometheus UI** (see access methods above)

2. **Check Targets:**
   - Go to: Status → Targets
   - All targets should be "UP" (green)
   - Should see targets for:
     - prometheus
     - kube-state-metrics
     - node-exporter
     - kubelet
     - apiserver

3. **Run a Query:**
   - Go to Graph tab
   - Enter query: `up`
   - Click Execute
   - Should see results showing all services with value `1`

### Check Ingress Integration

**Verify Ingress metrics are being scraped:**

1. Access Prometheus UI
2. Go to Status → Targets
3. Look for "ingress-nginx" targets
4. Run query: `nginx_ingress_controller_requests`
5. Should see metrics

---

## Step 8: Troubleshooting

### Problem: Pods Not Starting

**Check pod status:**
```bash
kubectl describe pod -n <namespace> <pod-name>
kubectl logs -n <namespace> <pod-name>
```

**Common causes:**
- Image pull errors (check network connectivity)
- Resource constraints (check node resources: `kubectl top nodes`)
- Config errors (check pod events: `kubectl describe pod`)

### Problem: PVC Pending

**Check PVCs:**
```bash
kubectl get pvc -n monitoring
```

**Check StorageClass:**
```bash
kubectl get sc
```

**Solution:**
- If no StorageClass: Monitoring will deploy with ephemeral storage (data lost on pod restart)
- To add persistent storage: Deploy TrueNAS or other storage provisioner
- For testing: Ephemeral storage is acceptable

### Problem: Can't Access Services

**Check NodePort:**
```bash
kubectl get svc -n ingress-nginx ingress-nginx-controller
```

**Check if pods are running:**
```bash
kubectl get pods -n ingress-nginx
kubectl get pods -n monitoring
```

**Check Ingress resources:**
```bash
kubectl get ingress -n monitoring
kubectl describe ingress -n monitoring grafana-ingress
```

**Check Ingress controller logs:**
```bash
kubectl logs -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx
```

### Problem: Grafana Shows "No Data"

**Check Prometheus is running:**
```bash
kubectl get pods -n monitoring -l app.kubernetes.io/name=prometheus
```

**Check Prometheus logs:**
```bash
kubectl logs -n monitoring prometheus-monitoring-kube-prometheus-prometheus-0
```

**Check Grafana datasource:**
1. Login to Grafana
2. Configuration → Data Sources
3. Click on Prometheus datasource
4. Scroll down and click "Save & Test"
5. Should see green checkmark "Data source is working"

### Problem: Grafana Can't Login

**Reset password:**

Option 1 - Redeploy with new password:
```bash
# Edit ansible/roles/monitoring/defaults/main.yml
grafana_admin_password: "NewPassword123"

# Redeploy
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring
```

Option 2 - Reset from pod:
```bash
kubectl exec -n monitoring -it deployment/monitoring-grafana -- grafana-cli admin reset-admin-password NewPassword123
```

---

## Step 9: Import Additional Dashboards

### Community Dashboards

1. **Login to Grafana**

2. **Click '+' (plus icon) → Import**

3. **Enter Dashboard ID:**
   - **9614** - NGINX Ingress Controller
   - **13770** - Kubernetes Cluster Monitoring
   - **12114** - Kubernetes API Server
   - **8588** - Kubernetes Deployment Metrics

4. **Click Load**

5. **Select Prometheus datasource**

6. **Click Import**

### Custom Dashboards

Create your own dashboards for application-specific metrics:

1. Click '+' → Dashboard
2. Add Panel
3. Write PromQL queries
4. Configure visualization
5. Save dashboard

---

## Step 10: Configure Alerting (Optional)

### Edit Alert Rules

Alert rules are in `ansible/roles/monitoring/files/prometheus-rules.yaml`:

```yaml
- alert: NodeDown
  expr: up{job="node-exporter"} == 0
  for: 5m
  labels:
    severity: critical
  annotations:
    summary: "Node {{ $labels.instance }} is down"
```

**To modify:**
1. Edit the file
2. Redeploy: `ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml --tags monitoring`

### Configure Alertmanager

**Create receiver configuration:**

```bash
kubectl edit secret -n monitoring alertmanager-monitoring-kube-prometheus-alertmanager
```

**Example email receiver:**
```yaml
receivers:
  - name: 'email'
    email_configs:
      - to: 'alerts@example.com'
        from: 'alertmanager@example.com'
        smarthost: 'smtp.example.com:587'
        auth_username: 'alertmanager@example.com'
        auth_password: 'password'

route:
  receiver: 'email'
  group_wait: 30s
  group_interval: 5m
  repeat_interval: 4h
```

---

## Step 11: Next Steps

### For Testing Environments

1. ✅ Verify all components are running
2. ✅ Access Grafana and explore dashboards
3. ✅ Check Prometheus targets are up
4. ✅ Test Ingress access methods
5. ✅ Review alert rules

### For Production Environments

1. **Change default passwords:**
   ```yaml
   grafana_admin_password: "SecurePassword123!"
   ```

2. **Enable TLS for Ingress:**
   - Install cert-manager
   - Create TLS certificates
   - Update Ingress annotations

3. **Configure authentication:**
   - Set up OAuth (Google, GitHub, etc.)
   - Or configure LDAP/Active Directory
   - Enable SSO

4. **Implement security:**
   - Add NetworkPolicies
   - Restrict namespace access
   - Enable RBAC
   - Use Pod Security Standards

5. **Set up backups:**
   - Configure Velero for cluster backups
   - Backup Prometheus data
   - Export Grafana dashboards

6. **Optimize resources:**
   - Adjust Prometheus retention based on needs
   - Tune resource limits based on actual usage
   - Configure scrape intervals

7. **Deploy MetalLB (optional):**
   - For LoadBalancer support on bare metal
   - Provides actual External-IP for services

---

## Deployment Checklist

### Pre-Deployment
- [ ] Control node prepared
- [ ] Cluster nodes configured
- [ ] SSH connectivity verified
- [ ] Ansible collections installed
- [ ] Configuration reviewed
- [ ] Grafana password changed (production)

### Deployment
- [ ] Playbook executed successfully
- [ ] No errors in Ansible output
- [ ] All plays completed

### Post-Deployment
- [ ] All nodes show "Ready"
- [ ] All pods are "Running"
- [ ] Ingress NGINX deployed
- [ ] Prometheus deployed
- [ ] Grafana deployed
- [ ] Alertmanager deployed
- [ ] Ingress resources created

### Verification
- [ ] Verification script runs successfully
- [ ] Can access Grafana
- [ ] Can login to Grafana
- [ ] Prometheus datasource working
- [ ] Dashboards show data
- [ ] Prometheus targets are UP
- [ ] Alertmanager accessible

### Access Testing
- [ ] Port-forward access works
- [ ] NodePort access works
- [ ] Hostname access works (if DNS configured)
- [ ] All three services accessible (Grafana, Prometheus, Alertmanager)

---

## Quick Command Reference

```bash
# Deploy everything
cd ansible
ansible-playbook -i inventories/lab/hosts.ini playbooks/site.yml

# Verify
./scripts/verify-ingress-monitoring.sh

# Get access info
kubectl get svc -n ingress-nginx ingress-nginx-controller
kubectl get nodes -o wide

# Port-forward to Grafana
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80

# Port-forward to Prometheus
kubectl -n monitoring port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090

# Check pods
kubectl get pods -n ingress-nginx
kubectl get pods -n monitoring

# Check logs
kubectl logs -n ingress-nginx -l app.kubernetes.io/name=ingress-nginx
kubectl logs -n monitoring -l app.kubernetes.io/name=grafana
kubectl logs -n monitoring prometheus-monitoring-kube-prometheus-prometheus-0
```

---

## Support & Documentation

**Main Documentation:**
- [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Quick access guide
- [INGRESS_MONITORING_FIXES.md](INGRESS_MONITORING_FIXES.md) - Technical details
- [PROJECT_FIX_SUMMARY.md](PROJECT_FIX_SUMMARY.md) - Summary of all fixes
- [PROJECT_ANALYSIS_SUMMARY.md](PROJECT_ANALYSIS_SUMMARY.md) - Complete analysis

**Project Documentation:**
- [README.md](README.md) - Project overview
- [VERIFICATION.md](VERIFICATION.md) - Component verification
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) - Troubleshooting guide

**Verification Script:**
```bash
./scripts/verify-ingress-monitoring.sh
```

---

**Status:** ✅ Ready to deploy - All fixes applied and tested

Good luck with your deployment! 🚀
